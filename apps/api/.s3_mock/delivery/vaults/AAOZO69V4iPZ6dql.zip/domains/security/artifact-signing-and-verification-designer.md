---
id: skillsgit-curated/artifact-signing-and-verification-designer
version: 1.0.1
name: Artifact Signing and Verification Designer
description: Design a signing and verification flow for build artifacts and container
  images, covering identity, key management, transparency log, attestation binding,
  and deploy-time policy enforcement.
authors:
- name: Wave-3 Methodology Synthesis
  handle: wave3-supplychain
  role: author
category: engineering
tags:
- niche:supply-chain-security
- sigstore
- cosign
- keyless-signing
- transparency-log
- admission-control
- policy-enforcement
links:
- target: ci-pipeline-architect
  relation: applies
- target: secrets-architecture-designer
  relation: see-also
license_type: free
ai:
  required_models:
  - claude-opus-4-7
  - claude-sonnet-4-6
  compatible_models:
  - gpt-4o
  - gpt-4.1
  - gemini-1.5-pro
  min_context_tokens: 32000
  tools_optional:
  - web_search
  estimated_tokens_per_invocation: 6500
trigger_keywords:
- artifact signing
- cosign
- sigstore
- keyless signing
- signature verification
- admission controller
- transparency log
- rekor
- fulcio
- image signing
example_invocations:
- Design end-to-end signing for our container images and Helm charts.
- Keyless vs key-based signing — which fits our org?
- How do we enforce signature checks at deploy without breaking the deploy pipeline?
- Plan key rotation and revocation for our signing identities.
inputs:
- name: artifact_classes
  type: text
  required: true
  description: What you need to sign — container images, OCI artifacts, OS packages,
    language packages, Helm/Kustomize bundles, binaries, ML model files.
- name: build_environment
  type: text
  required: true
  description: Build platform (GitHub Actions, GitLab CI, self-hosted CI, Bazel remote,
    Buildkite, etc.) and whether it supports workload identity / OIDC.
- name: deployment_platform
  type: text
  required: true
  description: Where artifacts are consumed (Kubernetes via admission controller,
    package managers, OS distribution, customer download, embedded device).
- name: organizational_constraints
  type: text
  required: false
  description: Regulatory keys requirements (FIPS, HSM-backed), air-gapped operation,
    multi-tenant builders, geographic key custody.
- name: existing_state
  type: text
  required: false
  description: Anything signed today, key custody, tooling already in production.
outputs:
- name: signing_design
  type: markdown
  description: A signing and verification design with identity model, transparency-log
    policy, rotation/revocation plan, and deploy-time enforcement.
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release.
kind: skill
distribution:
  content_hash: cc5c062aa51653f51232c44535e2fc20470ffbd9bb58d4619a9e357f0012877f
  signed_at: '2026-06-04T09:34:38.037130Z'
  signed_by: marketplace
  signature: 518ca98992b01dff9f954703964d7510b5dde165304c617570c5425599cb94c2
---

# Artifact Signing and Verification Designer

## When to use

Use this skill when a team needs a coherent, defensible design for signing artifacts and verifying them at consumption. Typical situations:

- The team is about to adopt artifact signing for the first time and wants the design right before they pin a direction.
- Existing signing is ad-hoc (long-lived keys on a build server, no transparency log, no verification at deploy).
- A move to Kubernetes admission-controller-based enforcement is on the roadmap.
- Compliance asks for evidence that "we sign all artifacts and verify on deploy."
- Key custody arrangements (HSM, multi-region, multi-tenant builders) need rethinking.

The skill produces a design — identity model, signing flow, verification flow, rotation plan, failure modes. It does not write the YAML.

**Scope guardrail.** This is methodology guidance. The exact policy bindings and rotation cadences must be reviewed against your regulatory, contractual, and threat-model context. Cryptographic operations in regulated environments may require FIPS-validated modules and external review.

## How to apply

Walk the eight phases below. Each phase has explicit decision points; capture each decision before moving on, because downstream phases assume earlier choices.

### Phase 1 — Inventory what gets signed and what verifies it

Every artifact class has a different signing story; do not assume container-image patterns apply to language packages or vice versa.

For each artifact class, record:

- **Type.** Container image, OCI artifact, Helm chart, raw binary, JAR, wheel, npm tarball, OS package, ML model.
- **Where it is stored.** Registry, package repository, internal mirror, customer-accessible CDN.
- **How it is fetched at consumption.** kubelet pull, package manager install, custom installer, plugin loader.
- **Who or what verifies it.** Kubernetes admission controller, package manager, custom deploy script, OS update tool, none-yet.
- **What "deny" means.** Block deploy? Warn-only? Quarantine and alert?

Without an enforcement path, signing is decorative. If no verifier exists for a class, decide either to build one or to descope the class for now.

### Phase 2 — Decide identity model: keyless vs key-based

Pick deliberately. Most modern build platforms can use keyless; some environments still require key-based.

**Keyless (recommended default where it fits).** Build identity is a workload identity (OIDC) — e.g., a CI job in your build platform. A trusted CA (such as Fulcio in the Sigstore stack) issues a short-lived X.509 certificate to that identity at signing time. The signature is bound to the identity, not to a stored key.

Pros:
- No long-lived signing keys to steal, rotate, or hide in a vault.
- The signing identity is auditable: "this image was signed by *this workflow* in *this repo* on *this commit*."
- Pairs naturally with provenance attestations.

Cons / where it fails:
- Requires a build platform that supports OIDC workload identity.
- Requires consumers to trust the CA's identity issuance policy.
- Air-gapped or offline builds require running your own CA + transparency log.

**Key-based.** A long-lived private key (KMS-managed, ideally HSM-backed) signs artifacts. Public key is distributed to verifiers.

Pros:
- Works in air-gapped environments.
- Familiar to regulators / auditors used to PKI patterns.
- Compatible with FIPS-validated HSMs out of the box.

Cons:
- Key custody is an operational burden: backup, rotation, revocation, access control, audit.
- A stolen key is reusable until rotation; transparency log helps detect, not prevent.
- The signing identity is the key, not a workload identity — less expressive.

**Hybrid.** Production builds use keyless; security-critical or air-gapped releases use HSM-backed key-based. Document the policy clearly so consumers know which to expect per artifact class.

### Phase 3 — Bind to the artifact correctly

Common failure: signing a wrapper or a tag, not the artifact's content digest.

Rules:

- **Sign by content digest, never by mutable tag.** For OCI artifacts, the signature subject is the manifest digest. Tags are pointers and can be re-pointed; digests cannot.
- **One signature per artifact instance.** A new build is a new artifact and needs a new signature. Do not re-use signatures across rebuilds.
- **Bind related attestations to the same subject.** Provenance, SBOM, and vulnerability scan attestations all reference the same artifact digest. Verifiers can then evaluate them as a set.
- **Document the subject scheme.** For non-OCI artifacts (raw binaries, source tarballs), define how the digest is computed and where the signature lives (sidecar `.sig` file, signed manifest, registry attestation).

### Phase 4 — Use a transparency log

Transparency log is the difference between "we sign" and "we can detect silent re-signing".

Properties to require:

- **Append-only and tamper-evident.** Inclusion proofs are cryptographically verifiable; consumers can confirm a signature was recorded at a stated time.
- **Public or private deployment.** Most teams should use the public Sigstore Rekor log; air-gapped or sensitive-identity environments may run a private log instance. Document which one each signature lands in.
- **Monitoring.** Run a monitor (e.g., a Rekor monitor) that watches the log for signatures attributed to your identities. An entry you didn't expect is a high-signal alert: someone is signing as you.
- **Retention and offline verification.** Plan how a consumer in 5 years verifies a signature from today. The log entry's inclusion proof + a signed log checkpoint of that era must be archived.

### Phase 5 — Design the verification path

This is where most signing programs collapse. Producing signatures with no verifier downstream is theater.

For each consumption path, define:

- **What "valid" means.** Signature is well-formed (table stakes), signed by an allowed identity (mandatory), recorded in a known transparency log (mandatory), within an acceptable time window relative to artifact creation (optional, but useful to detect re-signing of stale artifacts).
- **What identities are allowed.** Build-platform workload identities for specific repositories / workflows / branches. *Not* the entire CA's issued population. Pin to the precise OIDC claim set you trust.
- **Policy language.** Use an admission-controller policy framework that supports per-namespace or per-workload rules. Kubernetes patterns are well-developed (e.g., Sigstore Policy Controller); for non-Kubernetes consumers, custom CLI verifiers or package-manager plugins fill the gap.
- **Fail-closed vs fail-open.** Production deploys fail closed (no signature → deny). Dev / preview environments may fail open with audit logging. Document and stage the rollout.
- **Bypass paths.** No bypass paths in production. Document the break-glass procedure (e.g., a separate signing identity with elevated review, used only in incident response) instead.

### Phase 6 — Plan rotation, revocation, and incident response

You will need to rotate. Plan it before you need it.

Rotation:

- **Keyless.** The "key" is the workload identity. Rotation = retiring the OIDC issuer or changing the workflow. Old signatures remain valid (still in transparency log under the old identity); policy is updated to add the new identity and, on a schedule, remove the old one once all artifacts signed by it are out of support.
- **Key-based.** Define rotation cadence (annual is common for HSM-backed root keys; quarterly for intermediates). Maintain a "key timeline" document mapping each artifact to the key that signed it.

Revocation:

- **Keyless.** Revoke the upstream identity (suspend the OIDC issuer trust, disable the workload). For specific bad artifacts, push a deny rule referencing the artifact's content digest into admission policy. Do *not* try to delete transparency-log entries — the log is append-only by design.
- **Key-based.** Use a CRL or revocation list distributed to verifiers. Maintain a deny-by-digest list for known-bad artifacts as a faster path.

Incident response rehearsal:

- A signing identity is compromised. Steps: detect (transparency-log monitor alerts on unexpected entries), contain (revoke identity / rotate key), assess (which artifacts were signed during the suspect window — every transparency-log entry has a timestamp), notify, remediate (re-sign legitimate artifacts under the new identity, push deny rules for unauthorized ones). Rehearse on a calendar.

### Phase 7 — Operational metrics

Track these from day one; they tell you whether the program is real.

- **Coverage.** % of shipped artifacts with a current, valid signature. Target: 100%.
- **Verification coverage.** % of deploy paths that verify signatures before admitting. Target: 100% for production.
- **Deny events.** Count of admission denials due to signature failures, broken out by reason (unsigned, wrong identity, transparency-log miss). A flat-zero count is suspicious — it usually means verification is misconfigured to fail-open.
- **Time to revoke.** From identifying a bad artifact to having it denied everywhere. Sub-hour is achievable; multi-day means the revocation path is broken.
- **Transparency-log monitor coverage.** % of signing identities under active monitoring.

### Phase 8 — Document the threat model boundaries

Be explicit about what this design does and does not defend against.

Defends against:
- Tampering with artifacts in transit or in registry (mismatching digest fails verification).
- Replay of stale or unauthorized artifacts at deploy.
- Silent unauthorized signing (detected by transparency-log monitor).
- Compromise of a stored signing key in keyless mode (no key to steal).

Does *not* defend against (and you must say so):
- A compromised builder that signs malicious code as itself. Defense for this is provenance + build-environment hardening, not signing.
- A compromised source repo whose code legitimately reaches a legitimate builder. Defense is source-stage controls (branch protection, two-person review).
- Long-tail consumer trust mistakes (a deploy that disables verification "just for this rollout"). Defense is policy-as-code with audit logs that catch bypass.
- Cryptographic-agility events (algorithm break, log compromise). Plan for hash-agility and CA-agility in your design — be prepared to re-attest under new algorithms.

## Inputs

- **Artifact classes.** What gets signed.
- **Build environment.** Especially: does it support workload identity OIDC?
- **Deployment platform.** Where verification lives.
- **Organizational constraints.** Regulatory, key custody, air gap.
- **Existing state.** Avoid prescribing a rip-and-replace where not needed.

## Outputs

A markdown design containing:

1. **Artifact-class table.** Per class: signing approach, subject scheme, attestations bound, verification path.
2. **Identity model.** Keyless vs key-based, per class; rationale.
3. **Transparency-log plan.** Public vs private, monitor placement.
4. **Verification policy.** Allowed identities per environment, fail-closed boundaries, dev/preview exceptions.
5. **Rotation / revocation runbook.** Routine rotation cadence, revocation paths, incident-response rehearsal calendar.
6. **Operational metrics dashboard.** With targets.
7. **Threat-model statement.** What this design defends against and what it explicitly does not.
8. **Rollout sequencing.** Which artifact classes ship first; which deploy paths flip from monitor-only to enforce, on what schedule.

## Examples

**Example A — Kubernetes-centric SaaS shipping container images and Helm charts.**

Keyless signing with workload-identity-bound certs from the build platform's OIDC issuer. One signature per image manifest digest; one per Helm chart's content digest. Provenance and SBOM attached as in-toto attestations to the same subjects. Public transparency log; a Rekor-style monitor watching for unexpected entries against the org's identities. Kubernetes admission controller enforces: image must be signed by a build-platform identity bound to one of the allowed source repos, and the workflow path must match the release workflow. Dev/staging environments fail open with audit logging for the first 30 days, then flip to fail closed. Revocation rehearsed quarterly with a synthetic incident: a "bad" image is pushed and observed to be denied.

**Example B — Regulated on-prem product, air-gapped customers.**

Hybrid identity model. Build pipeline produces keyless-signed staging artifacts (workload-identity); a separate offline release ceremony re-signs the final release with an HSM-backed key. Customers ship with the HSM-key's public key burned into their verification config. Run a private transparency log instance, mirrored to a customer-accessible snapshot for offline inclusion-proof verification. Rotation cadence: HSM root key every 3 years; intermediates annually. Revocation: CRL distributed via the same channel as software updates; deny-by-digest list maintained alongside the CRL.

## Limitations

- This skill assumes the build platform itself is trusted. A compromised builder defeats signature integrity end-to-end. Pair this design with build-stage hardening from the SLSA Maturity Assessor skill.
- Algorithm-agility is not solved by signing alone. Plan for re-attestation when current hash or signature algorithms are deprecated.
- Real-world air-gapped operation introduces complexity (private log, key custody) outside the scope of a methodology design. Engage cryptography and operations expertise for that path.
- The skill does not prescribe specific HSM models or KMS vendors. Vendor choices depend on regulatory regime, geography, and existing infrastructure.
- Verification at runtime (post-deploy) is out of scope; this skill covers admission-time verification only. Workload identity and process-attestation are a separate problem.

## Sources

- https://github.com/sigstore/cosign
- https://github.com/sigstore/policy-controller
- https://github.com/in-toto/attestation
- https://github.com/slsa-framework/slsa-github-generator
- https://github.com/chainguard-dev/apko
- https://github.com/ossf/scorecard

## Linked notes

- [[domains/ci-cd/ci-pipeline-architect]] — applies
- [[domains/security/secrets-architecture-designer]] — see-also

<!-- skg-attribution:
  vault_path: "domains/security/artifact-signing-and-verification-designer.md"
  skill_id: "019e91f9-6294-7161-8cbf-d3b7d0ae7fc7"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "7586ee928a4aa49953b794e57ba2c8026e8b2df90e598bc89113a2edfc95a21b"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:07.961703Z -->
