---
id: jane-demo/jane-neuron-0
version: 1.0.0
name: Jane Neuron 0
description: A test skill describing Jane Neuron 0.
category: engineering
tags: ['jane']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: memory_neuron
parent_occupation_id: occ-creator/ai-devops-engineer-it
links:
  - target: base/ci-pipeline-architect
    relation: applies
neuron:
  situation: 'Production incident at 3am.'
  decision: 'Roll back the deploy + write the runbook.'
  outcome: '15-min impact; runbook reused 3x.'
  recorded_at: '2024-10-15'
  confidence: 'high'
---

## When to use

Use this skill when Jane Neuron 0 applies.

## How to apply

1. Read the spec.
2. Apply it.

## Linked notes

- [[base/ci-pipeline-architect]] — applies

<!-- skg-attribution:
  vault_path: "personas/jane-demo/jane-incident-it/neurons/jane-neuron-0.md"
  skill_id: "019e91fe-649f-7e22-8dcc-5fe057c00d5b"
  version: "1.0.0"
  kind: "memory_neuron"
  creator_handle: "jane-demo"
  content_hash: "85a86a2227b10b65c6952d039010612432fa999b8632546a5523f0a8cbc00529"
  built_at: "2026-01-01T00:00:00Z"
-->
