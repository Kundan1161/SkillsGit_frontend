# Index — AI DevOps (compose)

## Base methodology

### incident

**Core**

- [[domains/incident/ops-runbook-generator]] — Ops Runbook Generator
- [[domains/incident/ops-incident-commander]] — Ops Incident Commander


### observability

**Core**

- [[domains/observability/alert-policy-architect]] — Alert Policy Architect


## Personas

_None bundled in this base build. Composition adds personas at delivery time — see `vault.json` after composition._

<!-- license:00d131aca09c61e4 buyer:86164b1ee0c7f56d ts:2026-06-04T09:37:08.908077Z -->
