---
id: curator-handle/observability-dashboard-architect
version: 1.0.0
name: Observability Dashboard
description: A test skill describing Observability Dashboard.
category: engineering
tags: ['observability']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: skill
---

## When to use

Use this skill when Observability Dashboard applies.

## How to apply

1. Read the spec.
2. Apply it.

<!-- skg-attribution:
  vault_path: "domains/observability/observability-dashboard-architect.md"
  skill_id: "019e91fe-6444-7de2-b6c6-54473254e798"
  version: "1.0.0"
  kind: "skill"
  creator_handle: "curator-handle"
  content_hash: "fe20b63be5d57f9f0c077823b33236cc0f448d42d76fd9859311d2f2743afda7"
  built_at: "2026-01-01T00:00:00Z"
-->
