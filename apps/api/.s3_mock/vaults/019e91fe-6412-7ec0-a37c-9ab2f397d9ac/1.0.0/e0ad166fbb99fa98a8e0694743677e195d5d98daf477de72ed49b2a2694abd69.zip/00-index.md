# Index — AI DevOps Engineer (demo)

## Base methodology

### ci-cd

**Core**

- [[domains/ci-cd/ci-pipeline-architect]] — CI Pipeline Architect


### incident

**Core**

- [[domains/incident/ops-runbook-generator]] — Ops Runbook Generator


### observability

**Core**

- [[domains/observability/alert-policy-architect]] — Alert Policy Architect


## Personas

_None bundled in this base build. Composition adds personas at delivery time — see `vault.json` after composition._
