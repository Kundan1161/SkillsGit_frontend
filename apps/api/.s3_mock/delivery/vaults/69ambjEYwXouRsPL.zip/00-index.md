# Index — AI DevOps (compose)

## Base methodology

### incident

**Core**

- [[domains/incident/ops-runbook-generator]] — Ops Runbook Generator
- [[domains/incident/ops-incident-commander]] — Ops Incident Commander


### observability

**Core**

- [[domains/observability/alert-policy-architect]] — Alert Policy Architect


## Personas

_None bundled in this base build. Composition adds personas at delivery time — see `vault.json` after composition._

<!-- license:c5d2f2024a385834 buyer:14220e798dd1dd72 ts:2026-06-04T09:37:08.905360Z -->
