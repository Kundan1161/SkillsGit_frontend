# Index — AI DevOps (compose)

## Base methodology

### incident

**Core**

- [[domains/incident/ops-runbook-generator]] — Ops Runbook Generator
- [[domains/incident/ops-incident-commander]] — Ops Incident Commander


### observability

**Core**

- [[domains/observability/alert-policy-architect]] — Alert Policy Architect


## Personas

_None bundled in this base build. Composition adds personas at delivery time — see `vault.json` after composition._

<!-- license:3031fda922f68e54 buyer:904fef234b1af57f ts:2026-06-04T09:37:08.860184Z -->
