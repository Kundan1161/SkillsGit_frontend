---
id: occ-compose/ops-incident-commander
version: 1.0.0
name: Ops Incident Commander
description: A test skill describing Ops Incident Commander.
category: engineering
tags: ['ops']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: skill
---

## When to use

Use this skill when Ops Incident Commander applies.

## How to apply

1. Read the spec.
2. Apply it.

<!-- skg-attribution:
  vault_path: "domains/incident/ops-incident-commander.md"
  skill_id: "019e91fe-64e9-72a0-9863-6800ea8205fb"
  version: "1.0.0"
  kind: "skill"
  creator_handle: "occ-compose"
  content_hash: "ebcc50e27f82a8e83b637eb5dd08471150f5b3970b03e3a590ab1ed370142794"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:3031fda922f68e54 buyer:904fef234b1af57f ts:2026-06-04T09:37:08.860202Z -->
