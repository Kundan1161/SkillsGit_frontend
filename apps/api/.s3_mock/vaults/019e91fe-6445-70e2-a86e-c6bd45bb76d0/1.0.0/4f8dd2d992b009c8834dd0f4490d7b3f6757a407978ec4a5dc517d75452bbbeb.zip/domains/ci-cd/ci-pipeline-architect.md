---
id: curator-handle/ci-pipeline-architect
version: 1.0.0
name: CI Pipeline Architect
description: A test skill describing CI Pipeline Architect.
category: engineering
tags: ['ci']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: skill
---

## When to use

Use this skill when CI Pipeline Architect applies.

## How to apply

1. Read the spec.
2. Apply it.

<!-- skg-attribution:
  vault_path: "domains/ci-cd/ci-pipeline-architect.md"
  skill_id: "019e91fe-6441-7c23-a87c-cc76941b6970"
  version: "1.0.0"
  kind: "skill"
  creator_handle: "curator-handle"
  content_hash: "9937664532ad66ac917bca71b5d511acb17718a49f3894052ad77ee25e8cc7da"
  built_at: "2026-01-01T00:00:00Z"
-->
