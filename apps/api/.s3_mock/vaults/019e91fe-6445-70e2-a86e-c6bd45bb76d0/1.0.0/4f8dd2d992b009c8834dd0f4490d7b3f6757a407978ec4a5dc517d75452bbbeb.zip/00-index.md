# Index — AI DevOps Engineer (integration)

## Base methodology

### ci-cd

**Core**

- [[domains/ci-cd/ci-pipeline-architect]] — CI Pipeline Architect
- [[domains/ci-cd/gha-workflow-optimizer]] — GHA Workflow Optimizer


### iac

**Core**

- [[domains/iac/k8s-manifest-reviewer]] — K8s Manifest Reviewer


### incident

**Core**

- [[domains/incident/ops-incident-commander]] — Ops Incident Commander


### observability

**Core**

- [[domains/observability/observability-dashboard-architect]] — Observability Dashboard


## Personas

_None bundled in this base build. Composition adds personas at delivery time — see `vault.json` after composition._
