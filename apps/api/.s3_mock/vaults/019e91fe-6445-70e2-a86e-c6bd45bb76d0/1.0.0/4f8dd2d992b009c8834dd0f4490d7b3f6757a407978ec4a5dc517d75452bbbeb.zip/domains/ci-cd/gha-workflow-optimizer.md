---
id: curator-handle/gha-workflow-optimizer
version: 1.0.0
name: GHA Workflow Optimizer
description: A test skill describing GHA Workflow Optimizer.
category: engineering
tags: ['gha']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: skill
---

## When to use

Use this skill when GHA Workflow Optimizer applies.

## How to apply

1. Read the spec.
2. Apply it.

<!-- skg-attribution:
  vault_path: "domains/ci-cd/gha-workflow-optimizer.md"
  skill_id: "019e91fe-6442-7400-9583-b6fb4ac90de5"
  version: "1.0.0"
  kind: "skill"
  creator_handle: "curator-handle"
  content_hash: "09ed3fe0b4c1cfdec401973bdc352c2705c00057fc11b16f66a23608e31144af"
  built_at: "2026-01-01T00:00:00Z"
-->
