# Jane Devops (integration) — v1.0.0

> A persona overlay by @jane-demo. Integration testing

## What's in this overlay

- 3 memory neuron(s) recording real situations, decisions, and outcomes.

## About the practitioner

Jane's persona for integration tests.

## Attribution

This persona was assembled at 2026-01-01T00:00:00Z by Skills Git.
- `@jane-demo/jane-incident-it` v1.0.0

See `persona.json` for the machine-readable manifest fragment. Composition merges this overlay into the parent occupation vault at delivery time.
