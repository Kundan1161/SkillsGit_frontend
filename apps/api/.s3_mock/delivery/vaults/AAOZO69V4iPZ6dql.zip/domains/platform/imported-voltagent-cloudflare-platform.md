---
id: skillsgit-curated/imported-voltagent-cloudflare-platform
version: 1.0.1
name: Cloudflare Platform Overview
description: Decision trees for picking the right Cloudflare product — Workers, Pages,
  storage (KV/D1/R2), AI (Workers AI, Vectorize, Agents SDK), networking, security,
  media, analytics, and infrastructure-as-code.
authors:
- name: Cloudflare
  handle: cloudflare
  role: author
- name: skillsgit Curated
  handle: skillsgit-curated
  role: maintainer
category: engineering
tags:
- imported
- source-voltagent
- cloudflare
- platform
- product-selection
- architecture
links:
- target: imported-voltagent-cloudflare-workers-best-practices
  relation: extends
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  min_context_tokens: 32000
  estimated_tokens_per_invocation: 6000
trigger_keywords:
- cloudflare platform
- which cloudflare product
- workers vs pages
- kv vs d1
- vectorize
- ai gateway
example_invocations:
- Help me pick the right Cloudflare product for a real-time chat app
- Which storage option fits my use case best?
- Compare Workers AI, Vectorize, and AI Gateway
inputs: []
outputs: []
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Imported from VoltAgent/awesome-agent-skills under Apache-2.0.
kind: skill
distribution:
  content_hash: e5299302a5202f5f34485f8a9d106e9fe9d6ab5b4b07a070c1d1e9de6cca1642
  signed_at: '2026-06-04T09:34:38.122766Z'
  signed_by: marketplace
  signature: 6c3f261d1278eefdeeedeb19aa8e6381cbe38900816a8ff3bb40e304782fad06
---

# Cloudflare Platform Skill

Consolidated skill for building on the Cloudflare platform. Use decision trees below to find the right product, then load detailed references.

## When to use

Use this skill for any Cloudflare development task where you need to pick between products — compute, storage, AI, networking, security, media, analytics, or IaC.

## How to apply

Your knowledge of Cloudflare APIs, types, limits, and pricing may be outdated. **Prefer retrieval over pre-training** — the references in this skill are starting points, not source of truth. When a reference file and the docs disagree, **trust the docs**.

## Retrieval Sources

| Source | How to retrieve | Use for |
|--------|----------------|---------|
| Cloudflare docs | https://developers.cloudflare.com/ | Limits, pricing, API reference, compatibility |
| Workers types | `npm pack @cloudflare/workers-types` | Type signatures, binding shapes |
| Wrangler config schema | `node_modules/wrangler/config-schema.json` | Config fields, binding shapes |
| Product changelogs | https://developers.cloudflare.com/changelog/ | Recent changes, deprecations |

## Decision Tree: "I need to run code"

```
├─ Serverless functions at the edge → Workers
├─ Full-stack web app with Git deploys → Pages
├─ Stateful coordination/real-time → Durable Objects
├─ Long-running multi-step jobs → Workflows
├─ Run containers → Containers
├─ Multi-tenant (customers deploy code) → Workers for Platforms
├─ Scheduled tasks (cron) → Cron Triggers
├─ Lightweight edge logic (modify HTTP) → Snippets
├─ Process Worker execution events → Tail Workers
└─ Optimize latency to backend → Smart Placement
```

## Decision Tree: "I need to store data"

```
├─ Key-value (config, sessions, cache) → KV
├─ Relational SQL → D1 (SQLite) or Hyperdrive (existing Postgres/MySQL)
├─ Object/file storage (S3-compatible) → R2
├─ Versioned file trees → Artifacts
├─ Message queue (async processing) → Queues
├─ Vector embeddings (AI/semantic search) → Vectorize
├─ Strongly-consistent per-entity state → Durable Objects storage
├─ Secrets management → Secrets Store
├─ Streaming ETL to R2 → Pipelines
└─ Persistent cache (long-term) → Cache Reserve
```

## Decision Tree: "I need AI/ML"

```
├─ Run inference (LLMs, embeddings, images) → Workers AI
├─ Vector database for RAG/search → Vectorize
├─ Build stateful AI agents → Agents SDK
├─ Gateway for any AI provider (caching, routing) → AI Gateway
└─ AI-powered search widget → AI Search
```

## Decision Tree: "I need networking"

```
├─ Expose local service to internet → Tunnel
├─ TCP/UDP proxy (non-HTTP) → Spectrum
├─ WebRTC TURN server → TURN
├─ Private network connectivity → Network Interconnect
├─ Optimize routing → Argo Smart Routing
└─ Real-time video/audio → RealtimeKit or Realtime SFU
```

## Decision Tree: "I need security"

```
├─ Web Application Firewall → WAF
├─ DDoS protection → DDoS
├─ Bot detection/management → Bot Management
├─ API protection → API Shield
├─ CAPTCHA alternative → Turnstile
└─ Credential leak detection → WAF (managed ruleset)
```

## Decision Tree: "I need media/content"

```
├─ Image optimization/transformation → Images
├─ Video streaming/encoding → Stream
├─ Browser automation/screenshots → Browser Rendering
└─ Third-party script management → Zaraz
```

## Decision Tree: "I need analytics"

```
├─ Query across all CF products → GraphQL Analytics API
├─ Custom high-cardinality metrics → Analytics Engine
├─ Client-side (RUM) performance → Web Analytics
├─ Workers Logs and debugging → Observability
└─ Raw logs (external tools) → Logpush
```

## Decision Tree: "I need infrastructure-as-code"

```
└─ Pulumi, Terraform, or REST API
```

## Best Practices

1. Always retrieve current docs before citing limits, pricing, or API signatures.
2. Use bindings instead of REST calls for in-platform resources.
3. Prefer JSON config (`wrangler.jsonc`) over TOML for new features.
4. Run `wrangler types` after config changes.
5. Use environments to separate staging/production.

## Attribution

This skill was imported from `VoltAgent/awesome-agent-skills` under the MIT license, originating from the `cloudflare/skills` repository under the Apache-2.0 license. Original content authored by the listed contributor(s) at the source repository. Modifications by skillsgit: frontmatter normalization to fit marketplace spec; addition of attribution and sources sections.

## Sources reviewed

- https://github.com/VoltAgent/awesome-agent-skills (MIT)
- https://github.com/cloudflare/skills/tree/main/skills/cloudflare (Apache-2.0)

## Linked notes

- [[domains/ci-cd/imported-voltagent-cloudflare-workers-best-practices]] — extends

<!-- skg-attribution:
  vault_path: "domains/platform/imported-voltagent-cloudflare-platform.md"
  skill_id: "019e91f9-6ace-7f30-84d4-66aa782fff0d"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "d82e2aea4d6a6465ae7af4d2949bfd59e8dcc8a5518db2aefc5a23ceafead7d6"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:07.961529Z -->
