---
id: jane-compose/jane-neuron-rollback
version: 1.0.0
name: Jane rollback at 3am
description: A test skill describing Jane rollback at 3am.
category: engineering
tags: ['jane']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: memory_neuron
parent_occupation_id: occ-compose/ai-devops-compose
links:
  - target: base/ops-runbook-generator
    relation: applies
neuron:
  situation: 'Pager fired at 3am.'
  decision: 'Followed the rollback runbook.'
  outcome: '10-min impact; no escalation.'
  recorded_at: '2024-10-15'
  confidence: 'high'
---

## When to use

Use this skill when Jane rollback at 3am applies.

## How to apply

1. Read the spec.
2. Apply it.

## Linked notes

- [[base/ops-runbook-generator]] — applies

<!-- skg-attribution:
  vault_path: "personas/jane-compose/jane-incident-compose/neurons/jane-neuron-rollback.md"
  skill_id: "019e91fe-6521-70e2-8b7d-e36b4b5d5d2e"
  version: "1.0.0"
  kind: "memory_neuron"
  creator_handle: "jane-compose"
  content_hash: "65c8de416d6b52600e226ae6d8eb296a67f2f9c8a55ba476b91802d77ea13608"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c5d2f2024a385834 buyer:14220e798dd1dd72 ts:2026-06-04T09:37:08.905396Z -->
