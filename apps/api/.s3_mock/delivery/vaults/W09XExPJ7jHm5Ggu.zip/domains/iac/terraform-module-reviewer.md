---
id: skillsgit-curated/terraform-module-reviewer
version: 1.0.1
name: Terraform Module Reviewer
description: Audit a Terraform module or codebase for naming, variable design, state
  hygiene, security defaults, drift handling, and version pinning — output a triaged
  review.
authors:
- name: skillsgit Curated
  handle: skillsgit-curated
  role: author
category: engineering
tags:
- niche:devops-iac
- terraform
- infrastructure-as-code
- code-review
- cloud
- security
- opentofu
- module-design
links:
- target: k8s-manifest-reviewer
  relation: see-also
- target: secrets-architecture-designer
  relation: see-also
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gpt-4.1
  - gemini-1.5-pro
  tools_required:
  - file_io
  tools_optional:
  - web_search
  min_context_tokens: 32000
  estimated_tokens_per_invocation: 7000
trigger_keywords:
- review terraform
- audit terraform module
- terraform code review
- tf module review
- iac review
- terraform best practices check
- hcl review
- opentofu module audit
- terraform module audit
- check my terraform
- terraform security review
- terraform variable design
example_invocations:
- Review this Terraform module for an AWS VPC — flag anything off about variables,
  defaults, or outputs.
- Audit our infra/ directory; we're getting drift every Monday and I want to know
  why.
- Is this module ready to publish to the registry? What would a maintainer reject?
inputs:
- name: terraform_code
  type: text
  required: true
  description: HCL source (one file, several files, or a module tree). Provide README
    and examples if available.
- name: provider_targets
  type: choice
  required: false
  description: Primary cloud or provider — guides idiom-specific checks.
  choices:
  - aws
  - azurerm
  - google
  - kubernetes
  - helm
  - multi
  - other
- name: usage_context
  type: text
  required: false
  description: Where this module is used (root module, shared module, registry publication,
    monorepo, polyrepo).
- name: known_issues
  type: text
  required: false
  description: Existing pain points the author wants the review to look at first.
outputs:
- name: review_report
  type: markdown
  description: Triaged findings — blockers, majors, minors, nits — with file path
    and line range per finding plus a "publishability" verdict.
- name: findings_json
  type: json
  description: Machine-readable findings list for ingestion by review-bots or comment
    renderers.
kind: skill
distribution:
  content_hash: 9e827e2aad7d48c51ccc9dc6e8ac16e709051f8dbad8c15b290f6b5aaf6491ef
  signed_at: '2026-06-04T09:34:37.942113Z'
  signed_by: marketplace
  signature: b6348d6bed54e4c07403a1a0c9d2939136105d2cfa7094094bb1a9ca2bf1e8a9
---

# Terraform Module Reviewer

## When to use

Use this skill when a developer hands you Terraform (or OpenTofu) source — a single module, a directory tree, a root configuration — and asks for a review. Triggers include: a module is about to be published to a registry; a team is consolidating ad-hoc resources into a shared module; a long-running root configuration produces drift no one can explain; a security or platform team is auditing infrastructure before a compliance milestone; an engineer is taking over an unfamiliar codebase and wants a tour with notes.

The skill is appropriate for HCL written against any major provider (AWS, Azure, GCP, Kubernetes, plus the long tail of community providers). It is appropriate whether the code uses Terraform Cloud, Terraform Enterprise, self-managed remote state, OpenTofu, or local state. The advice generalizes; provider-specific nuance is layered on top.

It is not appropriate for: writing brand-new modules from scratch (that's a generation task, not a review); deep policy authoring in Sentinel or OPA (those have their own tooling); or production debugging of a specific failing apply (that's a debugging task and benefits from the actual error and state, not just the code). For those, prefer dedicated tools.

The bar the skill applies is "would the registry maintainers, the platform team, and the on-call all be happy to inherit this?" Not "would this terraform apply succeed?" — many disastrous modules apply successfully.

## Inputs

| Input | Required | Purpose |
| --- | --- | --- |
| `terraform_code` | yes | The HCL source under review. |
| `provider_targets` | no | Cloud provider for idiom-specific checks. |
| `usage_context` | no | Whether this is a registry module, a shared internal module, or a root config. |
| `known_issues` | no | Author's stated pain points. |

## How to apply

The agent walks the codebase deterministically. Each stage produces structured findings; the final stage ranks and renders them.

### Stage 1 — Frame the module

1. Read every file in the input. Build a map of the module structure: where `main.tf` is, where `variables.tf`, `outputs.tf`, `versions.tf`, `locals.tf`, `data.tf` are; whether there are submodules under `modules/`; whether there are examples under `examples/`; whether there are tests under `tests/` or `test/`.
2. Determine whether this is a **root module** (it owns the state and is applied directly), a **shared module** (consumed by other code), or a **registry-publishable module** (it must satisfy strict structure rules). The remainder of the review weights the rules accordingly.
3. Identify the providers in use, the versions pinned, and the Terraform/OpenTofu version constraint. If any of these are missing, that is the first finding.
4. Identify the resources created. Group them by service (networking, IAM, compute, storage). The grouping helps the reviewer reason about blast radius and module boundaries.
5. Read the README if present. Compare what it claims against what the code does. Mismatches are documentation drift.

### Stage 2 — Standard module structure

6. Check the standard module structure. A registry-publishable module has, at minimum, `main.tf`, `variables.tf`, `outputs.tf`, a `README.md`, an explicit `versions.tf` block with `required_version` and `required_providers`, and (recommended) an `examples/` directory. Internal modules can be more flexible, but the bar for "publishable" is firm.
7. Check that `main.tf` does not become a kitchen sink. A 1500-line `main.tf` is a smell; split by resource family (one file per service is a sane heuristic).
8. Check that `variables.tf` declares every variable used in the module (no implicit defaults from external sources) and that `outputs.tf` is the single declaration site for outputs.
9. Check that the module does not embed provider configuration blocks unless it must (e.g., aliased providers). A module that hardcodes `provider "aws" { region = "us-east-1" }` breaks composability; provider config belongs in the root.
10. Check that submodules are referenced by relative path within the same repo (`./modules/network`) and not by remote ref to themselves — circular indirection is a real bug we have seen.

### Stage 3 — Variables design

11. For every variable: does it have a `description`? Is the description more than a paraphrase of the name? "vpc_cidr — the vpc cidr" is no description. Each unannotated variable is a Minor finding.
12. For every variable: does it have a `type` declared? Untyped variables accept anything; `any` should be rare and motivated. Each untyped variable is a Minor; each variable typed `any` without a comment justifying it is a Major.
13. For every variable: is the default sensible, and is it the safer default? A variable that gates "destroy on delete" should default to `false`, not `true`; a "publicly accessible" toggle should default to `false`. Defaults that bias toward danger are Major findings.
14. For every variable: does it have a `validation` block when constraints are knowable? CIDR ranges, environment names, region whitelists, length limits — all can be enforced at plan time. Absent validation where it would help is a Minor.
15. Are variables grouped logically (in the file and in the README)? Required variables first, then optional, then advanced. A flat alphabetical list reads poorly for consumers.
16. Is the variable surface small enough to use? A module with 90 variables is a configuration framework, not a module. Recommend splitting into submodules where the variable count exceeds about 25 for general-purpose modules. Major if the surface clearly grew by accretion.
17. Are sensitive variables marked `sensitive = true`? Passwords, API keys, private keys, connection strings, anything that should not show up in `terraform plan` output. Each unmarked sensitive is a Blocker.

### Stage 4 — Outputs design

18. For every output: is the value meaningful for callers? Outputs that re-emit user inputs are noise; outputs that emit computed identifiers (ARNs, IDs, endpoints, DNS names) earn their keep.
19. For every output: is sensitive data marked `sensitive`? An output that leaks a generated password fails plan-output review.
20. Are outputs complete? If the module creates a database, a caller almost certainly wants the endpoint, the port, the database identifier, and the security-group ID. Missing common outputs are Minor.
21. Is there at least one output that lets a caller chain modules? "All resources are created with no outputs" is a smell — chaining is the point of modules.

### Stage 5 — Locals, data sources, and expressions

22. Are `locals` used to name expensive or repeated expressions? Repeated `lookup(var.x, key, default)` invocations should be locals. Repetition is a Minor.
23. Are `data` sources used for runtime lookups that don't change per apply (AMI lookup, account ID, available AZs)? Good. Are they used for values that change between plans and risk drift (live read of a mutable field)? Bad — use a variable.
24. Are conditional expressions readable? Nested ternaries beyond one level are a Minor; rewrite using `locals` with named intermediates.
25. Is `count` used where `for_each` would be safer? `count` on a list whose middle element gets removed shuffles addresses and destroys downstream resources; `for_each` keyed by a stable identifier does not. Each `count` over a mutable list is a Major.
26. Are `for_each` keys stable? Keys derived from the resource's own attributes create planning loops; keys must come from input values or fixed strings.

### Stage 6 — Resource design

27. Are resource names consistent and descriptive? The pattern `aws_xxx.this` for single-instance resources and `aws_xxx.by_name["..."]` for many is a widely-adopted convention; deviation is a Nit unless it's misleading.
28. Are tags applied consistently? Every taggable resource gets the same baseline tag set (environment, owner, cost center, application). Modules should accept `tags = map(string)` and merge with module-internal defaults. Missing tag-merge is a Major.
29. Are `lifecycle` blocks used intentionally? `prevent_destroy = true` on a stateful resource is good; `ignore_changes = all` is a code smell that hides drift — flag every wide `ignore_changes` as a Major and ask whether a narrower attribute list works.
30. Are dependencies explicit? `depends_on` is needed only when the relationship is invisible to Terraform's graph (e.g., IAM-then-API-call). Overuse is a Minor; missing where required is a Blocker if it causes ordering bugs.
31. Are timeouts set on resources with slow lifecycles (RDS, EKS, large IAM applies)? Defaults are sometimes too aggressive or too lax for a given environment. Missing is a Minor.

### Stage 7 — Security defaults

32. Storage encryption: every persistent storage resource (S3 bucket, EBS volume, RDS instance, Azure storage account, GCS bucket) has encryption enabled by default. Missing is a Blocker.
33. Public exposure: every network-facing resource is private by default. An S3 bucket with public ACLs, a security group with `0.0.0.0/0` on a non-public port, a NACL with broad allow rules — each is a Blocker unless explicitly opted into via a documented variable.
34. IAM principle: IAM policies use least privilege. Wildcards on `Action` or `Resource` in an inline policy are Major unless documented. Trust relationships allow only the principals that must assume the role.
35. Secrets handling: no secret values appear in code. References to a secret manager (AWS Secrets Manager, Azure Key Vault, GCP Secret Manager, Vault) are fine; literals are a Blocker.
36. Logging: audit logging is enabled where the provider supports it (S3 access logs, RDS slow logs, VPC flow logs, CloudTrail, Azure Monitor diagnostic settings). Missing is a Major.
37. TLS: where the resource handles network traffic and supports TLS, TLS is enabled and minimum version is at least 1.2 (1.3 preferred). Permissive cipher suites are a Major.
38. Backup: stateful resources have backup enabled (RDS automated backups, EBS snapshots, S3 versioning where appropriate, Azure Recovery Services). Missing is a Major for any production-grade module.
39. Public networking: defaults exclude public IPs where the workload does not need them. ECS tasks defaulting to `assign_public_ip = true` is a Major.

### Stage 8 — Version pinning and dependency hygiene

40. Provider versions are pinned with a `~>` constraint to a specific minor (`~> 5.40`) or with an explicit range. Missing version constraints on providers are a Blocker for publishable modules.
41. The Terraform `required_version` is set. `required_version = ">= 1.5.0"` is fine; missing is a Major.
42. Modules sourced from external registries are pinned to a specific version, not floating on `main`. A floating module ref is a supply-chain risk and is a Blocker for production code.
43. Modules sourced from Git are pinned to a tag or commit SHA, not to a branch. A branch ref is a time bomb.
44. There is a renovation strategy. Either a Dependabot/Renovate config exists, or the README documents the manual cadence. Absent renovation is a Minor.

### Stage 9 — State hygiene

45. Backend configuration is explicit and not pinned to a personal account. The backend uses a remote store (S3+DynamoDB, Azure Storage, GCS, Terraform Cloud) with state locking. Local-state-in-production is a Blocker for non-trivial codebases.
46. State files are not committed to the repository. A `terraform.tfstate` in the diff is a Blocker.
47. Workspace strategy is documented. If `terraform workspace` is used, the README explains the model. If workspaces aren't used and environments are separated by directory, that's documented too. Implicit conventions are a Minor.
48. Sensitive outputs are not stored in state without `sensitive = true` markers. State files contain secrets; the marker at least prevents accidental dumps.
49. `terraform import` flows are documented for any pre-existing resources the module is expected to adopt. Missing import documentation is a Minor.

### Stage 10 — Drift, plan stability, and idempotence

50. Apply, then plan immediately. Plan should be empty. The agent infers from the code whether this property likely holds; flag patterns that break it. Common offenders: data sources that read mutable cloud fields and feed them into resources; resources whose names are derived from `uuid()` or `timestamp()`; `random_*` resources without `keepers` so they regenerate.
51. Beware of "computed-only" attributes referenced in resources upstream — these create false diffs on every plan. Flag any such reference.
52. Flag `null_resource` with `triggers` that reference values that change every plan. They run every apply, which is rarely the intent.
53. Flag provisioners (`local-exec`, `remote-exec`) unless they're the explicit fallback the provider's documentation recommends. Provisioners are last-resort and resist idempotency; a module that relies on them should be redesigned.
54. Flag heavy use of `terraform_data` (formerly `null_resource`) as a sign of "we couldn't model this cleanly."

### Stage 11 — Module composition and reusability

55. The module accepts inputs at the right level of abstraction. A network module that takes a list of subnet CIDRs is reusable; a network module that takes 47 booleans for individual VPC features is not.
56. The module does one thing. A module that creates a VPC and also configures Datadog monitoring is two modules; recommend splitting.
57. The module does not bake in opinions a caller cannot override. Naming prefixes, tag keys, region defaults — accept overrides.
58. The module's examples actually exercise the module. An `examples/simple` and `examples/complete` (one minimal, one with all options) is the gold standard. Examples that don't compile against the current module are a Major.
59. The module exposes a stable interface. Renamed variables and outputs are breaking changes; the changelog acknowledges them; the version bumps major. Hidden breakage is a Blocker on a published version.

### Stage 12 — Testing strategy

60. There is at least one test. `terraform test`, Terratest, kitchen-terraform, or a custom harness. Untested infrastructure modules are a Major for any module that will be reused.
61. Tests cover at least the canonical example. A test that only runs `terraform validate` is a starting line, not a finish.
62. Tests run in CI on every PR. A test that only the author runs locally is a vestigial test.
63. Destructive tests use ephemeral accounts or sub-accounts. Tests that touch production-shared state are a Blocker.

### Stage 13 — Documentation

64. The README documents at minimum: purpose, requirements, providers, inputs, outputs, examples, and a usage snippet. Missing README is a Blocker for publication.
65. `terraform-docs` (or equivalent) is used to keep the inputs/outputs tables in sync with the code. Stale tables are a Minor.
66. The README documents the upgrade path between major versions. Modules that change shape without an upgrade note force every caller to read the diff.
67. The README documents the destroy story for stateful resources (which resources have `prevent_destroy`, what manual cleanup is required).
68. Deprecated variables and outputs are marked with a comment and a removal version, not silently removed.

### Stage 14 — Severity assignment

69. Assign each finding one of: **Blocker** (the module is dangerous to merge — data loss, secret leak, public exposure, broken state, missing publishable structure), **Major** (likely to bite the team within 90 days — drift, missing tests, weak defaults, missing observability), **Minor** (small defect — naming, documentation, repeated expressions), **Nit** (style, ordering, taste).
70. When in doubt, pick the lower severity. Loud reviewers are ignored; targeted reviewers are read.
71. Cap nits at 8 in the rendered output. Summarize the tail in one bullet.

### Stage 15 — Compose the report

72. Lead with a one-paragraph summary: what the module does (as you understood it), the headline counts (`2 blockers, 7 majors, 11 minors, 3 nits`), and a publishability verdict (Ready / Ready after blockers / Needs rework).
73. Group findings by severity. Within each severity, order by file path and then by approximate line.
74. For each finding, emit a fenced block with: severity tag, category, file and line range, "Why it matters" (one sentence), and "Suggested fix" (a small concrete change — not a rewrite).
75. End with a "What I did not check" section listing anything the inputs left ambiguous (e.g., "no example directory was provided, so example currency is unverified").
76. Produce `findings_json` in parallel for tooling consumption.

### Stage 16 — Self-check

77. Verify every "Blocker" is genuinely a blocker by the standard in step 69. Tighten if unsure.
78. Verify every "Suggested fix" is small and reversible. Multi-day refactors do not belong in line-anchored review.
79. Re-read your own report. If it has more than 30 findings, you are over-reviewing; consolidate or downgrade.
80. Re-read the README claims; ensure no finding contradicts the README without acknowledging it.

### Stage 17 — Provider-specific guardrails

When the input names a provider, layer the following per-provider checks.

81. **AWS.** S3 buckets need `block_public_access`, server-side encryption, versioning where data integrity matters; default deny on bucket policies. IAM uses least privilege and avoids `Action: "*"`. Security groups avoid `0.0.0.0/0` on ports other than 80/443 and only where the workload is intentionally public. RDS uses encryption at rest, deletion protection, automated backups, and a non-default port where feasible. KMS keys have rotation enabled. VPC flow logs are on. CloudTrail is multi-region. Default VPC is not used.
82. **Azure (azurerm).** Storage accounts disable public network access by default; min TLS 1.2; soft-delete on; container access tier appropriate. Key vault uses RBAC mode; purge protection on for production. NSGs deny inbound by default; explicit allow rules where needed. SQL servers/managed instances use TDE; vulnerability assessments wired. Diagnostic settings on for every resource that supports them. Managed identities preferred over service principal secrets.
83. **GCP (google).** Buckets use uniform bucket-level access and CMEK where required. Service accounts have minimum role grants; no `Editor` or `Owner` on a service account. Cloud SQL uses private IP only; Cloud KMS keys have rotation. VPC service controls considered for sensitive data. Audit logs (admin read, data read/write) configured at the project level. GKE uses private clusters with authorized networks.
84. **Kubernetes / Helm.** Resources include namespace scoping; no cluster-wide bindings unless intentional. Helm release `atomic` and `cleanup_on_fail` to avoid stuck state. Secrets pulled from a secret manager rather than embedded.
85. **Multi-provider.** Cross-cloud resources reference each other through outputs, not by hard-coded values. Provider aliases are explicit and named after their role (`aws.useast`, `aws.uswest`) not by index.

### Stage 18 — Anti-patterns catalog

Watch for these recurring anti-patterns and flag with high precision. Each is a Major unless noted.

A. **The mega-module.** One module that provisions an entire environment from scratch. It's tempting; it's also unmaintainable. Recommend split.
B. **The boolean farm.** Forty boolean variables that combinatorially gate behavior. Recommend a typed configuration object with `optional()` fields.
C. **The interpolation pyramid.** Locals five layers deep referencing other locals. Flatten or rename.
D. **The `ignore_changes = all`.** Drift hiding. Replace with a narrow attribute list.
E. **The string ARN.** Hardcoded ARNs that should be data lookups or variables.
F. **The unkeyed for_each.** `for_each = var.list` instead of `for_each = { for x in var.list : x.name => x }`. Set vs. map matters.
G. **The vestigial workspace.** `terraform.workspace` referenced in a module that nobody uses workspaces with. Either commit or delete.
H. **The implicit region.** A module that uses the provider's default region with no validation. Cross-region surprises follow.
I. **The forever-changing diff.** A `data` source whose value reflects mutable cloud state, feeding a resource argument. Plan is never empty.
J. **The cleanup-via-comment.** A `# TODO: remove after migration` that has been in the code for two years. Either remove or convert to a ticketed deprecation.

## Outputs

The skill returns two artifacts:

1. `review_report` (markdown) — triaged review.
2. `findings_json` (JSON) — structured findings for bot ingestion.

## Examples

**Input (placeholder):**

A 600-line module that provisions an AWS VPC, three subnet tiers, a NAT gateway, route tables, and a default security group. README is two paragraphs; no `examples/`; no `versions.tf`; one Terratest file that calls `terraform validate`.

**Agent reasoning (abbreviated):**

- Stage 1: shared module, AWS provider; resource families: networking only.
- Stage 2: missing `versions.tf` — Major; missing `examples/` — Major for publishable, Minor for shared internal.
- Stage 3: variables — 14 of them, three lack descriptions, two are typed `any` without justification, one ("allow_public") defaults to `true` — that's the dangerous default; Blocker.
- Stage 7: default SG allows `0.0.0.0/0:0-65535` egress. Egress to anywhere is conventional; ingress on the default SG is the watch. Re-read: ingress is empty, fine; flag the wide egress as a Minor with a note.
- Stage 8: `aws` provider unpinned; Blocker.
- Stage 9: backend block missing entirely (root config?); flag with the question.
- Stage 10: `data "aws_subnets"` reads live state and feeds resource `name = data.aws_subnets.example.ids[0]` — Major; plan will diff.
- Stage 12: Terratest exists but only validates — Major.

**Output (abbreviated):**

```
**Summary:** AWS VPC module; 14 variables; one Terratest stub.
**Verdict:** Needs rework before publication.
**Headline:** 2 blockers, 5 majors, 4 minors, 2 nits.

### [BLOCKER] variables: dangerous default on `allow_public`
File: variables.tf lines 34-39
Why it matters: ...
Suggested fix: ...

### [BLOCKER] versioning: provider versions are unpinned
File: versions.tf (missing)
Why it matters: ...
Suggested fix: add a versions.tf with `required_providers { aws = { source = "hashicorp/aws", version = "~> 5.40" } }` and `required_version = ">= 1.5"`.
```

## Limitations

- The skill reasons over text. Findings about runtime behavior (plan instability, drift) are flagged as hypotheses to verify with an actual `terraform plan`.
- Provider coverage is best for AWS/Azure/GCP/Kubernetes; community providers get general advice but not idiom-specific checks.
- The skill cannot run `terraform plan` or `terraform apply`. Detecting drift requires the actual state file, which is not an input.
- Policy-as-code review (Sentinel, OPA/Rego against the plan JSON) is out of scope; the skill flags missing policy gates but does not author policies.
- Cost reviews are heuristic. The skill identifies expensive shapes (NAT gateways per AZ, oversized RDS instances, unbounded autoscaling) but does not generate a forecast.
- The skill does not negotiate API contracts with neighboring teams; if your module's interface needs design review, that is a system-design task.

## Sources reviewed

- https://github.com/terraform-aws-modules/terraform-aws-vpc (Apache-2.0)
- https://github.com/aws-samples/aws-terraform-best-practices (MIT-0)
- https://github.com/aquasecurity/tfsec (MIT)
- https://github.com/aquasecurity/trivy (Apache-2.0)
- https://github.com/antonbabenko/pre-commit-terraform (MIT)
- https://github.com/tofuutils/pre-commit-opentofu (MIT)
- https://github.com/terraform-google-modules/terraform-google-kubernetes-engine (Apache-2.0)

## Linked notes

- [[domains/iac/k8s-manifest-reviewer]] — see-also
- [[domains/security/secrets-architecture-designer]] — see-also

<!-- skg-attribution:
  vault_path: "domains/iac/terraform-module-reviewer.md"
  skill_id: "019e91f9-6536-7633-b6a4-40c3e3bb7311"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "ec12f202c4047b50fbd5c85e897089a331d508c88cdef1cece5efbfe9fa51cca"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:39:34.070169Z -->
