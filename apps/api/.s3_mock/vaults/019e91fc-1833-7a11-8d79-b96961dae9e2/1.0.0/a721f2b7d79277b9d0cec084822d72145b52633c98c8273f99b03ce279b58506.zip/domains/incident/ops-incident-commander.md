---
id: skillsgit-curated/ops-incident-commander
version: 1.0.1
name: Incident Commander Sidekick
description: Real-time copilot for an on-call engineer running a live production incident
  — triage severity, coordinate parallel work streams, structure customer and internal
  comms, and decide between mitigation and rollback under pressure.
authors:
- name: skillsgit Curated
  handle: skillsgit-curated
  role: author
category: operations
tags:
- incident-response
- sre
- on-call
- incident-command
- reliability
- observability
- communications
links:
- target: ops-runbook-generator
  relation: applies
- target: alert-policy-architect
  relation: applies
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  tools_required: []
  min_context_tokens: 32000
  estimated_tokens_per_invocation: 8000
trigger_keywords:
- incident
- outage
- sev1
- sev2
- page
- on-call
- incident commander
- production down
- service degraded
- status page
- rollback
- mitigation
- war room
example_invocations:
- Production payments service is throwing 5xx on 30 percent of requests. Help me run
  this.
- Our database failover didn't promote a replica. I just got paged. What do I do first?
- I'm the IC for an active sev1. Help me structure the next status update.
inputs:
- name: incident_signal
  type: text
  required: true
  description: Initial pager alert, customer report, dashboard reading, or one-line
    description of the symptom that triggered the call.
- name: service_context
  type: text
  required: false
  description: Optional notes on the service architecture, upstream and downstream
    dependencies, recent deploys, and feature flag changes from the last 24 hours.
- name: investigation_notes
  type: text
  required: false
  description: Running notes from the responder — graphs read, hypotheses tried, log
    lines seen, who has been paged.
- name: time_in_incident
  type: number
  required: false
  description: Minutes elapsed since the incident was declared. Used to escalate urgency
    of customer communication.
outputs:
- name: triage_assessment
  type: markdown
  description: Suggested severity classification with the reasoning, and whether to
    declare, escalate, or downgrade.
- name: workstream_plan
  type: markdown
  description: A parallelized plan of investigation, mitigation, and communication
    streams with owners and the next checkpoint.
- name: comms_drafts
  type: markdown
  description: Templated drafts for the internal channel update, the status page entry,
    and the stakeholder email — each tuned to the current phase.
- name: decision_log_entry
  type: markdown
  description: A timestamped, append-only entry summarizing what was decided in the
    last cycle, ready to paste into the incident channel.
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release.
kind: skill
distribution:
  content_hash: 59ee191391583431a3aec8562a8831f541feb2fc114bd819aed1b2ccf21d2ed1
  signed_at: '2026-06-04T09:34:37.951044Z'
  signed_by: marketplace
  signature: ad86f49c2388b463b04d786b2228ae5de24563cdd2413c454528167f5aec39c5
---

## When to use

Use this skill the moment a responder is in the chaotic minutes of a live production incident and needs a calm, structured second voice. It is meant for the engineer who has just been paged, has a partial picture, and is about to make a sequence of consequential decisions while customers, executives, and teammates all want different things at the same time.

The skill is designed to run repeatedly across the life of the incident — once at declaration, again every time the situation materially changes (new symptom, hypothesis falsified, mitigation shipped, escalation), and a final time when the responder is deciding whether the incident is recoverable enough to close. It does not replace the human Incident Commander; it gives that human a checklist and a sparring partner so that nothing important gets dropped while attention is narrow.

Avoid using this skill for after-the-fact analysis (use the Postmortem Writer skill instead) or for documenting a routine, well-known operational procedure (use a Runbook Generator). This skill assumes the situation is novel enough that no playbook on the shelf cleanly applies, and that decisions are being made under time pressure.

## How to apply

The skill follows a six-phase loop that mirrors how experienced incident commanders run a call: assess, structure, communicate, investigate, decide, and either repeat or close. Each phase has explicit prompts the responder should answer before moving on.

1. **Read the signal, restate it back, and lock in shared language.** Start by paraphrasing the input symptom in one sentence using neutral, specific language. Replace vague words like "broken" or "slow" with measurable claims — "checkout API p95 latency rose from 200ms to 4.2s starting 15:42 UTC, and error rate is 18%." If the input is ambiguous, ask exactly one clarifying question — what are you observing, and where, and since when. Do not move on until the symptom is restated; misframed incidents cost the most time.

2. **Score severity using a four-dimensional rubric, not gut feel.** Evaluate each dimension on a 0–3 scale and take the maximum: scope (number of customers or workflows affected), depth (degree of degradation — partial, full, data loss), reversibility (is data being corrupted or lost as we sit here), and external visibility (do customers know yet — Twitter, status page, support tickets). A score of 3 in any single dimension is sev1; sustained 2s in two dimensions is sev2; everything else is sev3 or lower. State the score and the reason in one line.

3. **Declare explicitly and name the roles.** Even on a small team, write out who is Incident Commander, who is Communications Lead, who is Scribe, and who is the technical lead actively typing into production. If the responder is alone, say so and recommend paging at minimum a second pair of eyes — solo IC plus solo investigator is a known failure mode because the same person cannot both decide and dig. Recommend specific people only when the input names them; otherwise recommend role categories (the on-call for service X, a senior engineer from team Y).

4. **Open a dedicated channel and timeline file before anything else.** Recommend creating an incident-specific chat channel (e.g. `#inc-<short-slug>-<date>`) and a single living document or thread that will accumulate the timeline. Insist that all decisions and observations land in that one location, not scattered across DMs. The Scribe role exists to enforce this; if there is no Scribe, the IC writes timeline entries themselves, no exceptions.

5. **Generate three parallel work streams and assign owners.** A common mistake is serial work — investigate, then mitigate, then communicate — which triples the incident's customer cost. Instead structure three streams that run concurrently: **investigation** (what is happening and why), **mitigation** (what action might stop the bleeding now, even before we understand it), and **communications** (who needs to know, when, in what tone). Each stream gets one named owner. The IC is none of them; the IC supervises, blocks distractions, and arbitrates conflicts.

6. **Frame investigation as a hypothesis tournament, not a debugging session.** Ask the responder to write down up to three hypotheses for the cause, each with a falsifiable test that can be run in under five minutes. Examples: "the new deploy is the cause — test: roll back deploy ID 7c4a in canary region and watch error rate"; "the database is slow — test: query pg_stat_activity for long-running transactions." Force ranking by how quickly each can be falsified and how much it would explain. The first test executed should be the cheapest disconfirming experiment, not the one most likely to confirm a favorite theory.

7. **Apply the mitigation-versus-rollback heuristic explicitly.** When a recent deploy is suspected, default to rollback over investigation if the deploy is younger than the incident, the rollback path is well-rehearsed, and no irreversible migrations were included. When migrations are involved, switch to feature-flag disable as the first mitigation. When the suspected cause is infrastructural (cloud provider, network, certificate, DNS), there is no rollback; mitigation means failover, draining, traffic shaping, or degrading non-essential features. The decision is: would a five-minute rollback be cheaper than thirty more minutes of investigation? If yes, roll back and investigate from the restored state.

8. **Communicate before you have answers, on a fixed cadence.** Push the responder to send a first internal update within five minutes of declaration and an external status page entry within fifteen minutes for any incident at sev2 or above. The first updates do not need to contain a root cause — they need to contain three things: what customers will notice, what we are doing about it, and when we will update again. Make the next-update commitment explicit and short (30 minutes is a safe default for sev1, 60 for sev2). Missing a promised update damages trust more than slow resolution.

9. **Tune messages to three distinct audiences with different stakes.** Internal channel messages can be terse, jargon-heavy, and include hypotheses. Status page entries to customers must be factual, free of jargon, free of speculation about cause, and acknowledge the impact in plain terms. Executive or stakeholder emails should lead with business impact ("checkout is unavailable, approximately X% of revenue affected this hour"), then current actions, then ETA confidence. Never copy-paste between channels — each is a different speech act with a different reader.

10. **Watch for the four common cognitive traps and name them when they appear.** Fixation: the responder keeps looking at one dashboard because it was useful five minutes ago. Confirmation: a hypothesis is being tested only with evidence that would confirm it. Premature closure: a partial fix made the graph look better and everyone wants to declare resolved. Heroism: one engineer is doing everything and refusing handoff into a long incident. When you detect one of these patterns from the running notes, surface it explicitly and recommend a counter-move (e.g. "you have been on this call 90 minutes; rotate the IC role now").

11. **Track decisions in a structured log, separate from the timeline.** A timeline records observations ("error rate spiked at 15:42"). A decision log records choices ("at 16:05 we decided to fail traffic away from us-east-1 — owner: Alice — expected effect: error rate drops below 1% within 5 minutes — actual effect: TBD"). Every decision entry must include the expected effect and a deadline for checking whether it happened. This is the single highest-leverage habit; almost every botched incident has a moment where a decision was made and never verified.

12. **Escalate by criteria, not by feeling.** Define ahead of time which conditions trigger paging additional people: incident still open at 30 minutes, customer-visible impact crossing a threshold (e.g. 5% of users), data integrity in question, multiple regions affected, or external attention (press, social media). When any criterion fires, the IC pages the next layer — typically a senior engineer, the service owner if not already on, and eventually an executive on call. Do not wait for the responder to feel overwhelmed; by then escalation is late.

13. **Verify each mitigation against a real signal before claiming success.** When a mitigation ships, name the metric that will move and the time window in which it should. If after that window the metric has not moved, the mitigation failed regardless of how plausible it was, and you go back to step 6 with one hypothesis ruled out. Do not let plausible mitigations live unverified — they accumulate into a stack of "we tried X" with no clarity on what actually worked.

14. **Recognize when the incident is contained but not resolved, and stage down deliberately.** Containment ("the bleeding has stopped") is not resolution ("we understand and have fixed the cause"). When containment is achieved, announce it explicitly, drop the cadence of updates to a slower beat (every 60–90 minutes), but keep the channel open. Send a separate, clearly labeled "containment" status page update. Do not declare full resolution until you can articulate what changed, why it fixed the symptom, and that the change is durable across a normal traffic cycle.

15. **Run a structured close before standing down.** When resolving, prompt the responder for: (a) the single sentence customers will see in the final status page entry; (b) the owner of the postmortem; (c) the date the postmortem will be completed (default within five business days for sev1, ten for sev2); (d) any immediate followup actions that cannot wait for the postmortem (e.g. revoke a leaked credential, raise a per-host alert threshold). Push back if any of these four are missing — closing without them is how lessons are lost.

16. **Hand the running notes to the Postmortem Writer skill.** The decision log, timeline, and final close summary produced by this skill are the natural inputs to a postmortem. End the final output of an incident-closing invocation with a one-line pointer that the responder can use to kick off the writeup, including the file or thread location of the timeline.

### Output protocol per invocation

Each time the skill is invoked mid-incident, return four sections, in this order, with these exact headings:

- **Triage assessment.** Two to four sentences: restated symptom, computed severity, recommended next action in the next 10 minutes.
- **Workstream plan.** A short table or list naming the three streams (investigation, mitigation, communications), the proposed owner for each, and the single next concrete task per stream.
- **Comms drafts.** Three blocks — internal channel update (3–5 lines), status page entry (2–3 lines, jargon-free), stakeholder note (4–6 lines, business-impact framed). Mark each with the audience.
- **Decision log entry.** One timestamped paragraph in the form: "At T+\<minutes\>, decided to \<action\>. Expected effect: \<metric and direction\> within \<window\>. Verifier: \<owner\>."

Keep the total response under 600 words unless the responder asks for depth. Brevity in the middle of an incident is a service to the reader; verbosity is not.

## Inputs

- **Incident signal (required, text).** The pager alert text, the dashboard reading, or the one-line description that started this. The shorter and more recent the better.
- **Service context (optional, text).** Architectural notes, current deploy state, feature flag changes from the last 24h. Do not require this; many responders won't have time to compile it.
- **Investigation notes (optional, text).** A running scratchpad of what has already been tried. The skill uses this to avoid re-recommending discarded paths and to detect fixation.
- **Time in incident (optional, number).** Minutes since declaration. Used to escalate urgency in the communications draft and to suggest IC role rotation if the number is large.

## Outputs

Markdown, structured into the four sections defined under "Output protocol per invocation." The skill never emits free-form prose without the headings; the headings are how the responder finds the relevant section while scanning under stress.

## Examples

### Worked example: payments service partial outage

**Input incident signal:** "Payments service is throwing 502s on roughly a third of requests since 15:42 UTC. We just deployed v7.4.1 to payments at 15:30. Pager woke me up. I'm the on-call. No other engineers awake yet."

**Input service context:** "Payments calls Stripe and our risk engine. Both report healthy from their own dashboards. v7.4.1 added retries to the risk engine call. We have a feature flag, `payments.retry_v2`, default on."

**Input investigation notes:** None yet.

**Expected output:**

**Triage assessment.** Payments service returning 502 on ~33% of requests since 15:42 UTC, 12 minutes after deploy of v7.4.1 which changed retry behavior. Scope 2 (significant customer subset), depth 3 (full failure for affected users), reversibility 1 (no data corruption signal yet), external visibility 2 (customers cannot complete checkout). Severity 3 — sev1. **Next 10 minutes: roll back v7.4.1 in a canary region while simultaneously disabling `payments.retry_v2`. Do not wait for understanding.**

**Workstream plan.**

- **Investigation** — owner: you. Pull `payments.retry_v2`-tagged logs from 15:30 onward. Look for retry storms or thread pool exhaustion. Falsifiable test: if disabling the flag drops 502 rate below 2% within 3 minutes, retry logic is the cause.
- **Mitigation** — owner: you, in parallel. Step 1: disable `payments.retry_v2` via feature flag (cheaper than rollback, reversible in seconds). Step 2 if no improvement in 3 minutes: roll back v7.4.1.
- **Communications** — owner: you for now, but page a second engineer immediately to take this role. Solo IC + solo investigator is unsafe past 10 minutes.

**Comms drafts.**

*Internal channel:*
> Sev1 declared 15:54 UTC. Payments returning 502 on ~33% of requests, started 15:42, 12 min after v7.4.1 deploy. Disabling `payments.retry_v2` now. Rollback prepared as fallback. Next update in 15 min. IC: me. Need a second engineer — paging @secondary-oncall.

*Status page:*
> **Investigating** — Some customers are seeing errors when attempting to complete a payment. We are aware and are working to restore the service. Next update within 30 minutes.

*Stakeholder note:*
> Checkout is currently failing for approximately one third of customer payment attempts, starting 15:42 UTC. The likely cause is a deploy made minutes before the failures began. We are reverting changes now and expect to see improvement within 10 minutes; if not, we will roll back fully. I will update you again by 16:30 UTC regardless of state.

**Decision log entry.**

> At T+12, decided to disable `payments.retry_v2` feature flag while preparing rollback of v7.4.1. Expected effect: 502 error rate drops below 2% within 3 minutes. Verifier: on-call (me). Rollback to v7.4.0 staged and ready if flag-disable does not move the metric.

### Subsequent invocation, 8 minutes later

**Input investigation notes:** "Disabled the flag at 15:55. Error rate is still 31% at 16:03. No change. Rollback to v7.4.0 in progress, ETA 16:08. Secondary on-call (Priya) is now online and has taken the Comms role."

The skill should now detect that the first hypothesis was falsified (flag did not move the metric), confirm rollback as the correct next step, recommend that Priya post the next status-page update on schedule, and add a decision-log entry recording the falsification — so the postmortem has a clear record that the retry logic was suspected but ruled out within minutes.

## Limitations

- The skill assumes the responder has a working channel, a working status page, and the ability to ship a rollback. If those tools are themselves the incident (chat is down, status page provider is offline), the skill cannot route around that — escalate to whatever backchannel exists.
- The skill does not know your specific service architecture. It recommends categories of action ("roll back," "feature flag," "failover") that the responder must translate into the right command in their environment.
- The skill is not a substitute for a real second human. Repeated invocations are not a replacement for paging another engineer in a long incident; the rotation recommendation in step 14 is a hard rule, not an optional one.
- The skill is tuned for software incidents. Security incidents (active intrusion, data exfiltration) have different first moves — preserve evidence, contain laterally, involve legal — and are out of scope here.
- The severity rubric is opinionated. Organizations with formal sev definitions in their own runbook should treat the rubric output as a recommendation, not an override.

## Sources reviewed

- https://github.com/PagerDuty/incident-response-docs
- https://github.com/counteractive/incident-response-plan-template
- https://github.com/aws-samples/aws-incident-response-playbooks
- https://github.com/meirwah/awesome-incident-response
- https://github.com/austinsonger/Incident-Playbook
- https://github.com/PagerDuty/business-response-docs

## Linked notes

- [[domains/incident/ops-runbook-generator]] — applies
- [[domains/observability/alert-policy-architect]] — applies

<!-- skg-attribution:
  vault_path: "domains/incident/ops-incident-commander.md"
  skill_id: "019e91f9-703f-73e0-8e9b-9fa5d5c6fc24"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "b17d1b703a138c816647d128b9b68f0ee5da3c8ba5bbe1903e9595b93f50dfd0"
  built_at: "2026-01-01T00:00:00Z"
-->
