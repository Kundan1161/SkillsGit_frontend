---
id: skillsgit-curated/imported-google-skills-networking-observability
version: 1.0.1
name: Google Cloud Networking Observability
description: Investigate Google Cloud networking issues by analyzing VPC Flow Logs,
  NAT, firewall, threat logs, latency/throughput metrics, and Connectivity Tests.
authors:
- name: Google (original)
  handle: google
  role: author
- name: skillsgit Curated
  handle: skillsgit-curated
  role: maintainer
category: engineering
tags:
- imported
- source-google
- gcp
- networking
- observability
- vpc-flow-logs
links:
- target: observability-dashboard-architect
  relation: see-also
- target: ops-incident-commander
  relation: see-also
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gemini-2.0-pro
trigger_keywords:
- vpc flow logs
- firewall logs
- cloud nat
- connectivity tests
- latency
- threat logs
example_invocations:
- Investigate which firewall rule is dropping traffic to my VM.
- Find top talkers in VPC Flow Logs for the last hour.
- Run a Connectivity Test between two VMs.
inputs: []
outputs: []
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Imported from google/skills under Apache-2.0.
kind: skill
distribution:
  content_hash: acc555077dfec0e9791e040eb9c169294628521991681a790f432e0d75513cc3
  signed_at: '2026-06-04T09:34:38.068284Z'
  signed_by: marketplace
  signature: 82a6e4ce921e73201cd3d61e20a80590f89623276cc0b1414013eefbd11fc870
---

# Google Cloud Networking Observability Expert

## When to use

Use this skill when investigating Google Cloud networking issues: VPC Flow Logs, NAT logs, firewall logs, threat logs, latency/throughput metrics, or running Connectivity Tests for path diagnostics.

## How to apply

Identify which log source the question maps to. Run the minimum required query. Present the finding immediately on identification — including null/zero results — and terminate. Do not chase a "better" answer unless the user explicitly asks for troubleshooting of a resource that should be busy.

## Core Directive: Results First

1. Identify the primary source: firewall logs, threat logs, Cloud NAT, VPC Flow Logs, or metrics.
2. Execute and present: run the minimum required query.
3. Definitive termination: once you identify the requested data, regardless of value (including 0, null, or "no traffic"), present the finding and call the finish tool in the same turn. Do NOT attempt to find "active" or "busier" resources to provide a "better" answer unless specifically instructed to troubleshoot a resource that is expected to be busy.

## Log and Telemetry Overview

- Threat Logs: specialized logs from Cloud Firewall Plus and Cloud IDS that identify malicious traffic patterns (e.g., SQL injection or malware) using deep packet inspection.
- VPC Flow Logs: capture sample IP traffic to and from network interfaces. Use for traffic analysis, volume trends, and top talkers.
- Firewall Logs: record connection attempts matched by firewall rules. Use to identify DENY events or verify ALLOW rules.
- Cloud NAT Logs: audit NAT translations. Use to audit NAT gateway traffic or troubleshoot port exhaustion.
- Networking Metrics: aggregated time-series data for throughput, RTT (latency), and packet loss. Use for historical trends.
- Connectivity Tests: static analysis tool for path diagnostics. Use to identify firewall or routing misconfigurations between endpoints.

## Procedures

### 0. Log Source Preference

- Prioritize BigQuery linked datasets over Cloud Logging for high-volume analysis.
- Account for `EXCLUDE_ALL_METADATA` subnetwork configurations that may return NULL VM names.
- Retry using internal IP addresses when VM-name queries yield no results.

### 1. Tool Selection and Discovery

- Use MCP servers (Cloud Monitoring, BigQuery, Cloud Logging) first.
- Deploy `gcloud` commands for resource discovery if MCP fails.
- Apply curl templates from the metrics-analysis reference as CLI fallback.

### 2. Schema Verification and Error Recovery

Follow a three-step recovery pattern: validate schema with `bq show`, execute dry runs, then retry with corrected queries.

### 3. Analysis Guides

Six specialized reference documents in the upstream repo address threat logs, VPC flows, Cloud NAT, firewall rules, metrics, and connectivity tests. Reference them only when needed.

## Boundaries (CRITICAL)

- Present direct answers immediately upon identification.
- Limit exploratory queries to a maximum of two before reporting results.
- Avoid secondary verification without explicit user consent.
- Always print generated SQL before execution.
- Include the Flow Analyzer console link in all responses.
- Accept zero counts and null values as conclusive findings.
- Use BigQuery aggregation on `_AllLogs` datasets for volume-based discovery.
- Prohibit auxiliary scripting; execute all logic via direct tool calls.
- Treat BigQuery data as primary source of truth; do not cross-verify with Monitoring API.

## Attribution

This skill was imported from `google/skills` under the Apache-2.0 license. Original content authored by Google. Modifications by skillsgit: frontmatter normalization to fit marketplace spec; addition of attribution and sources sections; addition of `## When to use` and `## How to apply` stubs required by our validator. The original LICENSE and NOTICE files are preserved at the source repository.

## Sources reviewed

- https://github.com/google/skills/tree/main/skills/cloud/google-cloud-networking-observability (Apache-2.0)

## Linked notes

- [[domains/observability/observability-dashboard-architect]] — see-also
- [[domains/incident/ops-incident-commander]] — see-also

<!-- skg-attribution:
  vault_path: "domains/observability/imported-google-skills-networking-observability.md"
  skill_id: "019e91f9-6a44-7d22-897f-3c6ca76cd9be"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "fee9ac651664c49cb7160bc0165c4742f1e6db4754f103d58b19de65d8475b3d"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:39:34.070325Z -->
