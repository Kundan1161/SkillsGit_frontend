---
id: skillsgit-curated/alert-policy-architect
version: 1.0.0
name: Alert Policy Architect
description: A test skill describing Alert Policy Architect.
category: engineering
tags: ['alert']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: skill
---

## When to use

Use this skill when Alert Policy Architect applies.

## How to apply

1. Read the spec.
2. Apply it.

<!-- skg-attribution:
  vault_path: "domains/observability/alert-policy-architect.md"
  skill_id: "019e91fe-6411-78d3-9bee-0f23c3f51bc1"
  version: "1.0.0"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "e8ac8fd78be4d3fa7460c630eab9a622e2d69932aac91fe54e97cabbb1bb73f4"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:b7ae3081ba0f82e3 buyer:0d35f73d714c524b ts:2026-06-04T09:37:08.646000Z -->
