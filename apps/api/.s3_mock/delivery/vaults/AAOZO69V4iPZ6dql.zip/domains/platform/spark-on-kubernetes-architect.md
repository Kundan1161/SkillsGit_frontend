---
id: skillsgit-curated/spark-on-kubernetes-architect
version: 1.0.1
name: Spark on Kubernetes Architect
description: Design production Spark on Kubernetes with the right operator model,
  dynamic allocation, GPU scheduling, multi-tenant isolation, observability, and cost
  controls mapped to workload shape and cluster topology.
authors:
- name: skillsgit Curated
  handle: skillsgit-curated
  role: author
category: data
tags:
- niche:spark-on-k8s
- apache-spark
- kubernetes
- operator
- dynamic-allocation
- gpu-scheduling
- multi-tenancy
- cost-ops
links:
- target: k8s-manifest-reviewer
  relation: applies
- target: kubernetes-cost-optimizer
  relation: see-also
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gpt-4.1
  tools_required: []
  tools_optional:
  - code_execution
  - web_search
  min_context_tokens: 32000
  estimated_tokens_per_invocation: 8500
trigger_keywords:
- spark on kubernetes
- spark on k8s
- spark operator
- spark-submit kubernetes
- dynamic allocation spark
- external shuffle service
- spark gpu scheduling
- multi-tenant spark
- spark namespace isolation
- karpenter spark
- spot instances spark
- spark history server k8s
- spark observability
- spark cost optimization
example_invocations:
- We are moving Spark off YARN onto Kubernetes — design the cluster, the submission
  path, and the autoscaling story.
- Pick between the Spark Operator and direct spark-submit for our nightly ETL workload
  of 60 jobs.
- We need dynamic allocation on K8s without losing shuffle data when an executor terminates.
  What is the safe setup?
- GPU-accelerated Spark jobs share a cluster with CPU ETL. Design the scheduling and
  quota model.
- Three teams want to share one Spark-on-K8s cluster. Design the multi-tenant isolation.
inputs:
- name: workload_profile
  type: text
  required: true
  description: Job mix — batch ETL, interactive notebooks, streaming, ML training;
    counts per category; peak concurrency; typical job duration; data volumes per
    job.
- name: tenancy_model
  type: text
  required: false
  description: One team, several teams, or many teams. How isolated does each team's
    compute and data need to be? Any regulatory constraints (HIPAA, PCI, data residency).
- name: existing_kubernetes
  type: text
  required: false
  description: Existing cluster — managed (EKS, GKE, AKS) or self-hosted; node groups;
    networking; storage classes; ingress; identity provider.
- name: hardware_constraints
  type: text
  required: false
  description: Instance families available, spot vs on-demand policy, GPU availability,
    network bandwidth between nodes, S3/GCS/object-store proximity.
- name: spark_versions
  type: text
  required: false
  description: Target Spark version(s), language runtimes (Scala, PySpark), container
    image strategy, JAR distribution mechanism.
- name: observability_stack
  type: text
  required: false
  description: Existing logging, metrics, and tracing tools — Prometheus, Loki, OpenTelemetry,
    Datadog-equivalent, Spark History Server hosting, log aggregation policy.
- name: cost_targets
  type: text
  required: false
  description: Budget envelope, cost-per-job targets, chargeback expectations, and
    any executive-level constraints on infrastructure spend.
outputs:
- name: topology_design
  type: markdown
  description: Node groups, namespaces, submission path, autoscaler choice, storage
    classes, and the rationale for each.
- name: workload_placement
  type: markdown
  description: How each workload class maps onto the cluster — driver placement, executor
    placement, GPU requests, taints and tolerations, priority classes.
- name: operational_plan
  type: markdown
  description: Image build pipeline, secret distribution, observability wiring, history
    server, log retention, on-call escalation, upgrade strategy.
- name: cost_and_quotas
  type: markdown
  description: ResourceQuotas, LimitRanges, namespace-level budgets, spot policy,
    idle reaping, and the chargeback model.
- name: verification_checklist
  type: markdown
  description: Pre-production proofs — chaos test for executor loss, scaling test,
    GPU scheduling test, namespace isolation test, History Server reachability test.
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release.
kind: skill
distribution:
  content_hash: 7f23f6b13396a375fe16e5baca271e0cf49cd531030c39b176c570cde7fe54ac
  signed_at: '2026-06-04T09:34:38.083544Z'
  signed_by: marketplace
  signature: 520abe0c5b21ddf8ff4fef24db324ef751751b38148009cbbce5d3edf421c165
---

## When to use

Use this skill when a team is putting Apache Spark onto a Kubernetes cluster and needs a coherent architecture rather than a copy-pasted set of YAML files. Concrete triggers:

- Migrating from a YARN-based or VM-based Spark deployment onto Kubernetes for the first time.
- Deciding whether to adopt a Spark-on-Kubernetes operator pattern or use direct spark-submit with the Kubernetes scheduler.
- Designing dynamic allocation that survives executor preemption when running on spot instances.
- Hosting GPU-accelerated Spark jobs next to standard CPU ETL on shared infrastructure.
- Tenants are starting to step on each other — driver pods stuck in pending, executors evicted by other workloads, History Server overwhelmed.
- The cost story is unclear; finance is asking which team or job spent what.

Do not use this skill as a substitute for the per-job tuning playbook (use a Spark Job Tuner skill). Do not use it to pick a table format (use a lakehouse-table-format skill). Do not use it for streaming-specific architecture decisions where the bottleneck is the state store or sink rather than the runtime layout. Do not use it when the cluster is fixed-size, single-team, single-workload — the design value comes from sharing and scale.

## How to apply

Work the steps in order. Architecture choices in step 1 cascade into placement, observability, and cost; reversing a topology decision later is expensive.

### 1. Capture the workload portrait

1. **List every workload class.** Nightly ETL, hourly micro-batches, ad-hoc notebooks, scheduled ML training, streaming queries, on-demand reprocessing. Each class has different latency, isolation, and SLA needs.
2. **Quantify concurrency and burstiness.** Peak concurrent driver count, peak concurrent executor count, the times of day when each class spikes. A nightly ETL spike from 02:00–04:00 with 800 executors is very different from a flat 50-executor day-long footprint.
3. **Quantify job duration distribution.** Sub-minute jobs, multi-hour jobs, and indefinite streaming queries imply different cleanup and reaping policies.
4. **List data sources and sinks.** S3, GCS, ABFS, HDFS, JDBC, Kafka, on-cluster object store. Network locality matters; same-region object store is mandatory.
5. **List shuffle pressure.** Shuffle-heavy workloads (large joins, wide aggregations) constrain dynamic allocation and influence the choice of remote shuffle service.
6. **List GPU and special-hardware needs.** GPU SKUs, FPGAs, large-memory nodes. Note whether the GPU is for the executor JVM (via accelerator plugins) or for a Python worker that the executor launches.
7. **Capture failure tolerance.** A nightly ETL can rerun; a streaming query feeding fraud detection cannot. Tolerance drives node-class choice — spot for batch, on-demand for streaming.

### 2. Choose the submission path

8. **Spark Operator pattern.** A Kubernetes operator that watches a custom resource (SparkApplication / ScheduledSparkApplication) and creates the driver and executor pods. Strengths: declarative, GitOps-friendly, lifecycle is K8s-native, status surfaces in `kubectl`. Weaknesses: an extra moving piece to operate; CRD drift between Spark versions; restart semantics need care.
9. **Direct spark-submit.** Run `spark-submit --master k8s://...` from a CI runner, a workflow orchestrator, or an interactive shell. Strengths: minimal infrastructure; matches the YARN-era muscle memory; works with every Spark version. Weaknesses: no declarative state in the cluster; harder to GitOps; status surfaces only via the submitter; cleanup logic must live in the orchestrator.
10. **Hybrid.** Use the operator for scheduled production jobs and spark-submit for interactive sessions and notebook backends. The operator carries the SLA workloads where declarative state matters; ad-hoc workflows use submit.
11. **Pick on the operability axis.** If the team has Kubernetes muscle and a GitOps pipeline, prefer the operator. If the team treats Kubernetes as a black box and lives in their orchestrator, prefer direct submit with the orchestrator holding state.
12. **Document the choice.** A one-pager in the runbook with the two paths, when each applies, and how to escalate from one to the other.

### 3. Lay out node groups and namespaces

13. **Separate driver nodes from executor nodes.** Drivers need stable memory and predictable scheduling; executors are cattle. A small on-demand node group for drivers and a larger spot or mixed group for executors is the canonical split.
14. **Separate GPU nodes from CPU nodes.** Taint GPU nodes with `nvidia.com/gpu=true:NoSchedule` and only GPU jobs tolerate it. Otherwise idle CPU jobs scavenge GPU nodes.
15. **Use one namespace per tenant** for the team-isolation story. Resource quotas, RBAC, network policies, and chargeback all attach to namespaces.
16. **Reserve a shared system namespace** for the operator, History Server, monitoring, and any cluster-wide infrastructure.
17. **Pick a node autoscaler.** A node autoscaler that provisions nodes on pending-pod signal (cluster-autoscaler or a just-in-time provisioner like Karpenter) is mandatory for any non-trivial Spark cluster. Pre-scale only the driver pool; let executor pools elastic-grow.
18. **Set node-group lifetimes.** Spot-only executor pools need rapid replacement; on-demand pools can be longer-lived. Match the autoscaler's eviction policy to the workload's tolerance for executor loss.
19. **Map storage classes.** Local NVMe for shuffle spill (`emptyDir.medium: Memory` for in-RAM or block volumes for disk), object-store backed for inputs and outputs, EBS/persistent volumes only when truly required.

### 4. Decide on shuffle storage

20. **The dynamic-allocation problem.** Spark on K8s historically lost shuffle data when an executor terminated, because there was no external shuffle service to hand it off. This is the central design constraint for cost-optimized batch.
21. **Option A: shuffle tracking + graceful decommission.** Modern Spark (3.1+) supports decommissioning an executor before it dies, migrating shuffle and cached blocks to peers. Combine with `spark.decommission.enabled=true` and a sensible PreStop hook. Works well on spot fleets with reasonable termination notice.
22. **Option B: remote shuffle service.** A separate shuffle service (Apache Celeborn, Magnet-like services) writes shuffle data to a centralized store. Decouples executor lifetime from shuffle lifetime; supports aggressive scale-down and spot eviction. Adds an operational component.
23. **Option C: persistent volume per executor.** Mount a per-executor persistent volume so shuffle survives pod restart. Operationally heavy; rarely worth it on K8s.
24. **Choose on the eviction-tolerance axis.** Sub-30-second termination windows force option B. Multi-minute drain windows make option A workable. No spot at all makes shuffle storage simple.
25. **Document the chosen mode and the `spark.dynamicAllocation.*` and `spark.decommission.*` settings** in a defaults file mounted into every job.

### 5. Wire dynamic allocation

26. **Enable dynamic allocation by default.** `spark.dynamicAllocation.enabled=true`, with `shuffleTracking.enabled=true` if not using a remote shuffle service.
27. **Set sensible bounds.** `initialExecutors`, `minExecutors`, `maxExecutors`. Floors prevent cold-start lag on hot pipelines; ceilings prevent runaway cost.
28. **Tune idle timeouts.** `executorIdleTimeout` (release when idle), `cachedExecutorIdleTimeout` (release when only cached data lives there). Tighter timeouts cut cost; aggressive timeouts thrash with bursty workloads.
29. **Configure decommissioning.** `spark.decommission.enabled=true`, `spark.storage.decommission.enabled=true`, `spark.storage.decommission.shuffleBlocks.enabled=true`. Pair with a PodSpec PreStop that sends SIGTERM with a graceful window.
30. **Test eviction scenarios end-to-end.** A chaos drill that kills a random executor mid-stage and confirms the job completes is the only proof that the configuration is correct.

### 6. Place workloads onto nodes

31. **Use priority classes** to express SLA. Streaming and SLA-bound jobs get a high-priority class so they preempt batch when capacity is scarce; batch runs at a lower priority and yields.
32. **Use pod anti-affinity** for drivers — one driver per node is overkill, but spreading drivers across nodes prevents a single node failure from killing many jobs.
33. **Tolerate spot taints** on executor pods of batch workloads. Streaming pods do not tolerate spot taints and land only on on-demand nodes.
34. **Request GPUs explicitly.** `resources.limits["nvidia.com/gpu"]: 1` (or the vendor's resource name). Use the relevant device plugin and confirm topology-aware scheduling for multi-GPU jobs.
35. **Set requests and limits identically** on driver and executor containers in the steady state. Mismatched values lead to OOMKilled pods at unpredictable times.
36. **Reserve memory headroom.** Set the container memory request higher than `spark.executor.memory + spark.executor.memoryOverhead`. A 15–20% pad covers off-heap, Python workers, and JVM metaspace.

### 7. Design the image and dependency pipeline

37. **One base image per Spark major version.** Built from an official Spark base, pinned, scanned for CVEs in CI.
38. **Application JARs and Python packages baked in or fetched at submit time.** Baking gives reproducibility; fetching gives flexibility. Pick one and stick to it; mixing leads to ghost version drift.
39. **Avoid the `--packages` Maven coordinate path in production.** It hits Maven Central at submit time and fails the job when the network blips. Pre-resolve and bundle.
40. **Pin Python dependencies in a `requirements.txt`** and install them at image build, not at runtime. Use a virtualenv or `--archives` path for environments that vary per job.
41. **Sign and gate images.** Cosign-signed images and an admission webhook (Kyverno, Gatekeeper) that rejects unsigned images on the Spark namespaces.

### 8. Wire observability

42. **Metrics: enable Spark's Prometheus sink** via `spark.metrics.conf.*.sink.prometheusServlet.class`. Scrape from the driver and aggregate executor metrics into the driver namespace. Pair with a node-level exporter for host metrics.
43. **Logs: forward driver and executor stdout/stderr to the cluster log aggregator.** Tag with job id, namespace, and tenant. Retention typically 7–30 days for executor logs, longer for driver logs.
44. **Spark History Server.** Run as a dedicated deployment in the system namespace, backed by an object store (`spark.eventLog.dir=s3a://bucket/eventlogs`). Set retention so the History Server does not drown in event log files.
45. **Tracing.** Optional; pair Spark with OpenTelemetry-compatible agents only when end-to-end traces matter (e.g., reads from a traced service). Most batch shops do not need this.
46. **Alerting.** Three alert classes: stuck pending pods (driver cannot start), runaway durations (job past p99 of its baseline), and executor failure rates (cluster health regression).

### 9. Multi-tenant isolation

47. **ResourceQuotas per namespace.** Cap CPU, memory, GPU, and pod count. Quotas are the bluntest but most reliable isolation primitive.
48. **LimitRanges to enforce defaults.** Default container limits prevent a misconfigured pod from claiming an entire node.
49. **NetworkPolicies for east-west isolation.** Drivers only talk to executors in the same namespace; executors only talk to the driver and to the shuffle service. Egress to object stores and the catalog is allowed.
50. **RBAC scoped to the namespace.** Each team's CI service account can create SparkApplications in its namespace and nothing else. The operator's service account is cluster-scoped but only manages spark.* resources.
51. **PodSecurity admission level baseline or restricted.** Run-as-non-root, no privilege escalation, drop all capabilities. Privileged Spark pods are an anti-pattern.
52. **Workload-level data isolation.** S3/GCS bucket policies and per-tenant IAM roles tied to the namespace's service account via OIDC token volume projection (IRSA, workload identity, etc.). The namespace is the unit of data access.

### 10. Cost and chargeback

53. **Attribute cost to namespace by default.** Cluster cost report grouped by namespace, then by job label. This is the floor; refinements layer on.
54. **Tag every SparkApplication** with team, project, environment, and cost-center labels. These flow through to billing exports.
55. **Run spot for batch by default.** With decommissioning or a remote shuffle service, spot interruption is a non-event. Streaming and SLA work stays on-demand.
56. **Reap idle clusters.** A scheduled cleaner deletes completed SparkApplication records older than N days; the History Server keeps the event logs.
57. **Right-size drivers down.** Most jobs use 2–4 GB driver memory but request 8 GB out of habit. Audit and clip.
58. **Use SQL/UI cost dashboards** that show $ per job and per stage. Pair with the per-job tuning skill when a single job is an outlier.

### 11. Upgrade strategy

59. **Plan for Spark minor-version upgrades quarterly.** Hold one minor version behind latest unless a CVE forces an upgrade. The image pipeline produces both old and new images during the transition.
60. **Run a shadow upgrade window.** A subset of jobs run on the new image in parallel; compare wall clock and output equality before flipping the default.
61. **Plan for K8s minor upgrades** in coordination with the cluster team. Drain Spark namespaces of streaming jobs first; batch jobs ride through.
62. **Plan for operator upgrades carefully.** Each operator release may change CRD fields; existing SparkApplication objects need migration or a clean cut.

### 12. Write the deployment plan

63. **Topology section.** Node groups, namespaces, autoscaler, storage classes.
64. **Workload section.** Mapping from each workload class to placement (priority, taints, tolerations, requests).
65. **Operational section.** Image pipeline, secret distribution, observability, History Server, alerting.
66. **Cost section.** Quotas, labels, spot policy, idle reaping.
67. **Verification section.** The pre-production proofs each subsystem must pass before traffic shifts.
68. **Risk register.** Spot eviction storms, control-plane outages, shuffle service overload, History Server saturation. Each risk gets a mitigation.

## Inputs

- A workload portrait — class, concurrency, duration, data, isolation needs.
- The Kubernetes substrate available — managed or self-hosted, node types, networking.
- The existing observability stack and cost-attribution practices.
- Any regulatory or organizational constraints on tenancy.

## Outputs

- A topology design with node groups, namespaces, and storage choices.
- A workload-placement plan mapping each class onto the cluster.
- An operational plan covering images, observability, and upgrades.
- A cost-and-quota plan with chargeback model.
- A verification checklist of pre-production proofs.

## Examples

### Example 1: nightly ETL plus interactive notebooks for two teams

Input: 60 nightly batch jobs peaking at 400 executors between 02:00 and 04:00; ad-hoc notebooks during business hours peaking at 30 concurrent drivers; two teams; managed K8s on a major cloud provider; spot available.

Design: one node group of on-demand small machines for drivers and History Server, one spot node group for batch executors, one on-demand pool for notebook executors (lower interruption tolerance). Spark Operator for scheduled batch; spark-submit from a notebook proxy for interactive. Namespace per team plus a shared system namespace. Decommissioning enabled; shuffle tracking enabled. Quota of 1000 vCPU per team. Cost attribution by namespace label.

### Example 2: GPU model training next to CPU ETL

Input: 10 GPU training jobs per day, each running 1–3 hours; 80 CPU ETL jobs per day; one team but two cost centers; on-prem K8s.

Design: tainted GPU node group with NVIDIA device plugin; non-tainted CPU node group. Priority classes: GPU at high priority, ETL at default. Job labels include cost-center; quota per cost-center inside the shared namespace. Reuse a single shuffle service across both workload classes. History Server consumes event logs from both. CPU jobs may use spot; GPU jobs run on-demand only.

### Example 3: streaming SLA workload alongside batch reprocessing

Input: 5 streaming queries that must not stop for more than 60 seconds; 30 batch reprocessing jobs that backfill historical state; managed K8s; spot available.

Design: streaming namespace pinned to on-demand nodes, high-priority class, anti-affinity to spread drivers; batch namespace on spot with decommissioning and a remote shuffle service. PriorityClass preemption disabled to prevent batch from preempting streaming. Alerting: streaming p99 lag, batch job duration outliers. Separate History Server retention by namespace (streaming kept longer for postmortem).

## Limitations

- This skill prescribes architecture, not Spark internals tuning. Pair with a Spark Job Tuner skill for individual slow jobs.
- The choice between operator and direct submit depends on team operability; both are valid and the skill explains the trade-offs rather than dictating one.
- Remote shuffle services add operational burden; small teams may prefer shuffle tracking even at the cost of less aggressive scale-down.
- Cloud-specific identity wiring (IRSA, workload identity, AAD pod identity) is mentioned generically; the precise binding depends on the provider.
- Cost-attribution depth depends on the labeling discipline; without consistent labels, the model degrades to "by namespace only".
- GPU scheduling assumes a Linux GPU plugin; specialized accelerators (Intel, AMD, custom ASIC) follow similar patterns but require vendor-specific verification.

## Sources reviewed

- https://github.com/apache/spark
- https://github.com/kubeflow/spark-operator
- https://github.com/apache/incubator-celeborn
- https://github.com/kubernetes/autoscaler
- https://github.com/awslabs/karpenter-provider-aws
- https://github.com/prometheus/prometheus
- https://github.com/NVIDIA/spark-rapids

## Linked notes

- [[domains/iac/k8s-manifest-reviewer]] — applies
- [[domains/cost/kubernetes-cost-optimizer]] — see-also

<!-- skg-attribution:
  vault_path: "domains/platform/spark-on-kubernetes-architect.md"
  skill_id: "019e91f9-7427-7b60-883d-582fbad8010d"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "a037e24a9849bdf540a85a3626729b6882bc2a9af7540b06d414a93fbd409401"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:07.961653Z -->
