---
id: skillsgit-curated/ci-pipeline-architect
version: 1.0.1
name: CI/CD Pipeline Architect
description: Design a production-grade CI/CD pipeline for a given stack — build, test,
  scan, sign, promote, deploy — with caching, parallelism, gates, and rollback plan.
authors:
- name: skillsgit Curated
  handle: skillsgit-curated
  role: author
category: engineering
tags:
- niche:devops-iac
- ci-cd
- pipeline-design
- github-actions
- supply-chain
- release-engineering
- build-automation
- testing
links:
- target: gha-workflow-optimizer
  relation: see-also
- target: artifact-signing-and-verification-designer
  relation: extends
- target: imported-voltagent-cloudflare-workers-best-practices
  relation: see-also
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gpt-4.1
  - gemini-1.5-pro
  tools_required:
  - file_io
  tools_optional:
  - web_search
  min_context_tokens: 32000
  estimated_tokens_per_invocation: 7000
trigger_keywords:
- design a ci pipeline
- cd pipeline design
- github actions workflow
- build pipeline
- release pipeline
- pipeline architecture
- ci cd plan
- deployment pipeline
- pipeline stages
- sign and promote artifacts
- pipeline caching strategy
- matrix build
- supply chain pipeline
example_invocations:
- Design a CI/CD pipeline for a TypeScript monorepo deploying a backend service and
  a Next.js frontend.
- Sketch the GitHub Actions workflows we need to build, test, scan, sign, and promote
  a Go microservice.
- We have no pipeline today. Walk me through the stages we need and what gates each
  one.
inputs:
- name: stack_description
  type: text
  required: true
  description: Languages, frameworks, package managers, container runtime, target
    platforms, repository layout (single repo, monorepo, polyrepo).
- name: deployment_targets
  type: text
  required: false
  description: Where artifacts land — Kubernetes, serverless, VMs, mobile stores,
    package registries, static hosts.
- name: existing_pipeline
  type: text
  required: false
  description: Current pipeline configuration (YAML, Jenkinsfile, etc.) if migrating
    or extending; otherwise the agent designs from scratch.
- name: compliance_requirements
  type: text
  required: false
  description: SOC2 / FedRAMP / ISO / SLSA level / internal supply-chain rules that
    constrain the design.
- name: team_constraints
  type: text
  required: false
  description: Team size, on-call posture, time-to-merge target, budget for compute,
    vendor preferences.
outputs:
- name: pipeline_design
  type: markdown
  description: Layered design doc with stage diagram, per-stage purpose, tooling choices,
    gates, rollback paths, and an opinionated 30-60-90 rollout plan.
- name: workflow_skeleton
  type: text
  description: Annotated YAML or pseudocode skeleton for the recommended runner (GitHub
    Actions, GitLab CI, Buildkite, Jenkins) that the team can paste and fill in.
kind: skill
distribution:
  content_hash: be4d0c2d706eaa860c15758da5f542994fe7950f9f7536a3cb6aa44131d7a267
  signed_at: '2026-06-04T09:34:37.875279Z'
  signed_by: marketplace
  signature: d27b81cac8e3f700eb13f5f9bcd3597a19a680052b6d586afbaff046f81d9699
---

# CI/CD Pipeline Architect

## When to use

Invoke this skill when an engineer asks for help designing — not just tweaking — a continuous integration and continuous delivery pipeline. The trigger is usually one of: a new project with no pipeline yet; an existing pipeline that has grown by accretion and now needs a redesign; a migration between CI providers (Jenkins to GitHub Actions, CircleCI to Buildkite, GitLab to Argo); or a compliance-driven uplift (the team needs to reach a SLSA level, satisfy a SOC2 control, or close a supply-chain audit finding).

The skill is appropriate when the user can describe the application stack and the deployment targets but has not yet decided the stage ordering, the gating policy, the artifact promotion model, or the secret-handling boundary. It is not appropriate for tactical YAML debugging (a job is failing; why?), for narrow speed optimization on a working pipeline, or for choosing between two specific CI vendors as a procurement question. Those tasks have dedicated treatment elsewhere; here the focus is the design.

A well-designed pipeline does four things well: it produces a build that is reproducible and traceable; it surfaces every category of failure (compile, unit, integration, security, policy) with the right latency for the right audience; it promotes a single artifact through environments with monotonically increasing trust; and it makes the next deploy a button press rather than a heroic event. The skill is calibrated to deliver a design that satisfies all four.

## Inputs

| Input | Required | Purpose |
| --- | --- | --- |
| `stack_description` | yes | The languages, package managers, container or VM target, and repo shape. |
| `deployment_targets` | no | The runtime substrate and any environment tiers (dev, staging, prod, region splits). |
| `existing_pipeline` | no | Current configuration if the design is an evolution rather than a greenfield. |
| `compliance_requirements` | no | Regulatory or internal controls that constrain or expand the design. |
| `team_constraints` | no | Cost, headcount, time-to-merge, and vendor preference. |

## How to apply

The agent runs a layered design pass. Each step produces an artifact that subsequent steps consume, and the final report assembles them in human-readable order.

### Stage 1 — Frame the system

1. Read the stack description and classify the build along three axes: the *artifact kind* (container image, native binary, browser bundle, library package, mobile binary, static site, infrastructure plan), the *test surface* (unit only, unit plus integration, end-to-end, plus contract tests, plus load), and the *deploy cadence* (per merge, per tag, per nightly, per ad-hoc). The three axes determine which stages are mandatory and which are optional.
2. Identify the *promotion topology*: how many environment tiers exist, what events cause an artifact to move from one tier to the next, and which humans (if any) sit at each gate. The default for new pipelines is two tiers (staging then production) plus an optional pre-merge ephemeral environment. Anything more is justified by team size or compliance.
3. Identify the *repo shape*. A single-application repo deploys one artifact; a monorepo deploys many and benefits from change-detection routing; a polyrepo distributes responsibility but needs cross-repo coordination. The shape changes how the trigger graph is wired.
4. Note the *latency budget*. How long can a developer wait between push and PR-mergeable signal? Typical targets are under 10 minutes for unit signal and under 30 minutes for full integration signal; design the parallelism budget accordingly.
5. Note the *risk budget*. How catastrophic is a bad production deploy? A low-risk surface (internal tools, idempotent jobs) can use direct deploy on merge; a high-risk surface (payments, identity, customer data) needs canary, manual approval, or both.

### Stage 2 — Define the stage graph

6. Lay out the canonical pipeline stages, then mark each as required, optional, or skipped given the stack. The canonical stages, in execution order, are: **checkout**, **dependency resolution and cache restore**, **lint**, **type-check**, **unit test**, **build**, **container or artifact assembly**, **vulnerability scan of dependencies**, **vulnerability scan of artifact**, **license compliance scan**, **secret scan**, **integration test against ephemeral dependencies**, **contract test (if multi-service)**, **end-to-end test against ephemeral environment (if applicable)**, **performance baseline (if applicable)**, **artifact signing (Sigstore cosign or platform-equivalent)**, **SBOM generation and attestation**, **artifact publish to staging registry**, **deploy to staging**, **smoke test against staging**, **promote artifact to production registry**, **deploy to production with chosen rollout strategy**, **post-deploy verification**, **release annotation**.
7. For each stage, decide whether it runs *blocking* (the pipeline fails if it fails), *informational* (it produces a comment but does not block merge), or *post-merge* (it runs only on the main branch after merge, never on PR). Blocking-on-PR raises trust but increases time-to-merge; the right balance depends on the latency budget from step 4.
8. Identify which stages can run in parallel. The default parallelism set is: lint, type-check, and dependency-scan in one fan-out; unit tests sharded by directory or test framework in a second fan-out; container assembly serially after these, then artifact scans in a third fan-out. Document the dependency DAG explicitly — fan-out without explicit dependencies leads to flaky behavior.
9. Identify which stages need *fan-in* to a gate. The classic gates are: "all required checks green" before merge, and "staging smoke test green" before production promotion. Each gate has a named owner — usually a CODEOWNERS group or a release manager rotation.
10. Mark every stage with its *failure mode*. A failing unit test fails the build and requires no escalation. A failing license scan blocks promotion but does not block merge in most setups. A failing post-deploy verification triggers automatic rollback. Be explicit; the failure mode dictates the on-call experience.

### Stage 3 — Caching and reproducibility

11. Design the *cache key strategy*. The canonical pattern is a layered key: an outer key on the runner OS plus the lockfile hash; an inner restore-key that falls back to the same OS plus any lockfile. Misses are warm-fills, not full rebuilds. Document the cache scope (per-branch vs. cross-branch) and the eviction policy.
12. Pick a *dependency reproducibility model*. For language ecosystems with lockfiles (npm, pnpm, yarn berry, poetry, pip-tools, bundler, cargo, go.sum), enforce lockfile presence in CI and refuse builds that resolve transitively without the lockfile pinning the world. For build systems without lockfiles, recommend vendoring or a manual constraints file with a CI check that diffs the resolved tree.
13. Pin the *build environment*. Specify the runner image by digest, not by tag. Specify the toolchain version (Node major.minor, Go x.y, Python x.y, Java LTS) and enforce it via the build matrix; "use the system version" is not a design.
14. Pin *third-party actions or plugins* by SHA, not by floating tag. This is non-negotiable in compliance-graded pipelines and a strong default everywhere. Document the renovation process — typically a weekly bot PR that bumps SHAs after auto-running a smoke build.
15. Make the build *deterministic in the small*. Disable timestamps inside artifacts where the build system allows (e.g., `SOURCE_DATE_EPOCH` honored, `--build-arg` for the commit SHA, no random IDs baked in). Determinism is a prerequisite for reproducible-build attestation and for sane cache hits.

### Stage 4 — Test strategy on the pipeline

16. Choose the *unit test isolation level* and shard accordingly. Single-process test runners shard cleanly on file count or measured duration; multi-process runners need careful shard boundaries (e.g., one shard per service module). Recommend the framework's native sharding (Jest `--shard`, pytest-xdist, Go's parallel test runner, Maven Surefire's `forkCount`) rather than home-grown splitting.
17. Define the *integration test boundary*. Decide what the test environment actually contains: real databases via testcontainers; in-memory replacements; recorded HTTP fixtures via VCR-style libraries; live external services with a sandbox account. Mixing strategies inside one suite is a smell; pick one boundary per suite.
18. Define the *end-to-end strategy*. Ephemeral preview environments per PR are the gold standard; static integration environments are the budget option; production "test in real life" is the desperation option. Pick one and write down what triggers the environment up and down.
19. Define the *flake policy*. State that flaky tests are tracked in a dedicated quarantine label, that any test that fails twice and passes on retry within a week enters the quarantine, that quarantined tests do not gate merges, and that the on-call rotation has explicit time budgeted to drain the quarantine. Without this policy, retries become hush money.
20. Define the *test data lifecycle*. Test data is owned by the test that uses it; fixtures are generated, not borrowed; production data is never imported into test environments without explicit redaction and approval.

### Stage 5 — Supply chain and security stages

21. Pick a *dependency scanner*. The pattern across the field is one fast SCA scan on every PR (advisory database lookup, no network at run time) and one deeper scan post-merge that includes transitive analysis and license checks. Configure the scanner with an allowlist for known false positives, a deny-list for forbidden licenses, and an explicit owner who triages findings.
22. Pick an *artifact scanner*. For containers, scan the built image layer-by-layer for CVEs after build but before promotion. Surface findings with severity thresholds: a critical finding fails the stage; a high finding warns; a medium finding is informational. Make the thresholds explicit in the design — defaults vary by team risk appetite.
23. Add a *secret scanner*. Scan diffs on every PR and the full tree post-merge. Pair this with branch-protection rules that refuse pushes containing matches. Surface positives as a blocker even on the smallest change.
24. Add *IaC and policy scans* if the pipeline ships infrastructure. For Terraform, this is a static security scan plus a policy-as-code check (OPA, Sentinel, Conftest) on the plan. For Kubernetes, this is a manifest linter plus admission-policy preview against the rendered manifests.
25. Generate an *SBOM* on every build and store it alongside the artifact. The SBOM is the source of truth for the dependency-scanner post-mortem when a future CVE is announced. Use a standard format (SPDX, CycloneDX); platform-specific formats lock you in.
26. *Sign artifacts and attest the build* with a keyless signing tool (Sigstore cosign or its workload-identity equivalent). The signed attestation includes the builder identity, the SBOM, the source commit, and any scan reports. The deploy environment refuses unsigned artifacts. This is the single highest-leverage supply-chain control.
27. Pin a *credentials boundary*. Build secrets (registry credentials, signer keys, scanner tokens) live in CI-only secret stores, are scoped to the workflow that needs them, and rotate on a documented cadence. Application secrets never live in CI — they live in the deploy target's secret manager and CI only handles a reference.

### Stage 6 — Promotion and deploy stages

28. Decide the *promotion model*. The recommended default is "build once, promote many": one artifact is built, signed, and pushed to a staging registry; the same digest is promoted to a production registry after staging acceptance. This eliminates "works in staging, broken in prod" caused by rebuilds.
29. Pick a *rollout strategy* per environment. Staging can use a simple replace; production should default to one of: blue/green for stateless services with simple cutover; canary with a defined percentage progression for traffic-shaped services; feature-flagged dark launch for the highest-risk releases. The skill picks the default based on the risk budget from step 5.
30. Define *the rollback path* explicitly. Rollback is not "redeploy the previous version" — it is "redirect traffic to the previously good artifact whose attestation is still trusted." Time-bound it: the design specifies the seconds-to-rollback target and the automated trigger conditions.
31. Define *post-deploy verification*. After deploy, the pipeline runs a short verification suite — health probes, a synthetic transaction, a baseline of the four golden signals (latency, traffic, errors, saturation). Failure triggers the rollback path from step 30.
32. Define *release annotations*. Every production deploy emits an annotation to the monitoring system and a release row to the change-management log. This is the link between observability and the pipeline; an incident commander will thank you.
33. Define *change windows and freezes*. Document who can authorize a deploy during a freeze and how the pipeline enforces the freeze (a configuration flag, a calendar integration, a CODEOWNERS gate). Pretending freezes don't exist is the path to a Sunday at 2am.

### Stage 7 — Trigger model

34. Specify the *PR triggers*. The default is: on `pull_request` to the default branch, run the blocking stages from step 7; on `pull_request` labeled with `run-extended`, run the optional stages too. PRs from forks have reduced secret access — design around it.
35. Specify the *main-branch triggers*. The default is: on `push` to the default branch, run all stages including build, scan, sign, publish, and deploy to staging. Production deploy is a separate event — usually a release tag or a manual approval — not an automatic consequence of merge.
36. Specify the *tag and release triggers*. A semver tag matching `v*.*.*` triggers the production deploy. The tag is created by a release tool, not by a human typing into the CLI; the tool guarantees the changelog, the version bump, and the immutability.
37. Specify the *scheduled triggers*. Nightly full integration tests against a fresh environment; weekly dependency renovation; monthly drift detection on infrastructure. Schedules catch the slow-burn failures that PR triggers miss.
38. Specify the *manual triggers*. A `workflow_dispatch` (or equivalent) lets a release manager retry a failed promotion, deploy a hotfix to a specific environment, or run a chaos exercise. These are documented, audited, and rate-limited.

### Stage 8 — Observability of the pipeline itself

39. Emit *pipeline metrics*: queue time, run time per stage, failure rate per stage, cache hit rate, flake rate per test. The team that does not measure these is flying blind on time-to-merge.
40. Emit *release metrics*: deploy frequency, change failure rate, mean time to recovery, lead time for changes. These are the four DORA metrics; they are well-known shorthand for the team's release velocity and quality. Treat them as the pipeline's KPIs.
41. Surface *expensive jobs*. Annotate jobs with cost estimates; flag any job whose runtime grows by more than a chosen percentage week-over-week. CI cost runs away quietly otherwise.
42. Wire *alerts on pipeline pathologies*: main-branch broken for longer than a chosen threshold; deploy-to-staging failure rate over a threshold; signing-stage failure (this is a security incident, not a flake).

### Stage 9 — Choose the runner and write the skeleton

43. Pick a *runner*. The pragmatic defaults are: GitHub Actions for projects living on GitHub; GitLab CI for projects living on GitLab; Buildkite for teams that want hybrid hosted/self-hosted; Jenkins for teams with deep existing investment that can't migrate yet. The choice is rarely worth re-litigating once made; pick once and design the skeleton against the chosen tool.
44. Write a *skeleton* (50-150 lines) showing the stage graph, the matrix, the caches, the secrets references, the gates, and the artifact publication. The skeleton is annotated heavily with comments explaining "why" — the team will fill in "what" later.
45. Note where the skeleton uses *third-party actions* and pin them by SHA in the example; never use a floating tag.
46. Note *self-hosted runners* if the design uses them. Self-hosted runners change the security model fundamentally; the design enumerates the isolation guarantees (per-job VM, ephemeral disk, network segmentation) or it doesn't recommend them.

### Stage 10 — Compose the deliverable

47. Write the design as a sectioned markdown document in this order: **Summary** (one paragraph), **Goals and non-goals**, **Stage diagram** (text-art DAG), **Per-stage design** (one subsection per stage with purpose, tooling, success criteria, failure mode), **Promotion model**, **Rollback model**, **Compliance posture** (mapping stages to the controls from input), **Observability**, **Risks and mitigations**, **30-60-90 rollout plan**, **Open questions**.
48. The **30-60-90 rollout plan** is the part the team will actually act on: which three stages get implemented in the first 30 days (typically lint, unit test, build), which three in the next 30 days (typically integration test, scan, sign), which in the final 30 (typically promote, deploy, rollback). The plan is opinionated; do not present every option as equal.
49. The **risks and mitigations** section names the top five risks specific to this team's stack. Generic risks ("CI could be slow") are not useful; specific risks ("the test data fixture is shared across suites and will cause races once we shard") are.
50. The **open questions** section captures what the user needs to decide before implementation can start. This is a feature, not a failure — a design that pretends to answer everything is a design that has buried the contentious bits.

### Stage 11 — Communication and calibration

51. Avoid vendor evangelism. The design names tools, but the rationale is in terms of the property the tool delivers (artifact signing, dependency caching) so the team can substitute.
52. Avoid scope creep. If the user asked for a pipeline, do not also design their observability stack or their secret manager. Reference them as preconditions and move on.
53. Avoid utopia. Acknowledge what gets deferred. "We do not propose canary rollout in v1 because the service mesh isn't in place; we revisit in 90 days" is a real design choice; "canary later" is not.
54. Reflect the team's constraints. A two-person team gets a different design than a fifty-person team; the same skill should produce two different artifacts for the two inputs.
55. End with a single short paragraph: "If you do nothing else from this design, do these three things." This focuses the conversation on the highest-leverage moves.

### Stage 12 — Self-check before returning

56. Verify every required stage from step 6 either appears in the design or is explicitly marked skipped with a reason. A silent omission erodes trust.
57. Verify the skeleton matches the design. The two artifacts can disagree only if the skeleton's deviations are called out in comments.
58. Verify the design does not depend on an unstated tool. If the rollback path assumes a service mesh, the design says so up front.
59. Verify the design names humans, not just systems. A pipeline with no named owners is a pipeline that decays.
60. Verify the design fits the team's latency budget from step 4. Add up the longest dependency path; if it exceeds the budget, the design must name what was traded for what.

## Outputs

The skill returns two artifacts:

1. `pipeline_design` (markdown) — the design document covering stages, promotion, rollback, observability, and the rollout plan.
2. `workflow_skeleton` (text) — an annotated runner-specific skeleton the team can paste and fill in.

## Examples

**Input (placeholder):**

Stack: Python 3.12 backend (FastAPI), Postgres, deployed as a container image to a Kubernetes cluster behind an Istio service mesh. Single repo. Two environments: staging and production. Compliance: SOC2 Type II in scope. Latency budget: under 15 minutes from push to merge-ready signal.

**Agent reasoning (abbreviated):**

- Stage 1: artifact is a container image; test surface is unit plus integration plus contract; cadence is per-merge to staging, per-tag to production.
- Stage 2: required stages — lint, type-check (mypy), unit test (pytest with xdist sharding), container build, dependency scan, image scan, SBOM, sign (cosign), publish to staging registry, deploy to staging via Argo CD, smoke test, manual promotion to production registry, canary rollout via Argo Rollouts, post-deploy verification.
- Stage 3: cache key — `runner-os + sha256(poetry.lock)`. Runner image pinned to a specific digest. Toolchain pinned to Python 3.12.x.
- Stage 4: unit test shards = 4; integration tests use testcontainers for Postgres; contract tests run only post-merge.
- Stage 5: SBOM in CycloneDX; sign with Sigstore keyless against the GitHub OIDC token; Trivy for image scan; gitleaks for secrets.
- Stage 6: build-once-promote-many; staging on push to main, production on tag; canary at 5%/25%/50%/100% with five-minute holds.
- Stage 7: pull_request triggers lint, type, unit, integration; push triggers everything; tag triggers production.
- Stage 8: emit DORA metrics; alert on main-broken > 1 hour and on signing failure.
- Stage 9: GitHub Actions; skeleton 110 lines with two workflows (build-and-test, release).
- Stage 10: 30-60-90 plan front-loaded with lint, unit, build, scan.

**Output (abbreviated):**

The design doc includes a 12-stage DAG, two YAML files in the skeleton, a paragraph each on canary rollout and SBOM attestation, and an opinionated recommendation to defer end-to-end browser tests to a nightly schedule rather than block PRs on them.

## Limitations

- The skill produces a design, not a working pipeline. The team owns the implementation and the inevitable platform-specific tuning.
- Some controls (e.g., FedRAMP-required attestations) require contractual relationships with specific vendors; the design points at the control but cannot procure the vendor for the team.
- Cost estimates are heuristic; actual CI cost depends on the team's job mix and runner choice. The design names cost as a dimension but does not generate a monthly forecast.
- The skill assumes the team has a deployable target. If the target itself is unstable (e.g., a Kubernetes cluster with no platform team), the pipeline cannot compensate; the design says so rather than papering over it.
- Recommendations encode practices common across mid-2020s production teams; teams with very different constraints (regulated air-gapped environments, real-time systems, hardware-in-the-loop builds) will get a design that's a starting point, not a finished product.
- The skill does not write the application's test code. It assumes tests can be written; it does not write them.

## Sources reviewed

- https://github.com/actions/reusable-workflows (MIT)
- https://github.com/sdras/awesome-actions (CC0-1.0 reference list of MIT/Apache actions)
- https://github.com/johnbillion/awesome-github-actions-security (MIT)
- https://github.com/aquasecurity/trivy (Apache-2.0)
- https://github.com/aquasecurity/tfsec (MIT)
- https://github.com/antonbabenko/pre-commit-terraform (MIT)
- https://github.com/argoproj/argo-rollouts (Apache-2.0)
- https://github.com/fluxcd/flagger (Apache-2.0)

## Linked notes

- [[domains/ci-cd/gha-workflow-optimizer]] — see-also
- [[domains/security/artifact-signing-and-verification-designer]] — extends
- [[domains/ci-cd/imported-voltagent-cloudflare-workers-best-practices]] — see-also

<!-- skg-attribution:
  vault_path: "domains/ci-cd/ci-pipeline-architect.md"
  skill_id: "019e91f9-650a-7361-ad7d-ff53ef81a0e5"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "192fbb9157917381b527b89cd77b3b707a1545ac5c9a46c12dc0701d8fe95c2b"
  built_at: "2026-01-01T00:00:00Z"
-->
