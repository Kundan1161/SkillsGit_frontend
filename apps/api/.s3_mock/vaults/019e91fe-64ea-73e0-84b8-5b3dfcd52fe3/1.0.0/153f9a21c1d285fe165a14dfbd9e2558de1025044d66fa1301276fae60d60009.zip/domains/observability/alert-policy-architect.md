---
id: occ-compose/alert-policy-architect
version: 1.0.0
name: Alert Policy Architect
description: A test skill describing Alert Policy Architect.
category: engineering
tags: ['alert']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: skill
---

## When to use

Use this skill when Alert Policy Architect applies.

## How to apply

1. Read the spec.
2. Apply it.

<!-- skg-attribution:
  vault_path: "domains/observability/alert-policy-architect.md"
  skill_id: "019e91fe-64e9-72a0-9863-682bb5e0c78f"
  version: "1.0.0"
  kind: "skill"
  creator_handle: "occ-compose"
  content_hash: "e8ac8fd78be4d3fa7460c630eab9a622e2d69932aac91fe54e97cabbb1bb73f4"
  built_at: "2026-01-01T00:00:00Z"
-->
