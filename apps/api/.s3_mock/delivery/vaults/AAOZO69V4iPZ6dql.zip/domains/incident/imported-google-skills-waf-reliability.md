---
id: skillsgit-curated/imported-google-skills-waf-reliability
version: 1.0.1
name: Google Cloud Well-Architected — Reliability
description: Apply the Google Cloud Well-Architected Framework Reliability pillar
  — SLOs, redundancy, horizontal scalability, observability, graceful degradation,
  and recovery testing.
authors:
- name: Google (original)
  handle: google
  role: author
- name: skillsgit Curated
  handle: skillsgit-curated
  role: maintainer
category: engineering
tags:
- imported
- source-google
- gcp
- well-architected
- reliability
- sre
- slo
links:
- target: slo-designer
  relation: applies
- target: chaos-experiment-planner
  relation: see-also
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gemini-2.0-pro
trigger_keywords:
- waf reliability
- slo
- error budget
- disaster recovery
- redundancy
- postmortem
example_invocations:
- Audit a workload's reliability against the WAF framework.
- Recommend SLOs and error budgets for a new service.
inputs: []
outputs: []
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Imported from google/skills under Apache-2.0.
kind: skill
distribution:
  content_hash: a6e8f8f779ecc119accbbb6f4763745399181a0067b51e24a83ef9e325155130
  signed_at: '2026-06-04T09:34:38.059837Z'
  signed_by: marketplace
  signature: b29a2fab8f9d546d725770b30d92a9bf4d9077d0c0a135485f5e12fae6d60a94
---

# Google Cloud Well-Architected Framework — Reliability pillar

## When to use

Use this skill when evaluating a workload's reliability against the Google Cloud Well-Architected Framework Reliability pillar, defining SLOs and error budgets, designing for redundancy and graceful degradation, or planning recovery testing.

## How to apply

Anchor on the nine core reliability principles. Ask the workload assessment questions to understand the user's current posture, then walk the validation checklist to identify gaps. Recommend the relevant compute, networking, storage, operations, and DR products.

## Overview

The Reliability pillar of the Google Cloud Well-Architected Framework provides principles and recommendations to help you design, deploy, and manage reliable, resilient, and highly available workloads in Google Cloud. A reliable system consistently performs its intended functions under defined conditions, is resilient to failures, and recovers gracefully from disruptions.

## Core principles

- Define reliability based on user-experience goals.
- Set realistic targets for reliability (SLOs + error budgets).
- Build highly available systems through resource redundancy across zones and regions.
- Take advantage of horizontal scalability.
- Detect potential failures by using observability.
- Design for graceful degradation.
- Perform testing for recovery from failures (chaos engineering, game days).
- Perform testing for recovery from data loss (backup/restore drills).
- Conduct thorough blameless postmortems.

Each principle has a grounding document under `https://docs.cloud.google.com/architecture/framework/reliability/`.

## Relevant Google Cloud products

- Compute: Compute Engine MIGs, GKE, Cloud Run.
- Networking: Cloud Load Balancing, Cloud CDN, Cloud DNS.
- Storage and databases: Cloud Storage (multi-region), Cloud SQL HA, Spanner, Filestore, Firestore.
- Operations: Cloud Monitoring, Cloud Logging, Google Cloud Managed Service for Prometheus.
- Disaster recovery: Backup and DR Service, Filestore backups.

## Workload assessment questions

- How does your organization define and measure the reliability of your systems in relation to user experience?
- How does your organization approach setting reliability targets for your services?
- What is your strategy for ensuring high availability through resource redundancy?
- How does your organization leverage horizontal scalability to maintain performance and reliability?
- How do you use observability (metrics, logs, traces) to detect potential failures?
- How do you manage alerting based on observability data without causing alert fatigue?
- What measures do you take to ensure systems can gracefully degrade during high load or partial failures?
- How frequently and comprehensively do you test for recovery from system failures?
- What is your approach to testing for recovery from data loss?
- How do you conduct and utilize postmortems after incidents?

## Validation checklist

- User-focused SLIs and SLOs are explicitly defined and actively monitored.
- The architecture avoids single points of failure through cross-zone or cross-region redundancy.
- Autoscaling is enabled to handle variable demand without manual intervention.
- Application and infrastructure health checks are configured to trigger automated failovers.
- Regular backup schedules are in place, and restoration processes are routinely tested.
- The system incorporates circuit breakers, retries with exponential backoff, and rate limiting to support graceful degradation.
- Game days or chaos engineering practices are regularly held to validate failure recovery.
- A formalized, blameless postmortem process exists to ensure organizational learning from operational incidents.

## Attribution

This skill was imported from `google/skills` under the Apache-2.0 license. Original content authored by Google. Modifications by skillsgit: frontmatter normalization to fit marketplace spec; addition of attribution and sources sections; addition of `## When to use` and `## How to apply` stubs required by our validator. The original LICENSE and NOTICE files are preserved at the source repository.

## Sources reviewed

- https://github.com/google/skills/tree/main/skills/cloud/google-cloud-waf-reliability (Apache-2.0)

## Linked notes

- [[domains/observability/slo-designer]] — applies
- [[domains/incident/chaos-experiment-planner]] — see-also

<!-- skg-attribution:
  vault_path: "domains/incident/imported-google-skills-waf-reliability.md"
  skill_id: "019e91f9-6a59-7723-8ab1-5c6a6bb46747"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "2578c638f6005c0143c53d9a52166ea8331e66d317fb63f1d9284bb663b62705"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:07.961374Z -->
