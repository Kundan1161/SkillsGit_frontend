---
id: curator-handle/k8s-manifest-reviewer
version: 1.0.0
name: K8s Manifest Reviewer
description: A test skill describing K8s Manifest Reviewer.
category: engineering
tags: ['k8s']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: skill
---

## When to use

Use this skill when K8s Manifest Reviewer applies.

## How to apply

1. Read the spec.
2. Apply it.

<!-- skg-attribution:
  vault_path: "domains/iac/k8s-manifest-reviewer.md"
  skill_id: "019e91fe-6443-7780-a352-ee3c639f2cef"
  version: "1.0.0"
  kind: "skill"
  creator_handle: "curator-handle"
  content_hash: "871e9530aedeae027d9b00a85dd952332e529647488acf21f4d6b3c82f8ceb4f"
  built_at: "2026-01-01T00:00:00Z"
-->
