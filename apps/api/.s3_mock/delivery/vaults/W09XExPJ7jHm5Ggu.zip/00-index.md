# Index — AI DevOps Engineer

## Base methodology

### ci-cd

**Core**

- [[domains/ci-cd/ci-pipeline-architect]] — Design a production-grade CI/CD pipeline for a given stack — build, test, scan, sign, promote, deploy — with caching, parallelism, gates, an
- [[domains/ci-cd/gha-workflow-optimizer]] — Review GitHub Actions workflows for cost, speed, security posture, and reliability — flag wasted minutes, third-party-action risk, and missi

**Optional**

- [[domains/ci-cd/imported-voltagent-cloudflare-workers-best-practices]] — Review and author Cloudflare Workers code against production best practices, with a strong bias toward retrieving current docs rather than r


### observability

**Core**

- [[domains/observability/observability-dashboard-architect]] — Design service dashboards layered from user-journey golden signals through RED service panels, USE resource panels, and SLO budget panels, w
- [[domains/observability/alert-policy-architect]] — Design an alert taxonomy across page/ticket/email/dashboard channels with severity, routing, deduplication, escalation, and an alert-fatigue
- [[domains/observability/slo-designer]] — Design service-level objectives end-to-end — user journeys to SLIs to SLOs, multi-window multi-burn-rate alerts, error-budget policy, and re

**Supporting**

- [[domains/observability/cardinality-cost-reviewer]] — Diagnose unbounded metric cardinality, log volume, and trace storage. Recommend label hygiene, sampling, aggregation, and a target cost enve
- [[domains/observability/imported-google-skills-networking-observability]] — Investigate Google Cloud networking issues by analyzing VPC Flow Logs, NAT, firewall, threat logs, latency/throughput metrics, and Connectiv

**Optional**

- [[domains/observability/instrumentation-coverage-reviewer]] — Review a service's metrics, traces, and logs against RED/USE, span discipline, structured logging, and end-to-end correlation IDs — output a


### incident

**Core**

- [[domains/incident/ops-incident-commander]] — Real-time copilot for an on-call engineer running a live production incident — triage severity, coordinate parallel work streams, structure 
- [[domains/incident/ops-runbook-generator]] — Takes a recurring operational task — restart a stuck consumer, rotate a credential, drain a node — and produces an executable runbook with n
- [[domains/incident/chaos-experiment-planner]] — Plan a chaos experiment with explicit hypothesis, steady-state metrics, blast radius, abort criteria, and learnings capture so the test prod

**Supporting**

- [[domains/incident/imported-alirezarezvani-chaos-engineering]] — Use when planning, running, or learning from chaos engineering experiments. Triggers on "chaos experiment", "fault injection", "gameday", "r
- [[domains/incident/imported-google-skills-waf-reliability]] — Apply the Google Cloud Well-Architected Framework Reliability pillar — SLOs, redundancy, horizontal scalability, observability, graceful deg


### iac

**Core**

- [[domains/iac/k8s-manifest-reviewer]] — Audit Kubernetes manifests or Helm charts for security posture, resource limits, probes, rollout strategy, network policy, and admission com
- [[domains/iac/terraform-module-reviewer]] — Audit a Terraform module or codebase for naming, variable design, state hygiene, security defaults, drift handling, and version pinning — ou


### security

**Supporting**

- [[domains/security/secrets-architecture-designer]] — Design an end-to-end secrets architecture covering sources of truth, runtime distribution, rotation policy, ephemeral vs long-lived credenti
- [[domains/security/workload-identity-architect]] — Design attested per-workload identity that replaces shared long-lived secrets with short-lived credentials, SPIFFE-style federation, mTLS, a
- [[domains/security/artifact-signing-and-verification-designer]] — Design a signing and verification flow for build artifacts and container images, covering identity, key management, transparency log, attest


### cost

**Supporting**

- [[domains/cost/cloud-cost-audit]] — Audit a multi-cloud bill end-to-end — surface top cost drivers, weekly anomalies, rightsizing candidates, commitment coverage gaps, storage 
- [[domains/cost/cloud-cost-alert-designer]] — Design cost-anomaly detection and alerting for a cloud account — baselines, threshold-vs-trend rules, severity tiers, owner routing, and wee
- [[domains/cost/kubernetes-cost-optimizer]] — Surface Kubernetes-specific cost levers — requests/limits rightsizing, HPA/VPA tuning, spot adoption, node-pool design, idle workload detect
- [[domains/cost/imported-google-skills-waf-cost]] — Apply the Google Cloud Well-Architected Framework Cost Optimization pillar — FinOps culture, resource optimization, governance, and continuo


### platform

**Supporting**

- [[domains/platform/internal-platform-strategy-author]] — Define the scope, golden paths, and team-topology shape of an internal developer platform so it accelerates product teams without becoming a

**Optional**

- [[domains/platform/spark-on-kubernetes-architect]] — Design production Spark on Kubernetes with the right operator model, dynamic allocation, GPU scheduling, multi-tenant isolation, observabili
- [[domains/platform/kafka-topic-architect]] — Design a Kafka or Kafka-API topic taxonomy — naming, event vs entity split, partition keys, partition count, retention, compaction, replicat
- [[domains/platform/kafka-consumer-pattern-picker]] — Pick the right Kafka consumer pattern — single consumer, consumer group, exactly-once with idempotent producer and transactions, dead-letter
- [[domains/platform/kafka-streams-pipeline-designer]] — Design a Kafka Streams topology — sources, state stores, joins, windows, exactly-once-v2, scaling, recovery, and the operational shape that 
- [[domains/platform/kafka-schema-evolution-architect]] — Design a Kafka schema evolution policy — Avro vs Protobuf vs JSON Schema, compatibility modes, registry placement, breaking-change governanc
- [[domains/platform/imported-voltagent-cloudflare-platform]] — Decision trees for picking the right Cloudflare product — Workers, Pages, storage (KV/D1/R2), AI (Workers AI, Vectorize, Agents SDK), networ


## Personas

_None bundled in this base build. Composition adds personas at delivery time — see `vault.json` after composition._

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:39:34.069945Z -->
