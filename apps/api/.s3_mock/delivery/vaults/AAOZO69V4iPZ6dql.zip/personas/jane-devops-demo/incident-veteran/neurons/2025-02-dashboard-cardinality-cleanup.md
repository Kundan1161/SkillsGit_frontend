---
id: jane-devops-demo/2025-02-dashboard-cardinality-cleanup
version: 1.0.0
name: 2025-02 Cardinality cleanup — cutting Prometheus memory 47% in one week
description: '[sample data] Prometheus memory hit 28GB and started OOM-killing; tracked
  it to three labels (user_id, request_uuid, full URL path) and dropped them via metric-relabel
  without losing query value.'
authors:
- name: Jane Devops (sample)
  handle: jane-devops-demo
  role: author
category: personas
tags:
- sample-data
- prometheus
- cardinality
- observability
- cost
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
trigger_keywords:
- prometheus memory
- cardinality explosion
- metric cleanup
- observability cost
example_invocations:
- Prometheus is OOM-killing every other day. Where's the cardinality coming from?
kind: memory_neuron
parent_occupation_id: skillsgit-curated/ai-devops-engineer
links:
- target: base/cardinality-cost-reviewer
  relation: applies
- target: base/observability-dashboard-architect
  relation: extends
- target: base/instrumentation-coverage-reviewer
  relation: see-also
neuron:
  situation: 'Our central Prometheus instance had been climbing in memory over

    the prior 8 weeks. Steady-state was 22GB at the start of the

    window, hit 28GB by Feb 6, started OOM-killing on the 9th. We

    bumped the node from 32GB to 64GB as a stopgap; cost went from

    $310/month to $620/month for that one node. The trajectory said

    we''d be at 80GB+ within a quarter.

    '
  decision: 'Pulled the top-N series-count-by-metric report using the cardinality

    exporter. Three metrics accounted for 71% of the active series.

    All three had recently-added labels: user_id on http_request_total,

    request_uuid on http_request_duration_seconds, and the un-templated

    full URL path on http_external_dependency_latency_seconds. Dropped

    user_id and request_uuid entirely via metric_relabel_configs at

    the scrape config; templated the URL path into a parameterised

    route via a relabel rule.

    '
  outcome: 'Active series dropped 47% within one scrape cycle. Memory landed

    at 13GB steady-state (vs the original 22GB). Reverted the node

    size from 64GB back to 32GB. Query latency p99 improved from 2.4s

    to 380ms because the underlying TSDB had less to scan. No SLO

    dashboard lost meaningful information; we built two new helper

    metrics for the cases that legitimately needed the high-cardinality

    info (one logging-side, one short-retention).

    '
  recorded_at: '2025-02-21'
  confidence: 0.9
distribution:
  content_hash: 6d47ce611326299f301f9f5d27e0c76e5b953c8fd84ae22d418333559dca525a
  signed_at: '2026-06-04T09:34:41.864866Z'
  signed_by: marketplace
  signature: 05dcecd4bc5a82122a21acf89ae227be9595c012de31ad6ffcd9834e07b0533c
---

# 2025-02 Cardinality cleanup — cutting Prometheus memory 47% in one week

> SAMPLE DATA — this neuron is part of the seeded `@jane-devops-demo`
> persona shipped alongside the Cycle-1 demo. Real persona neurons are
> published by named DevOps practitioners and replace this content.

## When to use
Use this neuron when Prometheus memory is climbing without a
corresponding growth in monitored workload, especially after a
recent metric-instrumentation change. The same triage shape applies
to any metric backend: identify the top cardinality contributors,
attribute them to specific labels, decide per label whether the
information is load-bearing for an SLO/alert/dashboard, then drop
or template via relabeling.

## How to apply
1. Run a top-N cardinality report (Prometheus has
   `prometheus-cardinality-exporter`; other backends have
   equivalents). The top 3-5 metrics usually account for ≥60%
   of active series.
2. For each top contributor, run `count by (label) (metric)` to
   identify which label is driving the explosion. Usually it's a
   recently-added label or an un-templated path/identifier.
3. For each high-cardinality label, ask: does any SLO, alert, or
   dashboard query actually need this granularity? If no, drop
   via `metric_relabel_configs`. If yes for a small slice, move
   that slice to logs or traces with short retention.
4. Add a CI lint that fails PRs touching scrape config or
   instrumentation unless a CARDINALITY.md note documents the
   expected per-label bound.

## What happened
Our central Prometheus had been creeping. Memory was 22GB in early
December. By Feb 6 it was 28GB and we'd added 3 new alerts about
its own health. On Feb 9 it OOM-killed during a deploy spike. We
bumped the underlying node from 32 -> 64 GB as triage; cost doubled
to $620/month for that single node, and the trend suggested another
doubling within a quarter.

Step 1 was the cardinality exporter (`prometheus-cardinality-exporter`,
running every 6h). Top-10 by series count showed the distribution
sharply concentrated:

```
metric                                  series      pct
http_request_total                      1,840,231   31%
http_request_duration_seconds            1,420,889   24%
http_external_dependency_latency_seconds   942,471   16%
(everything else)                       1,742,108   29%
```

Drilling into each of the top three with `count by (label) (metric)`:

- `http_request_total` had grown a `user_id` label (added 7 weeks
  earlier as part of a "per-user request rate" dashboard nobody
  ended up using). 380k unique users, 5 quantile buckets, 4
  status-code buckets => millions of combinations.
- `http_request_duration_seconds` had grown a `request_uuid` label
  on its histogram (mistakenly added by a contributor who confused
  Prometheus labels with structured log fields). Every request was
  its own series.
- `http_external_dependency_latency_seconds` had the full URL path
  (including UUIDs in path segments) instead of a parameterised
  route — about 40k unique paths per day.

Fix was scrape-config metric_relabel_configs:

```yaml
metric_relabel_configs:
  - source_labels: [__name__]
    regex: 'http_request_total'
    target_label: user_id
    replacement: ''
    action: replace
  - source_labels: [__name__, request_uuid]
    regex: 'http_request_duration_seconds;.+'
    target_label: request_uuid
    replacement: ''
    action: replace
  - source_labels: [path]
    regex: '(/api/v[0-9]+/users)/[0-9a-f-]{36}(.*)'
    target_label: path
    replacement: '${1}/:user_id${2}'
    action: replace
```

Applied via prometheus-operator's `additionalScrapeConfigs`. First
scrape cycle after rollout: active series dropped from 5.94M to
3.13M. Steady-state memory landed at 13GB within an hour. Reverted
the node back to 32GB.

Followups:
- For the team that had genuinely wanted per-user request rates, we
  added a logging-side counter (Loki LogQL query) sampled at 1% with
  24h retention. Costs ~$8/month, doesn't touch Prometheus.
- For request_uuid: there was never a real need; the use case it
  was added for is better served by trace IDs in tempo.
- Audit lint: added a CI check on PRs that touch Prometheus
  scrape-config or instrumentation code that fails if a new label
  isn't documented in a CARDINALITY.md note explaining the expected
  bound.

## Lessons
- Cardinality cost compounds. A "small" new label that takes you
  from 1M series to 3M takes you from 22GB to 60GB memory; the
  storage and query cost is non-linear because of how TSDB chunks
  work.
- Per-metric cardinality reports are the unit of analysis. "Total
  series" tells you you have a problem; "series per metric per
  label" tells you what to fix.
- The right home for high-cardinality data is usually not Prometheus.
  User IDs, request UUIDs, full URL paths belong in logs (Loki, Splunk,
  CloudWatch Logs) or traces (Tempo, Jaeger), with metric-level
  aggregates rolled up via recording rules.
- Add a lint gate on instrumentation changes. The cheapest
  intervention is at PR-time; the most expensive is at OOM-time.

## Linked notes

- [[base/cardinality-cost-reviewer]] — applies
- [[base/observability-dashboard-architect]] — extends
- [[base/instrumentation-coverage-reviewer]] — see-also

<!-- skg-attribution:
  vault_path: "personas/jane-devops-demo/incident-veteran/neurons/2025-02-dashboard-cardinality-cleanup.md"
  skill_id: "019e91fc-26c4-7260-b593-113ae9790707"
  version: "1.0.0"
  kind: "memory_neuron"
  creator_handle: "jane-devops-demo"
  content_hash: "fb8c4d6365388c980e830d5d549ab62a1e557dabc99e0a4944f33ad456a2bd9d"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:07.961813Z -->
