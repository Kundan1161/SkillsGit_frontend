# Jane Incident (compose) — v1.0.0

> A persona overlay by @jane-compose. DevOps on-call

## What's in this overlay

- 2 memory neuron(s) recording real situations, decisions, and outcomes.

## About the practitioner

Hi I'm Jane-Compose.

## Attribution

This persona was assembled at 2026-01-01T00:00:00Z by Skills Git.
- `@jane-compose/jane-incident-compose` v1.0.0

See `persona.json` for the machine-readable manifest fragment. Composition merges this overlay into the parent occupation vault at delivery time.

<!-- license:3031fda922f68e54 buyer:904fef234b1af57f ts:2026-06-04T09:37:08.860214Z -->
