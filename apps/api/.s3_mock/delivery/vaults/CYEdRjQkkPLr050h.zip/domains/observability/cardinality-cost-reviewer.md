---
id: skillsgit-curated/cardinality-cost-reviewer
version: 1.0.1
name: Cardinality & Cost Reviewer
description: Diagnose unbounded metric cardinality, log volume, and trace storage.
  Recommend label hygiene, sampling, aggregation, and a target cost envelope.
authors:
- name: Wave-3 Methodology Synthesis
  handle: wave3-observability-sre
  role: author
category: engineering
tags:
- niche:observability-sre
- cardinality
- metrics-cost
- log-volume
- sampling
- label-hygiene
- telemetry-budget
links:
- target: instrumentation-coverage-reviewer
  relation: applies
- target: cloud-cost-audit
  relation: see-also
license_type: free
ai:
  required_models:
  - claude-opus-4-7
  - claude-sonnet-4-6
  compatible_models:
  - gpt-4o
  - gpt-4.1
  - gemini-1.5-pro
  min_context_tokens: 32000
  tools_optional:
  - web_search
  estimated_tokens_per_invocation: 6500
trigger_keywords:
- high cardinality
- prometheus cardinality
- metric explosion
- log volume
- trace cost
- sampling strategy
- label hygiene
- observability cost
- telemetry budget
example_invocations:
- Our Prometheus is OOMing. Audit our top metrics for cardinality.
- Datadog bill doubled this quarter. Help us cut without losing signal.
- We log 4 TB a day. What's safe to drop?
- Design a sampling policy for traces — we keep everything today.
inputs:
- name: telemetry_inventory
  type: text
  required: true
  description: Description or dump of the current telemetry — top metrics by series
    count, top log sources by volume, current trace sampling configuration, vendor
    costs if known.
- name: service_context
  type: text
  required: true
  description: Number of services, request volume, top alert use cases, and what the
    team currently relies on most for debugging.
- name: cost_target
  type: text
  required: false
  description: Specific cost or volume target ("cut metrics series 50%"), or pain
    point ("storage exceeded budget by 3×").
outputs:
- name: cost_review
  type: markdown
  description: A diagnosis of the worst offenders by signal, prioritized cuts, label-hygiene
    rules, a sampling design, and projected savings with the risks of each cut.
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release covering Prometheus cardinality detection, label-relabel
    patterns, log-tier design, trace sampling (head + tail), and a cost-impact estimation
    model.
kind: skill
distribution:
  content_hash: 1292a6f448e4b2d21338b943b5dce1d7f5e7fce788c9386555db3aa20a1391b6
  signed_at: '2026-06-04T09:34:38.055394Z'
  signed_by: marketplace
  signature: 6372a4fb8283c78d23e3d6211abb524a30af042231dcc03bc36df5d0317efbff
---

# Cardinality & Cost Reviewer

## When to use

Use this skill when the telemetry pipeline is **expensive, slow, or unstable** and someone needs to decide what to cut. Triggers:

- "Our Prometheus server OOMs at peak, what label is killing us?"
- "Our observability vendor bill is X — leadership wants it cut Y%."
- "We collect 100% of traces and storage is overflowing. Design a sampling policy."
- "We log everything at INFO and our log search is unusable. What can we drop?"
- "We're planning a new service and want a telemetry-cost envelope upfront."

Do **not** use this skill to add or improve instrumentation (use the coverage reviewer) or to design alerts (use the alert-policy or SLO designer skills). Cost work is **subtractive** — its quality is measured in what's safe to remove, not what's added.

## How to apply

Work through three signal-specific phases (metrics, logs, traces) and a cross-cutting governance phase. Always quantify before recommending. Never cut a signal an active alert depends on without naming the alert.

### Phase 1 — Metrics cardinality

**The model:** in Prometheus and almost every other time-series database, cost is roughly linear in **active series count**. One series is one unique combination of `(metric name, label1=v1, label2=v2, …)`. A metric with 5 labels each having 10 possible values is up to 100,000 series for that one metric. With minutes-per-sample storage at typical retention, each series costs a few KB of RAM and a few MB of disk per year.

The thresholds that matter:

- A single metric with **>10,000 series** is suspicious. Investigate why.
- A single metric with **>100,000 series** is almost always a bug.
- A single metric with **>1,000,000 series** will eat your Prometheus alive.

#### Find the offenders

In a running Prometheus, the questions to ask:

```promql
# Top metric names by series count
topk(20, count by (__name__)({__name__=~".+"}))

# For a suspect metric, top contributing labels
topk(20, count by (some_label) (some_metric))

# Per-job series totals
sort_desc(count by (job)({__name__=~".+"}))
```

In Datadog / Honeycomb / New Relic, vendor cardinality dashboards expose the same data — every vendor has one because every customer needs it.

#### The label-hygiene rules

These are not stylistic; they are correctness rules at scale.

1. **Never label by an ID with unbounded values.** Forbidden: `user_id`, `request_id`, `trace_id`, `session_id`, `email`, `order_id`, full URLs, raw stack-trace hashes, customer-supplied strings. These belong in **traces and logs**, not metrics.
2. **Never label by free-form text.** Error messages, raw exception strings, `User-Agent`. Aggregate to a class (`error_class`, `client_kind`) at recording time.
3. **Cap dynamic label sets at the source.** If `route` could be templated wrong (a stray `/users/12345` slips through), add a `relabel_config` that drops the metric or normalizes the value before ingestion.
4. **Status codes go to status classes for alerting.** Keep `status_class=2xx|4xx|5xx` on the high-cardinality counter; keep raw `status_code` only on a low-cardinality counter you actually query.
5. **Per-pod labels are temporary by nature.** Use `instance` and `pod` sparingly — every rolling deploy turns over every series. Prefer `service` and `deployment` as primary keys; let `instance` exist for drill-down but don't carry it on every metric.
6. **Resist one-metric-per-tenant.** In multi-tenant systems, `tenant_id` is tempting but explodes by tenant count. Acceptable only when tenant count is bounded and small (e.g. <500 enterprise accounts) — never for free-tier user counts in the millions.

#### Relabel patterns (Prometheus)

Drop the worst offender at scrape time:

```yaml
metric_relabel_configs:
  # Drop a specific noisy metric entirely.
  - source_labels: [__name__]
    regex: 'go_gc_duration_seconds_quantile_.*'
    action: drop

  # Drop a high-cardinality label, keeping the metric.
  - regex: 'user_id'
    action: labeldrop

  # Normalize a templated route that sometimes contains an ID.
  - source_labels: [route]
    regex: '/users/[0-9]+(/.*)?'
    target_label: route
    replacement: '/users/{id}$1'
```

Recording rules collapse high-cardinality raw series into the low-cardinality version you actually need for alerting:

```yaml
- record: http_requests:rate1m
  expr: sum by (service, route, status_class) (rate(http_requests_total[1m]))
```

This lets you drop the raw `http_requests_total` from long-term retention while keeping the recording series indefinitely.

#### Histograms specifically

Histogram buckets multiply. A histogram with 12 buckets and 5 labels each with 10 values is 600,000 series for one histogram. Rules:

- Default to **8–12 buckets** unless you have a specific need.
- Bucket boundaries should cover **two orders of magnitude** centered on the SLO threshold. For a 500 ms SLO: 50, 100, 200, 500, 1000, 2500, 5000 ms.
- Resist per-pod, per-customer, per-version histograms. Aggregate.

### Phase 2 — Log volume

Most log bills come from one of three patterns:

1. **Verbose INFO** on hot paths logging full request payloads at 100% sampling.
2. **Repeating WARN** for known-ignored conditions (e.g. expired token retries) — high volume, low actionability.
3. **Stack traces on every retry** of a transient error.

#### Triage logs into three tiers

Once you tier your logs, cost decisions become obvious.

- **Tier A — Audit/security/compliance.** Auth attempts, admin actions, money movement. Retain at full fidelity, often legally required. ~1–5% of volume in most systems.
- **Tier B — Operations.** WARN, ERROR, request-completed lines. The lines on-call greps during an incident. Retain 14–30 days, full fidelity.
- **Tier C — Debug / verbose INFO.** Per-request detail, payloads, internal state dumps. Sample to 1–10%, retain 3–7 days, or route to a cheaper store (S3 with Athena-style search) instead of the hot index.

Many vendor pipelines (Vector, Cribl, Fluent Bit) support routing by log line — apply tier rules at the agent, before paying for ingestion. Use what your stack already runs; do not introduce a new pipeline tier solely for cost-cutting unless the savings justify it.

#### Log-line hygiene

- **No PII** in logs. Removes a class of redaction work later.
- **Parameterize, don't interpolate.** `{"err":"timeout","host":"db-3"}` not `"timeout connecting to db-3 attempt 5/5 user=alice"`. Parameterized is cheaper to compress, easier to query, easier to redact.
- **One log per request outcome**, not one log per step. Steps are spans; logs are the result.
- **Compress retries.** If you log every retry of a transient failure, you've logged the noise but not the signal. Log on first failure, suppress until success or final failure.

#### Quantify before cutting

Before recommending a drop, compute the cost. A useful estimate:

```
daily_volume_GB = log_lines_per_second × avg_bytes_per_line × 86400 / 1e9
indexed_cost_per_month ≈ daily_volume_GB × 30 × $vendor_per_GB
```

Then for each candidate drop, project the new volume and savings. If the engineer doesn't have per-source volume, the agent (Fluent Bit, Vector) exposes it as a metric — get it before deciding.

### Phase 3 — Trace cost and sampling

Traces are expensive when full-fidelity (1 trace = many spans = many KB). The escape hatch is sampling. Three sampling tiers, used together:

1. **Head sampling at the edge.** Set `sampled=1` for K% of requests at the entry service. Propagate via `traceparent`. This is the only sampling decision that lowers *generation* cost (the un-sampled requests emit no spans).
2. **Tail sampling at the collector.** Run an OpenTelemetry Collector with a `tail_sampling` processor that buffers complete traces for ~10–30 seconds and keeps based on policy: **100% of error traces**, **100% of slow traces** (e.g. duration > p99 threshold), plus a sample of normal traces. Tail sampling lets you drop boring traces but never drop interesting ones.
3. **Always-keep override.** Honor a `debug=1` baggage entry or an `X-Debug-Trace: 1` header. Allows engineers to force-keep specific production traffic for triage. Limit to internal use to prevent abuse.

Default starting point for a service emitting 1k req/s:

| Tier | Rule | Effect |
| --- | --- | --- |
| Head | 10% random sample | 90% of spans never generated |
| Tail | Keep 100% errors, 100% > p99 duration, 5% of normal | Of the 10% generated, keep maybe 20% (depending on error rate) |
| Net | ~2% of all requests have stored traces, weighted to interesting ones | |

#### What sampling breaks

Be honest about the trade-offs:

- **Counting from traces is wrong under sampling.** Don't compute "total errors" from sampled traces — use metrics for that. Traces answer "what happened in this slow request", not "how many requests failed".
- **Rare events get missed** unless tail-sampled. A user complains about a specific failed request 2 days ago; if it wasn't an error or slow, it might not be in your sample. Provide a debug-trace override and document it.
- **Latency comparisons across sampled and unsampled time periods are unsafe.** Pick a sampling rate and stick with it; document changes.

### Phase 4 — Governance: budgets and exception process

To avoid relitigating each cut every quarter, give each team a **telemetry budget**:

- A target series count per service in metrics.
- A target log GB-per-day per service.
- A target trace span count per second per service.

Numbers come from current spend ÷ service count, adjusted to leave headroom. Publish them. New high-cardinality dimensions go through a PR review against the budget.

Exception process — short, written, time-boxed:

- A team can blow the budget for a quarter with eng-manager sign-off.
- The exception must name a re-evaluation date.
- Exceptions auto-expire; budgets reassert.

This keeps cost decisions out of incident retros and into routine engineering.

### Estimating impact before cutting

Rough model for projected savings on a Prometheus drop:

```
savings_series = sum(series_dropped)
savings_RAM_MB ≈ savings_series × 3 / 1000      # ~3 KB / series at hot-path
savings_disk_GB ≈ savings_series × 0.01 × retention_days / 30
```

These are rules of thumb — every install differs. The point is to attach a number to every recommendation so the team can prioritize.

## Inputs

- **Required:** an inventory or sample of current telemetry (top metrics by series, top log sources by volume, current trace sampling rate). If unknown, the skill provides queries to gather it first.
- **Required:** service context — service count, peak request volume, what the team uses most.
- **Recommended:** vendor invoice or cost report, ingest-rate dashboards, retention policy.
- **Optional:** specific cost target ("cut bill 40%") or pain point ("Prometheus OOMs at 6pm").

## Outputs

A markdown report with:

1. **Top offenders table** — for each of metrics/logs/traces, the top 5 by cost with measured cardinality/volume/sample rate.
2. **Prioritized cuts** — ordered by `savings ÷ risk-to-signal`. Each cut names the affected alerts and dashboards.
3. **Label-hygiene rules** for the team's stack with concrete `metric_relabel_configs` or vendor-equivalent.
4. **Log tiering plan** — which log sources move to which tier and how (Vector/Fluent Bit/Cribl rule snippets).
5. **Trace sampling design** — head sampler config, tail-sampling processor config (OTel Collector), debug-override guidance.
6. **Telemetry budgets** — proposed per-service budgets and exception process.
7. **Projected savings** — best estimate per cut, with confidence band.
8. **Risk register** — what each cut blinds you to, and the alert/dashboard that compensates.

## Examples

### Example 1 — "Our Prometheus OOMs at peak"

User shares: 80M active series, OOMs around 60M-RAM mark, ~30 services.

Recommended response shape:

- Top-of-list PromQL queries to identify the worst metric. Usually 1–3 metrics account for >40% of series. Common culprits: a histogram with `user_id` label, an SDK metric instrumented by default with high-cardinality attributes, a debug counter never removed.
- Drop or relabel those at scrape time. Project: minus ~30M series, minus ~90MB RAM.
- Add recording rules to keep the aggregate version for alerting.
- Cap per-team series with a `Per-team series budget` and a dashboard.
- Add cardinality CI: lint new `PrometheusRule` and `ServiceMonitor` files for forbidden label names (`user_id`, `request_id`, `email`, etc.).

### Example 2 — "Cut Datadog bill 40%"

User shares: $X/month, breakdown is 50% logs, 30% custom metrics, 15% traces, 5% other.

Recommended response shape:

- Logs (largest line item): tier into A/B/C, drop Tier C ingestion or route to S3-backed search. Project: 40–60% reduction on logs.
- Custom metrics: cardinality audit. Often a handful of tags blow up — `endpoint` with raw path, per-tenant labels in multi-tenant systems.
- Traces: introduce tail sampling at the OTel Collector. Keep all errors and slow, sample others to 5%. Project: 80–90% reduction in span ingestion.
- Net: a 40% bill cut with the largest savings on logs and traces; metrics are mostly hygiene.

## Limitations

- **Vendor-specific cost models vary.** This skill is most precise for self-hosted Prometheus, Loki-style log stores, and OTel-Collector-routed traces. Vendor APMs have different cost drivers (per-host, per-service, per-event); the framework still applies but the math differs — ask for the vendor's billing breakdown.
- **Does not negotiate vendor contracts.** Recommendations are technical. Renegotiation is procurement.
- **Cannot predict savings exactly.** Compression ratios, retention rules, and vendor pricing tiers all interact. Numbers in the output are estimates; verify after one billing cycle.
- **Aggressive cuts can blind on-call.** Always pair a cut with the alert or dashboard it might break. If the team can't articulate what they lose, slow down.
- **Not a sampling-fairness analysis.** If your trace sample is biased (e.g. always-keep-from-tenant-X due to debug header), downstream analyses based on traces will be biased. Note it; don't silently fix it.

## Sources

- Prometheus metric and label naming best-practices (Apache-2.0): https://github.com/prometheus/prometheus
- Awesome Prometheus Alerts — example label discipline in rule files (MIT/CC-BY): https://github.com/samber/awesome-prometheus-alerts
- kube-prometheus — relabel and recording-rule patterns at scale (Apache-2.0): https://github.com/prometheus-operator/kube-prometheus
- OpenTelemetry Collector sampling processors (Apache-2.0): https://github.com/open-telemetry
- OpenTelemetry specification — semantic conventions (controls cardinality of standard attributes) (Apache-2.0): https://github.com/open-telemetry/opentelemetry-specification
- Sloth — recording rule generation that bounds SLO-related cardinality (Apache-2.0): https://github.com/slok/sloth

## Linked notes

- [[domains/observability/instrumentation-coverage-reviewer]] — applies
- [[domains/cost/cloud-cost-audit]] — see-also

<!-- skg-attribution:
  vault_path: "domains/observability/cardinality-cost-reviewer.md"
  skill_id: "019e91f9-632f-7dd0-a10a-8e3fe973b02f"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "4d24acfa0a54dc6ca05727125a2fad1df81f8795996fc1857d33ac946316ab11"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:08.511091Z -->
