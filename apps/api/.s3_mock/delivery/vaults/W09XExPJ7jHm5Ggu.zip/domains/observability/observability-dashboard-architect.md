---
id: skillsgit-curated/observability-dashboard-architect
version: 1.0.1
name: Observability Dashboard Architect
description: Design service dashboards layered from user-journey golden signals through
  RED service panels, USE resource panels, and SLO budget panels, with variable, link,
  and audit discipline.
authors:
- name: Wave-4 Methodology Recovery
  handle: wave4-observability-dashboards
  role: author
category: engineering
tags:
- niche:observability-dashboards
- golden-signals
- red-method
- use-method
- slo-panels
- template-variables
- dashboard-hygiene
- on-call
links:
- target: instrumentation-coverage-reviewer
  relation: applies
- target: alert-policy-architect
  relation: see-also
- target: slo-designer
  relation: applies
license_type: free
ai:
  required_models:
  - claude-opus-4-7
  - claude-sonnet-4-6
  compatible_models:
  - gpt-4o
  - gpt-4.1
  - gemini-1.5-pro
  min_context_tokens: 32000
  tools_optional:
  - web_search
  estimated_tokens_per_invocation: 7000
trigger_keywords:
- dashboard
- dashboards
- golden signals
- red method
- use method
- slo dashboard
- service dashboard
- panel layout
- dashboard review
- template variable
example_invocations:
- Design a dashboard for our checkout service that an on-caller can read in under
  a minute.
- Review this dashboard JSON — what panels are missing and which are noise?
- We have 80 dashboards and on-call never opens the right one. Help us pick a canonical
  layout.
- Build me a per-region, per-tenant variable scheme that does not explode cardinality.
inputs:
- name: service_description
  type: text
  required: true
  description: What the service does, its dependencies, its critical user journeys,
    and which teams will read the dashboard during incidents and during business hours.
- name: telemetry_inventory
  type: text
  required: false
  description: What metrics, logs, and traces are already emitted, including label
    or attribute names you can rely on. If unknown, the skill will propose the missing
    ones rather than guess.
- name: existing_dashboards
  type: text
  required: false
  description: Names, screenshots, or exported definitions of dashboards already in
    use, so the skill can consolidate rather than duplicate.
outputs:
- name: dashboard_blueprint
  type: markdown
  description: A layered dashboard specification — row-by-row, panel-by-panel — with
    query stubs, variable design, link map, and a quarterly audit checklist.
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release covering the four-layer dashboard model, variable discipline,
    link contracts, and the audit cadence.
kind: skill
distribution:
  content_hash: 5d92ac3fcf01fc4ba37ec7932ce4ad7d2d14d364b49cf70f581f08f2fbfd48a2
  signed_at: '2026-06-04T09:34:37.968193Z'
  signed_by: marketplace
  signature: cd871524f71e8ad1d23acecf4f3b910656749e792b8b5b15230df6abb4e6d1dd
---

# Observability Dashboard Architect

## When to use

Use this skill when an engineer, SRE, or platform team needs to design or rebuild a service dashboard that will be opened during an incident, a release, or a weekly review. Common triggers:

- A new service is launching and needs the dashboard that on-call will use at three in the morning.
- An existing service has a sprawl of ad-hoc charts that nobody trusts and the team wants to collapse it into one canonical view.
- A platform team is publishing a dashboard template that twenty service owners will copy.
- Leadership has asked for a "single pane of glass" and the team needs a structure that does not become a wall of meaningless graphs.

Do not use this skill to define service-level objectives themselves — pair it with an SLO-design skill, which produces the targets and burn rates this dashboard renders. Do not use it as an alerting design skill — the burn-rate alerts shown here are surfaced from the SLO design, not invented inside the dashboard.

## How to apply

Walk the user through six phases. Each phase produces a concrete artifact the next phase consumes.

### Phase 0 — Establish the conceptual model the user will accept

Before any panels are drawn, agree with the user on the dashboard's purpose in one paragraph. The most common cause of dashboard sprawl is that two engineers were optimising for two different mental models of what the dashboard is.

Three competing models surface repeatedly. Surface them, name the one you have chosen, and discard the others.

- **The cockpit model.** The dashboard is what the on-caller stares at for the duration of an incident. Every panel must change meaningfully when something is wrong. Static panels and decorative summaries do not earn their space.
- **The narrative model.** The dashboard tells the story of the service over a longer window. Panels exist to explain a trend or to support a discussion in a weekly review. Live alerting is incidental.
- **The catalogue model.** The dashboard is a reference of every metric the service emits, organised by category. There is no story; the reader brings their own question.

The methodology in this skill is optimised for the cockpit model with a clear handoff to a narrative dashboard for trends. The catalogue model is a recipe for sprawl and the skill does not produce it.

When the user is wedded to the catalogue model, explain that you can produce a panel inventory as documentation, but the live dashboard will be the cockpit version. Reference documentation lives in a wiki, not on a live dashboard pane.

### Phase 1 — Decide who the reader is and when they are reading

Every dashboard has at most two audiences, and trying to serve more produces noise:

- **The on-caller during an incident.** They have ninety seconds, they are reading on a phone, and they need to decide whether to escalate, roll back, or keep watching. Optimise for the first screen.
- **The service owner during a weekly review or a release window.** They have twenty minutes, they want trends, breakdowns, and correlations.

Pick one as primary. The other gets a sibling dashboard linked from the first, not a second tab inside it. If the user insists on a third audience (compliance, finance, executives), redirect them to a separate report — those readers do not look at live dashboards, they read summaries.

Capture this in one sentence at the top of the dashboard description, for example: "Primary audience: on-caller during an incident. Use the linked Trends dashboard for week-over-week analysis."

### Phase 2 — Layer the dashboard top to bottom

Use a four-layer structure. Read from the top during an incident; read from the bottom during a deep-dive review.

| Row position | Layer | What goes here | Why |
| --- | --- | --- | --- |
| Top row | **Golden user-journey signals** | One stat panel per critical user journey: success rate, latency at a threshold, throughput. | A glance answers "is the thing customers care about working right now". |
| Second row | **Service RED panels** | For each high-traffic route or RPC: request rate, error rate (as a ratio), and a duration distribution. | When a journey is bad, this row narrows the blame to a service or route. |
| Third row | **Resource USE panels** | For each saturating resource (CPU, memory, GC, queue depth, connection pools, downstream dependency error rate): utilisation, saturation, errors. | When a service is bad, this row tells you whether it is starved, slow, or broken. |
| Bottom row | **SLO and error-budget panels** | One row of error-budget burn rate over multiple windows, plus a remaining-budget stat. | Confirms whether the user-visible damage justifies a page or a ticket. |

This top-to-bottom layering is non-negotiable. The reader's eye must move from "is the customer experience bad" downward through "which service" and "which resource" to "should we be paging anyone". A dashboard that puts CPU at the top is a dashboard that paged someone for a cron job.

### Phase 3 — Design template variables

Variables are the largest source of dashboard sprawl and the most common cause of "this query is timing out". Constrain them.

Recommended variables, in this order, for a service dashboard:

1. `environment` — single-select, never `All`. Pin one environment per dashboard. If you need two, build two dashboards.
2. `region` (or equivalent locality dimension) — multi-select with `All` allowed.
3. `service_instance` — multi-select, defaulted to `All`. Hidden by default; expose only when the reader chooses to slice.
4. `route` or `endpoint` — multi-select for the RED row only. Do not let it cascade into the USE row.

Three rules that prevent the most common variable mistakes:

- **Never use a label as a variable if it has more than a few hundred distinct values.** Per-customer or per-trace-ID variables look powerful and turn the dashboard into a denial-of-service tool against your metric store. If you need per-customer views, build a separate tenant-scoped dashboard with the tenant set by URL parameter, not a dropdown that loads every tenant.
- **Use recording rules to pre-aggregate** anything the dashboard reads per render. A dashboard with twenty panels, each running a sum over a high-cardinality histogram across seven days, will time out and the on-caller will distrust every dashboard you ever build.
- **Variables that scope a panel must be visible in the panel title.** "Error rate" is a bad title; "Error rate — checkout, us-east, all routes" is the correct title. Most dashboarding tools support title interpolation; use it.

### Phase 4 — Build the link map

A dashboard is a node in a graph, not a leaf. Every panel should answer "where do I go next?" in at most one hop. Establish these link types:

- **Drill-down link** from each user-journey stat to the corresponding RED row, pre-filtered by route.
- **Drill-down link** from each RED panel to a logs view filtered by `service`, `route`, and the current time window. The log query must preserve the same label set so the reader is looking at the same population.
- **Drill-down link** from each error-rate panel to a trace search filtered by `service` and `error=true`, time-bounded to the panel window.
- **Lateral link** to the upstream service dashboard (the caller) and to each downstream dependency dashboard (databases, caches, other services).
- **Lateral link** to the SLO review dashboard for the same service and to the deploys / change-log view for the same service.
- **Reverse link** from the SLO dashboard back to this one.

Two principles for link discipline:

- **Time-range and label filters propagate.** If a reader clicks from a panel to a trace search, the trace search opens at the same time range with the same filters. A link that drops the context forces the reader to re-orient and they will stop using it.
- **No more than one link per panel header and one link per legend.** Link clutter is as bad as panel clutter.

### Phase 5 — Define the panel inventory and queries

For each of the four rows, write the panels out in a small table the user can sign off on before any JSON is produced. The template:

| Row | Panel name | Visualisation | Query stub | Threshold or annotation |
| --- | --- | --- | --- | --- |
| Journey | `Checkout success rate` | Stat with sparkline | `sum(rate(journey_events_total{name="checkout",outcome="ok"}[5m])) / sum(rate(journey_events_total{name="checkout"}[5m]))` | Red if below the SLO target; yellow within 1% of target. |
| Journey | `Checkout p95 latency` | Stat | `histogram_quantile(0.95, sum by (le) (rate(journey_duration_seconds_bucket{name="checkout"}[5m])))` | Red above the threshold the SLO uses. |
| RED | `Request rate by route` | Time series, stacked | `sum by (route) (rate(http_requests_total{service="$service"}[1m]))` | None; informational. |
| RED | `Error ratio by route` | Time series | `sum by (route) (rate(http_requests_total{service="$service",status=~"5.."}[5m])) / sum by (route) (rate(http_requests_total{service="$service"}[5m]))` | Annotation line at the SLO threshold. |
| RED | `Duration heatmap` | Heatmap | `sum by (le) (rate(http_request_duration_seconds_bucket{service="$service"}[1m]))` | Annotation at the SLO threshold. |
| USE | `CPU utilisation per pod` | Time series | `rate(container_cpu_usage_seconds_total{service="$service"}[1m])` | Red above the request limit; informational below. |
| USE | `Memory working set per pod` | Time series | `container_memory_working_set_bytes{service="$service"}` | Red above the limit. |
| USE | `GC pause time` | Time series, p95 | runtime-specific | Red above a runtime-defined ceiling. |
| USE | `Downstream error rate` | Time series per dependency | `sum by (dependency) (rate(outbound_requests_total{service="$service",outcome="error"}[1m]))` | Annotation for known dependency SLOs. |
| SLO | `Budget remaining` | Stat | `1 - (errors_30d / valid_30d) / (1 - $slo_target)` | Red at zero, yellow under 30%. |
| SLO | `Burn rate, 1h` | Time series with alert thresholds overlaid | `(errors_1h / valid_1h) / (1 - $slo_target)` | Annotation lines at burn rates 1, 6, 14.4. |

Adjust query language to the user's metric store, but keep the panel inventory and order constant. The point of the inventory is to make every service's dashboard look the same to the on-caller; consistency across services is more valuable than service-specific cleverness.

### Phase 6 — Establish the audit cadence

A dashboard is a living artifact. Schedule three reviews.

- **Per-incident review.** After every page that used this dashboard, the on-caller leaves a one-line note: which panel did they look at first, which panel was the most useful, which panel was misleading. A weekly aggregation of these notes drives panel changes.
- **Quarterly audit.** Owner of the dashboard reviews the panel inventory against the table above. Delete any panel that has not been looked at by an on-caller in the quarter (telemetry on dashboard interactions is feasible in most tools). Confirm every link still resolves to the right destination after recent renames.
- **Annual restructure.** With the eng manager, confirm the audience and the user journeys still match the service. Retire the dashboard if its service has merged into another; consolidate panels if its journeys have collapsed.

### Phase 7 — Hygiene checklist before publishing

Run the dashboard through this twelve-point checklist before it ships. A failed item is a blocker, not a polish task.

1. The first screen, with no scrolling on a 13-inch laptop, shows only the journey row and the SLO budget row. Everything else is below the fold.
2. Every panel title names the entity it shows. "Error rate" fails; "Error rate — checkout / production / all routes" passes.
3. Every threshold or annotation line is tied to a documented SLO target, a documented capacity limit, or a runbook entry. No mysterious red lines.
4. Every panel has a documented unit (requests per second, seconds, percent, count). Mixed units within a single time-series chart are forbidden.
5. The longest default time range on any panel is the same across the dashboard. A reader who changes the global time range expects every panel to follow.
6. No panel queries return more than ten thousand series before rendering. Use recording rules or grouping to keep the result set bounded.
7. No variable has `All` selected by default if `All` would scan more than a small fixed fraction of the metric store.
8. Drill-down links carry the current time range, the current variable set, and any panel-specific filters. Test each link by clicking it during the review.
9. The dashboard description names the audience, the primary use case, the on-call rotation that owns it, and the date of the last review.
10. The dashboard is in a folder named for the owning team, not in a personal folder.
11. Permissions: the owning team has edit; the rest of engineering has view; nobody else needs explicit grants.
12. A screenshot of the first-screen view is attached to the team's runbook so new on-callers know what "healthy" looks like.

### Phase 8 — Anti-patterns to refuse politely

When a user asks for any of these, push back with a brief explanation and an alternative.

- **A single dashboard that serves on-call and executives.** Build two; link the executive view to a weekly screenshot of the on-call dashboard if a leadership audience genuinely wants to glance at it.
- **Per-customer or per-trace-ID variables on a fleet dashboard.** Build a separate tenant-scoped dashboard with the tenant pinned by URL parameter and a hard upper bound on the lookup window.
- **A row of panels that displays one metric per microservice in a fleet of two hundred microservices.** No reader scans two hundred sparklines. Replace with a top-N panel showing the worst offenders by some unambiguous criterion.
- **A panel whose query references a metric that no recording rule produces and that scans more than a few minutes of raw samples.** Either build the recording rule first or move the panel to a deep-dive dashboard that is not opened during incidents.
- **Three different "error rate" panels with different denominators.** Standardise on one definition; if the team needs two views, label them unambiguously and explain the difference in the panel description.
- **A dashboard whose panels all have a 24-hour time range hard-coded.** A reader who needs to investigate a one-minute incident cannot use it. Use the dashboard time range and let the reader scope.

## Inputs

- **Required:** a description of the service, its critical user journeys, and the audience for the dashboard.
- **Recommended:** the existing label vocabulary used in metrics, logs, and traces; a list of dependencies and upstream callers; the SLO targets if they exist.
- **Optional:** exports of current dashboards to consolidate; recent incident postmortems that name dashboards as helpful or unhelpful.

## Outputs

A markdown specification with these sections, in this order:

1. **Audience and primary use case** — one sentence at the top.
2. **Row layout** — the four-layer plan with named rows.
3. **Variable design** — list of variables with allowed values and the reasoning for any defaults.
4. **Link map** — each link type, source panel, target dashboard, and propagated context.
5. **Panel inventory** — the full panel table with query stubs and thresholds.
6. **Audit plan** — the three review cadences with named owners.

Optionally a JSON skeleton in the user's dashboarding tool's import format, generated from the inventory.

## Examples

### Example 1 — New checkout service, no dashboards yet

User says: *"We are launching a checkout service that calls a payments processor and a fraud-check service. We need a dashboard for the launch."*

Recommended response shape:

- Identify two journeys: `place_order` and `refund`. Both user-facing critical.
- Top row: success rate and p95 latency stats for both journeys.
- RED row: split by route across the four HTTP endpoints of the service.
- USE row: CPU, memory, GC, downstream error rate to each of the two dependencies (payments and fraud).
- SLO row: budget remaining and a burn-rate panel with the three alert thresholds annotated.
- Variables: `environment` (production-only at launch), `region` (multi-select), `route` (RED-row only).
- Links: from each journey stat to the RED row; from each error panel to the logs query; from the dashboard to the payments and fraud sibling dashboards.

### Example 2 — Consolidating 14 dashboards into one

User says: *"We have 14 dashboards for this service. On-call opens the wrong one and wastes the first five minutes of incidents."*

Recommended response shape:

- Inventory the 14 dashboards by audience. Map each panel to one of the four rows.
- Pick one dashboard as the "primary on-caller view" with the four-row layout; mark the rest as deep-dive siblings.
- Move any panel that does not fit the four rows into a deep-dive dashboard linked from the primary.
- Delete duplicate panels (most dashboards have several copies of the same chart).
- Publish a deprecation notice for the 13 non-canonical dashboards and remove them after one full on-call rotation.

### Example 3 — Platform team publishing a template for 30 service owners

User says: *"We are the platform team. Thirty service owners each maintain a dashboard. They are all different. We want a template that any team can clone and have something useful in an hour."*

Recommended response shape:

- The template is the four-row layout with variables `environment`, `region`, `service`, `route`. The `service` variable is the one that each cloning team sets when they fork.
- The platform team publishes recording rules that produce the journey row's data from a single canonical metric pattern (`journey_events_total{name, outcome}`). Service teams emit that pattern; in return they get the top row for free.
- The template's RED row uses the platform-standard metric names (`http_requests_total`, `http_request_duration_seconds`). Teams that emit non-standard names file a request to extend the template.
- The SLO row reads from a platform-managed SLO definition file. Teams add their service to the file and the row populates without any panel edits.
- The audit cadence is owned by the platform team for the template itself and by each service owner for their copy.

### Example 4 — Replacing a noisy alert with a dashboard panel

User says: *"We have an alert on queue depth that fires twice a week and is always self-healing. We can't get rid of it because nobody trusts the queue. Can a dashboard fix this?"*

Recommended response shape:

- Move queue depth off the page list and onto the USE row of the service's dashboard with a clear annotation line at the historical "actually broken" threshold.
- Add a recording-rule-backed panel showing the mean time-to-drain over the last hour; that is what the team actually cares about, not the instantaneous depth.
- Replace the page with a ticket alert that fires only when both the depth exceeds the threshold for an hour and the time-to-drain estimate exceeds the SLO budget for the consumer.
- The dashboard panel and the ticket alert share the same threshold annotation source so they cannot disagree.

## Common review findings

When reviewing an existing dashboard against the methodology above, these findings recur. Cite them by number in feedback so teams can build a pattern library.

1. **Top row is CPU.** The dashboard was built bottom-up. Move the journey row to the top and demote resource panels.
2. **No journey definition.** The dashboard tracks endpoints, not user-visible outcomes. Pair with the SLO design and rewrite the top row.
3. **Variables that include `All` with no upper bound.** The dashboard times out for half the team. Constrain the variable or add a hard limit at the panel.
4. **Drill-down links to a different time range.** Reader loses context on every click. Fix by propagating the dashboard time range as a URL parameter.
5. **Three panels with the same name.** They cannot all be right and the reader cannot tell which to trust. Rename to disambiguate or delete duplicates.
6. **A "stack-rank by team" panel listing two hundred entries.** Truncate to top N or split into multiple dashboards keyed by team.
7. **Annotation lines without a source.** The red line is "company tribal knowledge". Document the source in the panel description or remove the line.
8. **Queries that scan multi-month windows on every load.** Build recording rules; reduce default time range; move historical panels to a sibling dashboard.
9. **The dashboard owner has left the company.** Reassign in the audit; orphaned dashboards become stale within a quarter.
10. **No screenshot of "healthy" in the runbook.** On-callers cannot recognise abnormal without a baseline. Add the screenshot.

## Limitations

- **Not a JSON generator for any specific dashboarding tool.** The skill produces a tool-agnostic specification; translating it into a vendor-specific definition is a mechanical step.
- **Not for executive or business dashboards.** Those have different patterns (KPIs, week-over-week percentage deltas, narrative annotations) and a different reader model.
- **Not for tracing-heavy investigation tools.** A dashboard is not a flame-graph viewer; trace exploration belongs in a dedicated tool linked from the dashboard.
- **Audit cadence assumes the platform records dashboard view telemetry.** If it does not, the quarterly audit relies on surveying on-callers, which is slower but still works.
- **Variable defaults are starting points.** Low-traffic services may need wider time windows on the top-row stats; very large fleets may need an additional `cluster` variable above `region`.
- **The four-row model assumes services follow request/response shapes.** For batch and streaming services, replace the RED row with throughput, lag, and freshness panels; the broader structure still applies.
- **Panel inventory tables in this skill use a specific metric-name convention.** Translate to your fleet's actual metric names before generating queries; cross-fleet portability comes from the structure, not from the metric names.

## Worked panel-by-panel review template

When asked to review an existing dashboard, return findings in this exact structure. The structure forces a like-for-like comparison against the methodology and makes review notes easy to action.

For each panel, capture:

- **Panel name** as it appears today.
- **Row assignment** in the four-layer model — Journey, RED, USE, SLO, or "off-model".
- **Audience match** — does this panel help the cockpit reader, the narrative reader, or neither?
- **Query verdict** — does it run in acceptable time at the dashboard's default range? If not, what is the recording-rule remediation?
- **Threshold source** — where does any annotation or colour threshold come from? Cite the SLO target, the capacity limit, or "remove" if no source exists.
- **Link verdict** — does any link from this panel still resolve and propagate context?
- **Recommendation** — keep, modify (with the specific change), move to deep-dive dashboard, or delete.

At the end of the per-panel list, summarise:

- The panels that are missing from the four-layer model and must be added.
- The duplicates that should collapse to a single canonical panel.
- The variables to consolidate or constrain.
- The links to repair.
- The audit cadence to assign to the dashboard's owner.

A review delivered in this shape can be executed by an engineer in a few hours; an unstructured review of the same dashboard yields a vague "needs work" and no progress.

## Glossary for users new to the methodology

Before working through the phases, ensure the user understands the following terms in the way this skill uses them. Differences in vocabulary across teams are the leading cause of design disagreements that look like design disputes.

- **Journey.** A user-visible outcome the service is responsible for. "Checkout completes" is a journey; "POST /api/v3/orders returns 200" is not.
- **Golden signal.** A metric tied directly to a journey: did it succeed, how long did it take, how often was it attempted. Distinct from a service-level metric.
- **RED metric.** Request rate, error rate, duration distribution — service-level signals; one set per route or RPC.
- **USE metric.** Utilisation, saturation, errors — resource-level signals; one set per resource.
- **Budget.** Error budget; the fraction of bad time or bad requests an SLO allows before remediation is required.
- **Burn rate.** Rate at which budget is consumed; the dashboard renders multiple burn-rate windows.
- **Variable.** A dashboard-scope value that parameterises queries. Synonyms in some tools: template, parameter.
- **Recording rule.** A pre-computed aggregation evaluated at write time, queried at read time. The single most useful primitive for fast dashboards.

## Handoff to neighbouring skills

A finished dashboard design is rarely useful by itself. Hand off cleanly to the team's broader observability practice.

- **To the SLO designer.** The dashboard's top row consumes the SLO targets. Confirm with the SLO design which target the dashboard renders, where the burn-rate alert thresholds annotate, and what the dashboard does when an SLO is in transition (target adjusted, journey redefined).
- **To the alerting policy.** The dashboard does not silence alerts; alerts are routed by the alert policy. Confirm that every annotation line on the dashboard corresponds to a known alert or to a documented non-alerted threshold; mystery lines confuse readers and erode trust.
- **To the instrumentation reviewer.** If the dashboard cannot be built because the data is not emitted, raise it as an instrumentation gap rather than papering over it with a worse panel. List the missing metrics with their owning service in the design output.
- **To the cardinality reviewer.** If a panel requires a new high-cardinality label, route the request through cardinality review before the panel ships. The dashboard architect does not unilaterally green-light a label.
- **To the runbook author.** Each alert annotation on the dashboard should point at a runbook. If the runbook is missing, mark the panel "pending runbook" rather than removing the alert or leaving the on-caller without guidance.

## Variable scheme — depth on a recurring trap

A surprising number of dashboard problems originate in the variable section, and the surface symptom is always different (timeouts, blank panels, paging on the wrong service). Address each of these explicitly.

- **Cascading variables.** A variable whose values depend on another variable is convenient but creates a dependency graph the reader cannot see. When a dropdown is empty, the reader does not know which upstream selector to change. Avoid cascades deeper than one level.
- **The `Custom` value.** Most dashboarding tools let a variable accept arbitrary input. This is occasionally useful and frequently dangerous; arbitrary input can collapse a panel's query into one that scans the entire store. If you allow `Custom`, validate the input or constrain it with a regex.
- **The `All` star.** Selecting `All` typically expands to a union over every value; when the value set is large, the resulting query is enormous. Either disable `All` for high-cardinality variables or, if your tool supports it, replace `All` with a literal regex bound to the top fifty entries.
- **Default values across teams.** A shared template dashboard's variable defaults will be wrong for some teams. Make defaults explicit and easy to override; do not bury them in JSON.
- **Variable order in the URL.** A linked dashboard receives variables as URL parameters; if the linked dashboard's variable order changes, old links break. Keep variable names and order stable; renames are major version bumps for a shared dashboard.

## Sources reviewed

- Open-source visualisation and dashboarding platform (AGPL-3): https://github.com/grafana/grafana
- Horizontally scalable metric store (Apache-2.0): https://github.com/cortexproject/cortex
- Long-term storage and global query layer for a pull-based metric system (Apache-2.0): https://github.com/thanos-io/thanos
- Time-series database optimised for high-cardinality metrics (Apache-2.0): https://github.com/VictoriaMetrics/VictoriaMetrics
- Pull-based metric collection and rule evaluation system (Apache-2.0): https://github.com/prometheus/prometheus
- Industry SRE workbook on alerting against SLOs (CC-BY): https://sre.google/workbook/alerting-on-slos/

## Linked notes

- [[domains/observability/instrumentation-coverage-reviewer]] — applies
- [[domains/observability/alert-policy-architect]] — see-also
- [[domains/observability/slo-designer]] — applies

<!-- skg-attribution:
  vault_path: "domains/observability/observability-dashboard-architect.md"
  skill_id: "019e91f9-701a-7bd1-ad87-36bc516d6598"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "bb06915a05ecb9d100270ba73b6a211e3bbe266aae59c459d63739cd8e7b6b59"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:39:34.070359Z -->
