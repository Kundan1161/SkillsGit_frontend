# AI DevOps Engineer (integration) — v1.0.0

> A curated, graph-linked vault of methodology for the AI DevOps Engineer (integration) role. Built by @curator-handle.

## What's in this vault

- 5 base methodology skills across 4 domain(s) (ci-cd, iac, incident, observability).
- Compose with persona overlays for recorded situations and on-call decisions.

## Summary

Integration test occupation.

## How to use this vault

1. Open the folder in **Obsidian** (no plugins required).
2. Press `Ctrl-G` to view the graph.
3. Start at `00-index.md`.
4. Drop the vault folder into your AI agent's working directory; point your agent at `vault.json` for routing.

## Attribution

This vault was assembled at 2026-01-01T00:00:00Z by Skills Git from:
- `@curator-handle/ai-devops-engineer-it` v1.0.0

See `vault.json` for the machine-readable manifest.

## License

Each file's license is governed by the buyer's purchase of the parent product. This bundle is per-buyer; the watermark in each file identifies the licensee. Redistribution is not permitted.
