---
id: jane-devops-demo/flaky-tests-demo
version: 1.0.0
name: Flaky tests demo
description: A test skill describing Flaky tests demo.
category: engineering
tags: ['flaky']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: memory_neuron
parent_occupation_id: skillsgit-curated/ai-devops-engineer
links:
  - target: base/ci-pipeline-architect
    relation: applies
neuron:
  situation: 'Demo situation.'
  decision: 'Demo decision.'
  outcome: 'Demo outcome.'
  recorded_at: '2024-10-15'
  confidence: 'high'
---

## When to use

Use this skill when Flaky tests demo applies.

## How to apply

1. Read the spec.
2. Apply it.

## Linked notes

- [[base/ci-pipeline-architect]] — applies

<!-- skg-attribution:
  vault_path: "personas/jane-devops-demo/incident-veteran/neurons/flaky-tests-demo.md"
  skill_id: "019e91fe-641c-77c3-9101-a8ad18340ac9"
  version: "1.0.0"
  kind: "memory_neuron"
  creator_handle: "jane-devops-demo"
  content_hash: "3d2e00565ca8334951d8197a4c6cb8cebe3a4875f72d558c1fb6cfba55a2f252"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:b7ae3081ba0f82e3 buyer:0d35f73d714c524b ts:2026-06-04T09:37:08.646010Z -->
