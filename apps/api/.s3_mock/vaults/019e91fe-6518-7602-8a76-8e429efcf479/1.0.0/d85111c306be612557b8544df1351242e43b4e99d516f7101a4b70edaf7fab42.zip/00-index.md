# Index — AI DevOps (compose)

## Base methodology

### incident

**Core**

- [[domains/incident/ops-runbook-generator]] — Ops Runbook Generator
- [[domains/incident/ops-incident-commander]] — Ops Incident Commander


### observability

**Core**

- [[domains/observability/alert-policy-architect]] — Alert Policy Architect


## Personas

_None bundled in this base build. Composition adds personas at delivery time — see `vault.json` after composition._
