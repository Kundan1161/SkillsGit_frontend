---
id: jane-demo/jane-neuron-2
version: 1.0.0
name: Jane Neuron 2
description: A test skill describing Jane Neuron 2.
category: engineering
tags: ['jane']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: memory_neuron
parent_occupation_id: occ-creator/ai-devops-engineer-it
links:
  - target: base/ops-incident-commander
    relation: applies
neuron:
  situation: 'Production incident at 3am.'
  decision: 'Roll back the deploy + write the runbook.'
  outcome: '15-min impact; runbook reused 3x.'
  recorded_at: '2024-10-15'
  confidence: 'high'
---

## When to use

Use this skill when Jane Neuron 2 applies.

## How to apply

1. Read the spec.
2. Apply it.

## Linked notes

- [[base/ops-incident-commander]] — applies

<!-- skg-attribution:
  vault_path: "personas/jane-demo/jane-incident-it/neurons/jane-neuron-2.md"
  skill_id: "019e91fe-64a1-7963-bafb-55b8a3dc94b0"
  version: "1.0.0"
  kind: "memory_neuron"
  creator_handle: "jane-demo"
  content_hash: "7825c371153e7b0f8a170c90ba2cb53d70db1745cbf9e8fbb613c0c0d1735d2b"
  built_at: "2026-01-01T00:00:00Z"
-->
