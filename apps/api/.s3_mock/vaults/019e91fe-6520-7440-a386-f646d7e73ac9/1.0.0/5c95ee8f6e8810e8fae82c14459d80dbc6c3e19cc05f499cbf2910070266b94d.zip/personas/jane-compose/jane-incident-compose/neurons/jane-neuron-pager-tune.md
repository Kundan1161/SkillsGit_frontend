---
id: jane-compose/jane-neuron-pager-tune
version: 1.0.0
name: Jane pager tune
description: A test skill describing Jane pager tune.
category: engineering
tags: ['jane']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: memory_neuron
parent_occupation_id: occ-compose/ai-devops-compose
links:
  - target: base/alert-policy-architect
    relation: applies
neuron:
  situation: 'Pager fired at 3am.'
  decision: 'Followed the rollback runbook.'
  outcome: '10-min impact; no escalation.'
  recorded_at: '2024-10-15'
  confidence: 'high'
---

## When to use

Use this skill when Jane pager tune applies.

## How to apply

1. Read the spec.
2. Apply it.

## Linked notes

- [[base/alert-policy-architect]] — applies

<!-- skg-attribution:
  vault_path: "personas/jane-compose/jane-incident-compose/neurons/jane-neuron-pager-tune.md"
  skill_id: "019e91fe-6521-70e2-8b7d-e389a6d47476"
  version: "1.0.0"
  kind: "memory_neuron"
  creator_handle: "jane-compose"
  content_hash: "47b40490de71fae9f594814967f6101ca0aa95b665c4bd75ba62ba786f907b19"
  built_at: "2026-01-01T00:00:00Z"
-->
