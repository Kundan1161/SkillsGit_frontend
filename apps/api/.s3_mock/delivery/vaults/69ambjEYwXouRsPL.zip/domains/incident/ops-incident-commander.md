---
id: occ-compose/ops-incident-commander
version: 1.0.0
name: Ops Incident Commander
description: A test skill describing Ops Incident Commander.
category: engineering
tags: ['ops']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: skill
---

## When to use

Use this skill when Ops Incident Commander applies.

## How to apply

1. Read the spec.
2. Apply it.

<!-- skg-attribution:
  vault_path: "domains/incident/ops-incident-commander.md"
  skill_id: "019e91fe-6517-7d10-90fc-c0dbf0fdbc87"
  version: "1.0.0"
  kind: "skill"
  creator_handle: "occ-compose"
  content_hash: "ebcc50e27f82a8e83b637eb5dd08471150f5b3970b03e3a590ab1ed370142794"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c5d2f2024a385834 buyer:14220e798dd1dd72 ts:2026-06-04T09:37:08.905378Z -->
