---
id: skillsgit-curated/kafka-streams-pipeline-designer
version: 1.0.1
name: Kafka Streams Pipeline Designer
description: Design a Kafka Streams topology — sources, state stores, joins, windows,
  exactly-once-v2, scaling, recovery, and the operational shape that survives production.
authors:
- name: skillsgit Curated
  handle: skillsgit-curated
  role: author
category: data
tags:
- niche:kafka-architecture
- kafka-streams
- stream-processing
- state-store
- windowing
- joins
- exactly-once-v2
- changelog-topic
links:
- target: kafka-topic-architect
  relation: applies
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gpt-4.1
  - gemini-1.5-pro
  tools_required:
  - file_io
  tools_optional:
  - web_search
  min_context_tokens: 32000
  estimated_tokens_per_invocation: 8000
trigger_keywords:
- kafka streams
- streams topology
- state store
- changelog topic
- stream-stream join
- stream-table join
- tumbling window
- hopping window
- session window
- exactly-once-v2
- eos-v2
- streams scaling
- standby replicas
- interactive queries
example_invocations:
- Design a Kafka Streams topology that enriches order events with customer state and
  emits per-customer rolling totals.
- We have a Streams app that restarts slowly because the state store rebuilds — design
  a fix.
- Pick window types and grace periods for a fraud-detection Streams pipeline.
inputs:
- name: pipeline_intent
  type: text
  required: true
  description: What the pipeline computes — inputs, outputs, stateful operations (joins,
    aggregations, windows), and the downstream consumer of the result.
- name: data_characteristics
  type: text
  required: false
  description: Throughput, message size, key distribution, late-arrival frequency,
    and event-time vs processing-time semantics.
- name: latency_target
  type: choice
  required: false
  description: Acceptable lag between input arrival and output emission.
  choices:
  - sub-second
  - near-real-time-seconds
  - eventual-minutes
- name: operational_constraints
  type: text
  required: false
  description: Deployment shape (Kubernetes, VMs), disk and memory per instance, instance
    count budget, and on-call appetite for state rebuilds.
- name: existing_topology
  type: text
  required: false
  description: For audits — current topology, observed issues (slow restart, high
    lag, frequent rebalances, incorrect window results).
outputs:
- name: topology_design
  type: markdown
  description: The topology — source topics, processing nodes, state stores, sinks
    — with reasoning per choice, and the exactly-once-v2 decision.
- name: state_and_scaling_plan
  type: markdown
  description: State store sizing, changelog topic configuration, standby replica
    plan, instance count plan, and disk and memory budget per instance.
- name: window_and_correctness_plan
  type: markdown
  description: Window types and grace periods, handling of late and out-of-order events,
    join semantics, and how the pipeline behaves on restart.
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release.
kind: skill
distribution:
  content_hash: ca2c066b7b2835635f518438f0e702eedbc0df545eab7197479c94f9529ece16
  signed_at: '2026-06-04T09:34:38.109045Z'
  signed_by: marketplace
  signature: 1f36fd4088cec6a147520a0cb376869309ee04047ef75d71da08c1d72a0da768
---

# Kafka Streams Pipeline Designer

## When to use

Use this skill when designing or auditing a Kafka Streams application. The skill picks the topology shape, state-store configuration, join and window semantics, exactly-once-v2 setting, and operational plan that prevent the usual production failures: slow restart, bloated changelog topics, wrong window results under late events, and frequent rebalances.

It applies to Apache Kafka Streams (the JVM library). Many of the design principles transfer to ksqlDB and to Flink, but the configuration knobs differ.

Common triggers:

- A team is building its first Streams app and needs a topology design before code.
- An existing Streams app restarts in 40 minutes because the state store rebuilds from the changelog each time; the team wants standby replicas.
- A team has a windowed aggregation producing wrong results because late events arrive after the window closes.
- A read-process-write pipeline needs exactly-once-v2 and the team wonders what changes.
- A team's Streams app rebalances every few minutes and cannot keep up.

Do not use this skill for:

- Designing the upstream topics (`kafka-topic-architect`).
- Choosing the schema (`kafka-schema-evolution-architect`).
- Picking consumer patterns for simple consumers that do not need state (`kafka-consumer-pattern-picker`).
- Stream processing on non-Kafka stacks (Flink, Spark Streaming, Beam). Concepts overlap; APIs and operational characteristics differ.

## Inputs

- `pipeline_intent` (required) — inputs, outputs, stateful operations needed, downstream consumer.
- `data_characteristics` — throughput, key distribution, late-arrival frequency, event-time vs processing-time.
- `latency_target` — drives commit interval, cache size, and window grace period choices.
- `operational_constraints` — instance count, disk and memory budget, deployment shape, restart tolerance.
- `existing_topology` — for audits, where the pain is now.

## How to apply

The steps produce three deliverables: a topology design, a state-and-scaling plan, and a window-and-correctness plan. Work them in order.

### 1. Frame the pipeline

1.1. Restate the pipeline in one paragraph. Identify each input topic, each transformation (stateless: filter, map, branch; stateful: aggregation, join, window), and the output sinks.

1.2. Identify whether the pipeline is **stateless** or **stateful**. Stateless pipelines (filter, map, branch, repartition) are simple — most of this skill does not apply. Stateful pipelines (aggregations, joins, windows) need state stores and changelog topics, which dominate the operational design.

1.3. Identify whether the pipeline is **event-time** or **processing-time**. Event-time is what the data says happened; processing-time is when Streams sees the data. Event-time is the right default for analytics and aggregations; processing-time is acceptable for low-latency triggers where the exact timing matters less.

1.4. Identify the **downstream consumer expectations**. A dashboard refreshing once a minute tolerates higher latency than a real-time alerting system. The expectation shapes commit interval and window grace.

### 2. Choose the high-level shape

2.1. **DSL or Processor API**: the DSL (`StreamsBuilder`, `KStream`, `KTable`, `KGroupedStream`) is the default. It encodes the common patterns and lets the runtime optimize. Drop to the Processor API only for transformations the DSL cannot express, such as multi-key state access or custom timing.

2.2. **KStream vs KTable**: a `KStream` is the event log; every record is a fact. A `KTable` is the current state per key; the latest record per key supersedes earlier ones. Pick `KTable` for state, `KStream` for events. Mixing them up is the most common modeling error in Streams.

2.3. **GlobalKTable** is a `KTable` replicated on every instance, used for stream-table joins against small reference data. It is loaded fully into local state on every instance, regardless of partitioning. Use for small dimensions (thousands to low millions of keys); too large and every instance carries unnecessary data.

2.4. **Repartition step**: any operation that changes the key (e.g. group-by on a non-key field) triggers an internal repartition topic. Treat repartition topics as first-class operational citizens — they need partition counts, retention, and observability.

### 3. Decide stateful operations

3.1. **Aggregation** (`groupByKey().aggregate()` or `count()` or `reduce()`) maintains a state store keyed by the group key. Pick the right aggregation function — `reduce` for the same-type fold, `aggregate` for a different output type.

3.2. **Stream-stream join** joins two event streams within a window. Output is one record per matching pair within the window. State store holds both streams' records for the window duration. Stream-stream joins are the most expensive operation; they require correct co-partitioning and adequate state-store memory.

3.3. **Stream-table join** joins each event against the current state of a table. Cheap when the table is local (KTable); the output is one record per stream event with the matched table state at the time of the join.

3.4. **Table-table join** joins two tables on their key, emitting the joined record on either side's update. Useful for keeping a derived materialized view in sync with two sources.

3.5. **Co-partitioning is required** for every join except global-table joins. Both inputs must have the same partition count and the same partitioning key. If they do not, repartition one side first.

3.6. Document each stateful node's state-store name. Names show up in changelog topic names and in metrics; defaults are unreadable.

### 4. Pick window types and grace periods

4.1. **Tumbling windows** are fixed-size non-overlapping windows. Use for aggregations where each event belongs to exactly one bucket — e.g. counts per hour.

4.2. **Hopping windows** are fixed-size with an advance interval smaller than the size, so windows overlap. Use for rolling aggregations — e.g. 5-minute totals updated every minute. Cost: each event lives in multiple windows simultaneously, multiplying state-store size.

4.3. **Session windows** are dynamic windows defined by an inactivity gap. Use for user-session-like aggregations where the boundary depends on the data. Sessions can merge when out-of-order events arrive.

4.4. **Sliding windows** (for joins) define the join match range relative to each event's timestamp.

4.5. **Grace period** is the additional time after window close during which late events are still accepted. Default behavior keeps the window state for this period. Set grace based on expected lateness, not on what would be most convenient. Common values: 30 seconds for low-latency pipelines, several minutes for analytics pipelines, hours for cross-region or batch-imported data.

4.6. **Window suppression** controls whether intermediate updates emit downstream. By default, every state change emits a record; use `suppress(Suppressed.untilWindowCloses(...))` to emit only the final result. Trade latency for clean output.

4.7. Document the chosen window type, size, advance interval (for hopping), grace period, and suppression policy per stateful node.

### 5. Decide exactly-once-v2

5.1. Set `processing.guarantee = exactly_once_v2` when the pipeline reads from Kafka, writes to Kafka (including state store changelogs and output topics), and the team needs no duplicates within Kafka.

5.2. EOS-v2 uses transactions internally; the producer, consumer, and state store updates are wrapped in a transaction that commits atomically. The latency cost is the transaction commit interval (`commit.interval.ms`, default 100 ms under EOS-v2). The throughput cost is modest on modern Kafka but non-zero.

5.3. Requirements for EOS-v2: Kafka brokers 2.5+, idempotent producer (automatic), `acks=all` (automatic), and the consumer reading at `isolation.level=read_committed` (automatic for Streams).

5.4. EOS-v2 does not extend across external systems. A Streams app that calls an external HTTP API mid-topology is not exactly-once for that call. Keep external calls out of EOS-v2 paths or accept the duplicate cost on the external side.

5.5. EOS-v2 is the right default for analytical and read-process-write topologies. Skip it only when the workload truly tolerates duplicates and the throughput cost matters.

### 6. Plan state stores

6.1. The default state store is **RocksDB**, persisted on local disk, backed by a changelog topic in Kafka. Streams reads from the changelog topic on restart to rebuild the state.

6.2. State store sizing matters for two reasons: local disk consumption (RocksDB write amplification) and changelog topic size (Kafka disk consumption). Aggregations on high-cardinality keys can dominate cluster disk; estimate per-key state size times the number of unique keys per partition.

6.3. **Changelog topic configuration** is automatic but reviewable. Streams creates changelog topics with `cleanup.policy=compact` for KTable-style stores and `cleanup.policy=compact,delete` for windowed stores (so windows beyond retention are eventually deleted). Verify the partition count matches the source topic; verify replication factor matches production standards.

6.4. **Cache size** (`cache.max.bytes.buffering`, deprecated in favor of `statestore.cache.max.bytes`) determines how many state-store writes Streams batches before emitting downstream. Larger cache reduces downstream traffic and changelog write frequency but increases latency. Default is reasonable for most pipelines; tune up for write-heavy aggregations.

6.5. **In-memory stores** are an option for small state and ephemeral computations. They still write to the changelog topic for durability. Use sparingly; RocksDB is the right default.

### 7. Plan scaling and standby replicas

7.1. The number of Streams instances cap is the partition count of the source topics. Beyond that, instances sit idle.

7.2. **Standby replicas** (`num.standby.replicas`) keep a hot copy of each partition's state store on another instance. On rebalance, the standby takes over without rebuilding from the changelog. Default 0; recommended 1 in production. Each standby roughly doubles local disk usage; budget accordingly.

7.3. **Static membership** (`group.instance.id`) reduces rebalance churn. With static membership, an instance restart does not trigger a rebalance immediately; the broker waits for the session timeout. Set the static id from a stable host or pod identity.

7.4. **Rebalance protocol**: Streams uses the cooperative incremental rebalance protocol by default in recent versions. Verify it is enabled in legacy deployments.

7.5. **Restart latency**: with standby replicas, restart is fast (seconds). Without standby replicas, restart rebuilds state from the changelog (minutes to hours, depending on state size and changelog read speed). Pick standby count based on tolerated restart time.

7.6. Document per-instance disk budget: active state + standby state + RocksDB write amplification factor + buffer for changelog compaction lag.

### 8. Decide commit interval and threading

8.1. **`commit.interval.ms`** controls how often Streams commits offsets and state-store changes. EOS-v2 default is 100 ms; non-EOS default is 30 s. Tighter intervals reduce downstream lag and replay-on-crash window; they also increase broker write rate.

8.2. **`num.stream.threads`** sets the per-instance thread count. More threads parallelize partition processing on a single instance. Cap at the partition count assigned to the instance.

8.3. **`max.task.idle.ms`** controls how long Streams waits at a stream-stream join for the other side to catch up before emitting with one side missing. Default 0 emits eagerly. Set positive when out-of-order arrivals across two streams cause join misses; the cost is buffering and latency.

8.4. **`processing.timeout.ms`** caps how long a single record can take to process before the task is considered stuck and forcibly rebalanced. Set high enough to accommodate the slowest expected message but low enough that a truly stuck instance is recovered.

### 9. Plan error handling

9.1. **Deserialization errors**: configure `default.deserialization.exception.handler` to send bad records to a DLQ instead of crashing the application. The default fails the application.

9.2. **Production exceptions**: configure `default.production.exception.handler` to handle broker-side errors. Default fails; in many cases, you want to log and continue, or route the record to a DLQ.

9.3. **Uncaught exceptions**: register a `StreamsUncaughtExceptionHandler`. Choices: replace the failing thread, shutdown the client, or shutdown the application. Choose deliberately; the default behavior may not be the right one.

9.4. **State store corruption**: rare but possible. Recovery is by deleting the local state directory and rebuilding from the changelog. Document this and the operational impact (state-rebuild time).

9.5. **Reset**: `kafka-streams-application-reset` resets the application's consumer offsets and internal topics. Use only intentionally; for testing or for re-running on historical data. Production resets are dangerous.

### 10. Plan observability

10.1. Critical metrics: process latency per task, commit latency, cache hit ratio, changelog send rate per state store, state-store size on disk, standby lag, rebalance count, dropped records (late-arrival counter when grace expires).

10.2. Lag alerts: consumer lag on source topics is the upstream signal; changelog producer lag is the downstream signal. Both matter.

10.3. Rebalance alerts: more than a small handful per hour is wrong.

10.4. State-store size alerts: a state store growing unboundedly indicates a key cardinality explosion or a missing tombstone strategy. Set a per-state-store size threshold.

10.5. **Interactive queries** expose state-store contents over a service-local API. They are useful for read-after-write checks and dashboards. Plan the access pattern (which instance owns which key, query routing) before adopting.

### 11. Plan the rollout

11.1. For greenfield: stand up the application against a non-production topic set first. Validate window correctness against known-good inputs. Move to production with a low-traffic feature flag.

11.2. For topology changes that touch state stores (aggregation logic, window size, join shape): in most cases, the changelog topic must be reset. Plan this. Strategies:

- Side-by-side deploy: run the new topology in parallel against a new output topic; consumers switch when validated; old topology retires.
- Reset: stop the application, reset internal topics, restart. State rebuilds; production output is delayed during the rebuild.

11.3. For Kafka version upgrades: review the Streams compatibility matrix; some changes (EOS protocol, rebalance protocol) require coordinated upgrades of brokers and clients.

11.4. Document the topology version. Streams does not version topologies natively; a topology change without re-keyed output topics can confuse downstream consumers.

### 12. Emit the design

12.1. Lead with the chosen topology shape, EOS setting, and standby replica plan.

12.2. List source topics, processor nodes, state stores, and sinks. For each stateful node, list its state-store name, store type, expected size, and changelog configuration.

12.3. List window types and grace periods per windowed node, with the rationale (expected lateness, output cadence).

12.4. List the scaling plan: instance count, threads per instance, standby replicas, disk and memory per instance.

12.5. List the failure-handling plan: deserialization, production, uncaught exception handlers, and the DLQ destination.

### Decision rules and heuristics

- **Streams is event-time first.** Use processing-time only when event-time is unavailable or business logic does not require it.
- **KTable for state, KStream for events.** Confusing them produces wrong results.
- **Standby replicas = 1 in production by default.** The cost is local disk; the gain is fast recovery.
- **EOS-v2 is the default for analytical pipelines.** It is cheaper than the data-correctness debugging it prevents.
- **Co-partition before you join.** Streams cannot fix mismatched partition counts at runtime.
- **Grace periods reflect data reality.** Set them from observed late-arrival patterns, not from convenience.
- **Suppress for clean output, not for fast output.** Suppression trades latency for downstream cleanliness.
- **GlobalKTable is for small dimensions.** A large GlobalKTable is a footgun.
- **External calls in Streams are not exactly-once.** Move them out of EOS-v2 paths or pay the duplicate cost.
- **Reset is production-dangerous.** Treat application-reset like dropping a database table.

### Edge cases

- **Skewed keys.** A few keys dominate state-store size and processing time. Sub-key or salting helps; document the trade-off in ordering.
- **Late-arriving events past grace.** They are dropped silently unless you handle them in the deserialization or production handler. Wire the dropped-record metric to an alert.
- **Topology changes without changelog reset.** Some changes are safe (adding a downstream filter); most stateful changes are not (changing aggregation logic, window size). Use the side-by-side pattern.
- **Multi-source joins with different event-time progression.** One source ahead of the other causes join misses. Tune `max.task.idle.ms`; in extreme cases, use processing-time semantics with explicit caveats.
- **State-store size explosion under hopping windows.** Hopping with small advance interval and large window creates many overlapping windows. Reduce overlap or move to tumbling.
- **Interactive queries during rebalance.** State is unavailable on the rebalancing instance. Either tolerate the gap or query the standby (Streams supports standby reads in recent versions).
- **Pipeline outputs to a topic also consumed by Streams.** Be careful about loops; document the input/output graph and forbid self-feed unless intentional.
- **Schema evolution on a Streams-produced topic.** Changes follow the same rules as `kafka-schema-evolution-architect`; the application that produces is the producer that must move first under BACKWARD compatibility.

## Outputs

- `topology_design` — Topology graph (sources, nodes, state stores, sinks), with per-node rationale, EOS-v2 decision, and DSL/Processor API choice.
- `state_and_scaling_plan` — State-store sizes, changelog topic configuration, standby replica count, instance count, threads per instance, disk and memory per instance.
- `window_and_correctness_plan` — Window types, grace periods, suppression, late-event handling, join idle-ms, restart behavior.

## Examples

### Worked example

Input excerpt:

> Pipeline: read `prod.orders.events` (order_id keyed, 24 partitions, ~5k msg/s peak) and `prod.customers.state` (customer_id keyed, compacted, ~2M keys). Enrich each order event with current customer state. Compute per-customer 1-hour rolling order totals updated every minute. Output: enriched order events to `prod.orders.enriched.events`; rolling totals to `prod.customers.hourly-totals`. Latency target: near-real-time. Restart should complete within 5 minutes. Late events: up to 30 seconds late are common; rare events arrive 5 minutes late.

Expected output sketch:

- Topology shape: `orders` as `KStream`; `customers.state` as `KTable` (or `GlobalKTable` if total state fits in memory — 2M keys × ~1 KB = 2 GB, GlobalKTable is feasible). Stream-table join on `customer_id`. Output 1: `prod.orders.enriched.events`. After enrichment, re-key by `customer_id`, repartition, group by `customer_id`, hopping window (size 1 hour, advance 1 minute, grace 60 seconds), aggregate sum of order totals, suppress until window closes (to emit one record per window per customer per minute). Output 2: `prod.customers.hourly-totals`.
- EOS-v2: yes. All side effects are Kafka writes. `commit.interval.ms = 100`.
- State stores: customer-state-store (KTable backing, or GlobalKTable replicated); customer-hourly-totals-store (windowed aggregation). Changelog topics: `streams-app.customer-state-store-changelog` (compact), `streams-app.customer-hourly-totals-store-changelog` (compact,delete with retention covering window + grace).
- Repartition: required after re-keying on `customer_id`. Internal topic `streams-app.repartition.by-customer-id` with 24 partitions to match the customers source. Document.
- Scaling: 6 instances, 4 stream threads each = 24 tasks matching the 24-partition topics. Standby replicas: 1 per task. Disk per instance: active state + standby state + RocksDB amp + headroom = ~10 GB target.
- Grace period: 60 seconds covers common lateness; the rare 5-minute outliers are dropped or accepted as late-arrival errors in the dropped-record metric.
- Suppression: yes on the hourly totals, off on the enrichment.
- Restart plan: with standby replicas, restart of a single instance reassigns its tasks to standbys in seconds; new instance rebuilds standby state in the background.
- Error handling: deserialization handler sends bad records to `streams-app.dlq.events`; uncaught exception handler replaces the failing thread up to 3 times, then shuts the application down to trigger a fresh start under the standby.

## Limitations

- The skill targets Kafka Streams. Concepts transfer to ksqlDB and to Flink with caveats; configuration knobs do not.
- It does not generate working code. It produces topology and configuration choices; the team writes the DSL.
- It does not benchmark state-store throughput. Targets come from operational defaults and rough sizing; load testing on a representative dataset is required before production.
- It assumes the source topics are well-designed. Poor partition keys or missing schemas upstream cannot be fixed inside Streams.
- It cannot guarantee correctness of business logic. Window semantics and join semantics are subtle; the pipeline still needs tests with deliberate late and out-of-order inputs.
- For pipelines that need windowing semantics beyond what Streams supports (custom session merging, event-time watermarks with complex skew handling), consider Flink. The skill does not pick between Streams and Flink; that is a separate decision.

## Sources reviewed

- https://github.com/apache/kafka
- https://github.com/confluentinc/kafka-streams-examples
- https://github.com/confluentinc/cp-demo
- https://github.com/apache/flink
- https://github.com/strimzi/strimzi-kafka-operator
- https://github.com/apache/avro

## Linked notes

- [[domains/platform/kafka-topic-architect]] — applies

<!-- skg-attribution:
  vault_path: "domains/platform/kafka-streams-pipeline-designer.md"
  skill_id: "019e91f9-6c32-7fe2-9309-a60733fba941"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "bfd9cfd453285e6af1f385a2e6affa55fe6c8bfec3c8c2ddf649c9e3989e202d"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:39:34.070492Z -->
