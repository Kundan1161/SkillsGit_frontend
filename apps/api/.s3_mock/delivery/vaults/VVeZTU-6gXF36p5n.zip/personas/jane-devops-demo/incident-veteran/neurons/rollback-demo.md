---
id: jane-devops-demo/rollback-demo
version: 1.0.0
name: Rollback demo
description: A test skill describing Rollback demo.
category: engineering
tags: ['rollback']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: memory_neuron
parent_occupation_id: skillsgit-curated/ai-devops-engineer
links:
  - target: base/ops-runbook-generator
    relation: applies
neuron:
  situation: 'Demo situation.'
  decision: 'Demo decision.'
  outcome: 'Demo outcome.'
  recorded_at: '2024-10-15'
  confidence: 'high'
---

## When to use

Use this skill when Rollback demo applies.

## How to apply

1. Read the spec.
2. Apply it.

## Linked notes

- [[base/ops-runbook-generator]] — applies

<!-- skg-attribution:
  vault_path: "personas/jane-devops-demo/incident-veteran/neurons/rollback-demo.md"
  skill_id: "019e91fe-641e-7e12-9b67-de0c6696f6ad"
  version: "1.0.0"
  kind: "memory_neuron"
  creator_handle: "jane-devops-demo"
  content_hash: "e2d903c6af5084610a816293cac4568173aa26d568ae34482d40a1c5c5dd901a"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:b7ae3081ba0f82e3 buyer:0d35f73d714c524b ts:2026-06-04T09:37:08.646014Z -->
