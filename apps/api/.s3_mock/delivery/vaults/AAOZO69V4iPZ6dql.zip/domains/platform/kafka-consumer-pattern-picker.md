---
id: skillsgit-curated/kafka-consumer-pattern-picker
version: 1.0.1
name: Kafka Consumer Pattern Picker
description: Pick the right Kafka consumer pattern — single consumer, consumer group,
  exactly-once with idempotent producer and transactions, dead-letter, retry topics,
  and offset commit strategy.
authors:
- name: skillsgit Curated
  handle: skillsgit-curated
  role: author
category: data
tags:
- niche:kafka-architecture
- kafka
- consumer-group
- exactly-once
- idempotent-producer
- transactions
- dead-letter
- retry-topic
links:
- target: kafka-streams-pipeline-designer
  relation: see-also
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gpt-4.1
  - gemini-1.5-pro
  tools_required:
  - file_io
  tools_optional:
  - web_search
  min_context_tokens: 32000
  estimated_tokens_per_invocation: 7000
trigger_keywords:
- kafka consumer
- consumer group
- exactly-once
- eos
- idempotent producer
- kafka transactions
- dead letter topic
- retry topic
- offset commit
- rebalance
- poison message
- read-process-write
- sticky assignor
- cooperative rebalance
example_invocations:
- We're getting duplicates downstream of our Kafka consumer — should we move to exactly-once?
- Design the retry and dead-letter strategy for a payment-processing consumer.
- Pick a rebalance strategy and offset-commit pattern for a slow-processing consumer
  group.
inputs:
- name: consumer_workload
  type: text
  required: true
  description: What the consumer does with each message, the side effects (database
    writes, external API calls, publishes to another topic), the throughput, and the
    cost of duplicate or lost processing.
- name: failure_modes
  type: text
  required: false
  description: Known transient failures (network, rate limits) and known permanent
    failures (deserialization, schema mismatch, business-rule rejection).
- name: latency_target
  type: choice
  required: false
  description: How quickly the consumer must process messages from arrival.
  choices:
  - interactive-sub-second
  - near-real-time-seconds
  - eventual-minutes
  - batch
- name: scaling_target
  type: text
  required: false
  description: Expected concurrency of the consumer group, whether instances run on
    stable hosts or autoscaling, and the partition count of the source topic.
- name: existing_pattern
  type: text
  required: false
  description: Current consumer behavior and observed problems (duplicates, lag, lost
    messages, frequent rebalances).
outputs:
- name: pattern_recommendation
  type: markdown
  description: The chosen consumer pattern, delivery-semantics target, retry-and-DLQ
    topology, rebalance strategy, and offset-commit approach with rationale.
- name: consumer_config_sketch
  type: markdown
  description: A named-property list of consumer and producer configuration choices
    the pattern requires (not vendor-specific code), with values and reasoning.
- name: failure_runbook
  type: markdown
  description: Per-failure-class instructions — what is retried where, what reaches
    the DLQ, what alerts fire, and how the operator drains the DLQ.
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release.
kind: skill
distribution:
  content_hash: 4d295f69fd3fc60754c1deb9f6848c0020523e054fa61d967af4515b8502d249
  signed_at: '2026-06-04T09:34:38.100577Z'
  signed_by: marketplace
  signature: df2fbf28383a227478e495bfdbbffad103e56f7123f7145f12e007712375c462
---

# Kafka Consumer Pattern Picker

## When to use

Use this skill when designing or fixing a Kafka consumer. The skill picks between the practical patterns — single consumer, consumer group with at-least-once, read-process-write with transactions for exactly-once-within-Kafka, and external-side-effect patterns where exactly-once cannot exist and idempotency is the answer.

It applies to Apache Kafka and Kafka-API-compatible brokers running version 2.5 or later (so transactions and the cooperative rebalance protocol are available). It assumes topics already exist; design those with `kafka-topic-architect`.

Common triggers:

- A consumer is producing duplicate downstream effects and the team is debating "switch to exactly-once".
- A consumer hits a poison message and the whole partition stalls because there is no DLQ.
- A consumer group rebalances every few minutes and processing tail latency is wrecked.
- A consumer commits offsets at the wrong moment and loses work after a crash.
- A new service joins a Kafka topic and the team needs to choose its consumer group identity, isolation, and retry behavior.

Do not use this skill for:

- The decision of whether to adopt Kafka at all (`eventing-architect`).
- Topic design (`kafka-topic-architect`).
- Streams-topology design where exactly-once-v2 is built in (`kafka-streams-pipeline-designer`).

## Inputs

- `consumer_workload` (required) — what the consumer does per message, side effects (DB writes, external calls, publishes), throughput, cost of duplicate or lost work.
- `failure_modes` — the kinds of failures expected. Transient versus permanent drives the retry strategy.
- `latency_target` — sets the offset-commit cadence and rebalance tolerance.
- `scaling_target` — partition count constrains the consumer group concurrency ceiling.
- `existing_pattern` — for retrofits, current pain points reveal which property is wrong.

## How to apply

The steps produce a concrete pattern, config sketch, and runbook. Walk them in order; each builds on prior choices.

### 1. Classify the side effect

1.1. The side-effect class governs achievable delivery semantics. The realistic classes:

- **In-Kafka only** — read from topic A, transform, write to topic B (or commit offset only). Transactions can give exactly-once-in-Kafka here.
- **In-Kafka plus same-database** — read from Kafka, write to a database, optionally publish to another Kafka topic. With careful use of an outbox or the Kafka Connect sink with deterministic upserts, this is effectively-once.
- **In-Kafka plus external API** — read from Kafka, call an external service. Cannot be exactly-once across systems. Idempotency on the external call is the only correct solution.
- **In-Kafka plus user-visible action** — read from Kafka, send an email or push notification, no idempotency token possible at the recipient. Duplicates may be user-visible. Design to minimize, not eliminate.

1.2. Write down the class explicitly. The right pattern follows from the class, not from the words "exactly-once".

### 2. Pick the delivery-semantics target

2.1. **At-most-once** — commit offsets before processing. Survives crashes by losing in-flight work. Acceptable for high-volume low-value telemetry; never for money or fulfillment.

2.2. **At-least-once** — process, then commit. Crashes replay the uncommitted prefix; duplicates are possible. This is the default for most workloads and pairs with consumer-side idempotency.

2.3. **Exactly-once-within-Kafka (EOS v2)** — for read-process-write loops where the only side effects are Kafka writes and consumer-offset commits. Use the transactional producer and `isolation.level=read_committed` consumer. Available since Kafka 2.5+ with idempotent producer + transactions; Kafka Streams uses it natively under `processing.guarantee=exactly_once_v2`.

2.4. **Effectively-once for external side effects** — at-least-once delivery plus consumer idempotency keyed on `event_id` or a producer-assigned idempotency key carried in headers. The downstream call deduplicates.

2.5. Reject the phrase "exactly-once" without naming which class above. It is the most over-claimed property in messaging.

### 3. Pick the consumer group topology

3.1. **Single shared consumer group** — one logical consumer for the topic. All instances of the consuming service share offsets; rebalance distributes partitions. This is the right default for a service that owns the work.

3.2. **One consumer group per downstream purpose** — billing has its own group, analytics has its own group, search has its own group. Each group has independent offsets and progress. This is the right model whenever consumers do different work with the same events.

3.3. **One-off ad-hoc group** — a debugging consumer reads with a unique random group id and does not commit offsets. Use this for inspection; never for production.

3.4. Consumer group ids should follow a convention: `{service}.{env}.{purpose}` (e.g. `billing.prod.invoice-emitter`). Each unique id is a unit of progress; reusing a group id across services silently mixes their offset state.

3.5. Two services should never share a consumer group id. The "first to commit wins" semantics break both services in ways they will not notice until production.

### 4. Pick the rebalance strategy

4.1. The default `RangeAssignor` is suboptimal for most cases. Prefer `CooperativeStickyAssignor` (cooperative rebalance protocol, available since 2.4+). It limits stop-the-world rebalances; instances keep their partitions across most join/leave events.

4.2. For consumers with **expensive partition state** (in-memory caches, downstream connection pools), sticky assignment matters even more. Losing a partition assignment to a rebalance forces state rebuild.

4.3. For consumers with **slow message processing** (each message takes hundreds of milliseconds or more), tune `max.poll.interval.ms` above the worst-case processing time times the batch size. The default 5 minutes is generous but easy to exceed with slow downstream calls.

4.4. For consumers that can pause work cleanly, implement a `ConsumerRebalanceListener` that commits offsets and releases external resources before partition revocation. Sloppy rebalance handlers cause double-processing across rebalances.

4.5. Consumer concurrency cap: a consumer group cannot usefully scale beyond the partition count of the topic. If the group hits the ceiling, the only options are increasing partitions (with the cost from `kafka-topic-architect`) or parallelizing within a single consumer instance (which complicates ordering).

### 5. Decide offset-commit cadence

5.1. **Auto-commit** (`enable.auto.commit=true`) is acceptable only when the consumer can tolerate duplicates on every crash and processing is fast. Auto-commit fires on a timer regardless of processing state. Default off in production.

5.2. **Manual commit-sync after processing** is the default for at-least-once with external side effects. Process the batch, then `commitSync`. On crash, the uncommitted prefix replays; the consumer must be idempotent.

5.3. **Commit-async with periodic sync** trades a tiny duplicate window for throughput. Acceptable when the consumer is idempotent and the throughput gain matters.

5.4. **Per-partition commit** is required when processing is parallelized within an instance — the offset committed must reflect what has actually finished, not the highest read. Track per-partition completion explicitly.

5.5. **Commit on rebalance revocation** — always. Otherwise a rebalanced partition replays from the last committed offset, which may be old. Combine with idempotency to be safe regardless.

### 6. Design the retry strategy

6.1. Classify each failure as **transient** or **permanent** at the point of detection.

- Transient: network timeout, 5xx from a downstream, rate-limit, transient lock conflict. Retry in place.
- Permanent: schema mismatch, deserialization error, business-rule rejection that will not change on retry, missing required field. Do not retry; send to DLQ.

6.2. **In-process retry** with bounded attempts and exponential backoff is sufficient for short transient failures. Default: 3–5 attempts, 100 ms initial, 2× backoff, capped at 30 s. Beyond that, the consumer holds up the partition.

6.3. **Retry topics** are the right pattern for longer-lived retries that should not block the partition. The shape: `topic.events` → consumer → on transient failure, publish to `topic.events.retry.30s` (or `retry.1m`, `retry.5m`) → retry consumer reads after delay → on success ack, on failure publish to next-longer retry topic → eventually DLQ after the retry chain exhausts.

6.4. Retry topics have their own ordering implications. Per-key ordering across the retry chain is no longer preserved; the consumer must tolerate out-of-order arrival. Document this.

6.5. Avoid the **single-retry-topic-with-delay-header** pattern unless you can run delayed delivery natively. Kafka does not have native scheduled delivery; emulating it adds a sleep loop or a scheduler outside Kafka. Tiered retry topics are simpler.

### 7. Design the dead-letter topic

7.1. One DLQ per consumer group, not one DLQ per topic. Different consumers fail for different reasons; mixing their DLQs makes triage impossible.

7.2. DLQ payload: the original record (key, value, headers, partition, offset, timestamp), the failure reason, the failure class (transient-exhausted vs permanent), the attempt count, the timestamp of last attempt, and the consumer identity. Use Kafka headers, not a wrapped envelope, when possible — keeps the original payload intact for replay.

7.3. DLQ retention: 30 days minimum. The operator needs time to triage. Some teams use 90 days for less-trafficked topics.

7.4. Ship a **replay tool** the day the DLQ is created. The tool reads the DLQ, applies a fix (or none), and republishes to the original topic at the original key. Without this tool, the DLQ becomes an unobserved swamp.

7.5. Alert on DLQ growth, not on DLQ presence. A handful of messages per day is normal; sudden spikes are an outage signal.

### 8. Decide whether to use Kafka transactions

8.1. Use transactions only when the side effects are all in Kafka (read-process-write) and the team genuinely needs no duplicates across that boundary. Examples: aggregation jobs that write to an output topic, idempotency-keyed enrichments that should not duplicate.

8.2. To enable, configure on the producer side: `enable.idempotence=true`, `transactional.id=<stable-per-instance-id>`, `acks=all`, and use the transactional API (`initTransactions`, `beginTransaction`, `send`, `sendOffsetsToTransaction`, `commitTransaction`). On the consumer side: `isolation.level=read_committed`.

8.3. `transactional.id` must be **stable per logical producer**, not per process restart. A consumer-group-coordinated assignment of transactional ids (one per partition assigned to the instance) is the production pattern. Random transactional ids on every restart silently drop fencing protection.

8.4. Transactions add latency (commit waits for all replicas) and complexity (the producer must handle fencing on rebalance). They are not free. Use them when the workload justifies the cost.

8.5. Outside of read-process-write, transactions do not give exactly-once. A consumer that writes to a database and also publishes to Kafka under a transaction is not atomic across both systems; the database write is independent.

### 9. Design for idempotent external side effects

9.1. For external API calls, the consumer is idempotent if duplicate processing of the same input produces the same external state. Achieve this with:

- An **idempotency key** sent on the external call. The key is `event_id`, or the consumer-computed hash of the input plus the consumer identity. The receiver deduplicates within a window.
- A **unique constraint** in the external system on a field derived from `event_id`. Duplicate inserts fail; the consumer treats the failure as success.
- A **read-then-write** check. Read the current state; only write if the new event is newer (by `occurred_at` or version) than the current state.

9.2. For internal databases the consumer owns, prefer **upserts keyed on `event_id`** or **conditional writes** keyed on the event version. Avoid read-then-write across separate transactions if concurrent consumers can race.

9.3. For state machines, design the consumer to be **monotonic on `occurred_at`**. Out-of-order events for the same key are no-ops if `occurred_at` is older than the current state. Document this.

9.4. For email and notification consumers, idempotency is partial. The best you can do is deduplicate by `event_id` within a recent-history window (e.g. last 24 hours of seen events kept in Redis). Pair with rate limiting so a runaway loop does not flood users.

### 10. Plan observability

10.1. Per-consumer metrics that must exist: consumer lag per partition, records consumed per second, processing time per record, commit success rate, rebalance count, DLQ publish rate, retry-topic publish rate per tier.

10.2. Lag alerts: page when lag exceeds `latency_target` translated into messages. For an interactive consumer with 1 s target and 1k msg/s topic, the page-worthy lag is 1k messages, not 1 million.

10.3. Rebalance alerts: page when rebalance frequency exceeds an expected baseline (say, more than 3 rebalances per hour). Frequent rebalances mean misconfigured timeouts or unstable instances.

10.4. Tracing: propagate `trace_id` from message headers into downstream calls. Lost traces in a Kafka hop are the most common observability gap.

10.5. Replay tooling tests should run weekly: the DLQ replay tool should be exercised against a fixture so it actually works when needed.

### 11. Emit the design

11.1. Lead with the chosen pattern in one sentence: delivery-semantics target, group topology, retry strategy, DLQ strategy.

11.2. Provide the consumer and producer config sketch as a list of key-value choices with rationale. Vendor-specific code is out of scope; the properties are universal.

11.3. The failure runbook lists each failure class and what happens to it: where it retries, when it stops, what reaches the DLQ, what alerts fire, who is on call.

11.4. Document the rebalance handler behavior: what is committed on revocation, what external resources are released.

### Decision rules and heuristics

- **Idempotency is the consumer's job.** Do not let "exactly-once" rhetoric talk a team out of idempotency keys.
- **One consumer group per purpose, never shared.** Group identity is permanent and is the unit of progress.
- **Process, then commit.** Auto-commit is wrong for anything that matters.
- **Transactions help for in-Kafka only.** They do nothing for external side effects.
- **Cooperative sticky is the right default assignor.** The legacy Range assignor causes unnecessary churn.
- **Retry within the consumer for short waits; retry topics for long waits.** A 5-minute sleep on the consumer thread is sometimes acceptable; a 1-hour sleep never is.
- **DLQ per consumer group.** Sharing DLQs across groups destroys triage.
- **Replay tooling on day one.** Build the tool when you build the DLQ.
- **Transactional ids are stable per logical producer.** Random ids defeat fencing.
- **Lag is the most actionable metric.** It is the single number that says "this consumer is healthy" or "this consumer is dying".

### Edge cases

- **Slow consumer holds up the partition.** Other partitions are unaffected, but per-key ordering on this partition stalls. Acceptable for a few seconds; escalate beyond that.
- **Poison message in a transactional consumer.** A bad message can prevent the transaction from committing. Wrap deserialization to catch and route to DLQ before the transactional path.
- **Consumer that needs ordering across partitions.** It does not exist in Kafka. Either reshape the topic key or introduce a downstream sequencer.
- **Large in-flight batches.** `max.poll.records` and `max.poll.interval.ms` interact. A batch that cannot finish within the interval triggers a rebalance and replays.
- **Reactive frameworks.** They process events on different threads than the poll loop; offset commits must reflect actual completion, not the poll-loop position.
- **Out-of-order DLQ replay.** A replayed DLQ message arrives long after the original event sequence. Consumers must tolerate it, either by treating the replay as the canonical state or by ignoring if newer state has been observed.
- **Consumer groups with one partition each.** Used for global-ordering hacks. Partition is then a single-point bottleneck; document and accept.

## Outputs

- `pattern_recommendation` — Chosen pattern, delivery-semantics target, retry topology, DLQ design, rebalance strategy, offset-commit approach, with rationale per choice.
- `consumer_config_sketch` — Producer and consumer property list (key=value with rationale) — names like `enable.idempotence`, `transactional.id`, `acks`, `isolation.level`, `partition.assignment.strategy`, `max.poll.interval.ms`, `enable.auto.commit`.
- `failure_runbook` — Per-failure-class flow: in-process retry, retry-topic chain, DLQ destination, alert thresholds, replay tool entry point.

## Examples

### Worked example

Input excerpt:

> Payment-processing consumer. Reads `prod.orders.events`, calls an external payment provider to charge the customer, writes a `payment_attempts` row to Postgres, publishes `prod.payments.events`. Throughput 200 msg/s peak. Latency target: near-real-time. Cost of duplicates: very high (we would charge the customer twice). Cost of lost messages: high. Current state: at-least-once at the consumer, no idempotency at the payment provider; we have observed double charges during rebalances.

Expected output sketch:

- Pattern: at-least-once consumer plus idempotency key on the external call. Reject Kafka transactions: the side effect is external, transactions cannot save us. Use the payment provider's idempotency key (the `event_id` from the order event). The consumer also computes a deterministic `payment_attempt_id = hash(event_id, attempt_class)` and uses a unique constraint in Postgres on this id.
- Group: `payments.prod.processor`, dedicated to this service.
- Retry: in-process exponential backoff for transient 5xx, capped at 4 attempts and 10 seconds total. Beyond that, publish to `prod.payments.events.retry.1m`, then `.retry.10m`, then DLQ.
- DLQ: `prod.payments.events.dlq`, 60-day retention. Replay tool checks idempotency-key state at the provider before republishing.
- Offsets: manual commit after Postgres write succeeds (the local row carries the idempotency state). Cooperative sticky assignor. `max.poll.interval.ms` raised to 90 s to accommodate slow provider responses.
- Observability: lag alert at 500 messages, rebalance alert at 5 per hour, DLQ-growth alert at 10 messages per minute. Trace id propagated to the provider as a request header.

Config sketch excerpt:

```
consumer.partition.assignment.strategy = CooperativeStickyAssignor
consumer.enable.auto.commit             = false
consumer.isolation.level                = read_uncommitted (no in-Kafka transactions)
consumer.max.poll.records               = 50
consumer.max.poll.interval.ms           = 90000

producer.enable.idempotence             = true
producer.acks                            = all
producer.retries                         = max int (idempotent producer caps retries internally)
```

Runbook excerpt:

- Transient provider 5xx → in-process retry × 4 with backoff; on exhaustion, publish to `.retry.1m`.
- Deserialization error → DLQ immediately, alert engineering on call.
- Unique-constraint violation on `payment_attempts` → treat as success (duplicate detected); commit and move on.
- DLQ alert fires → on-call inspects payload, decides whether to replay (after provider-side check) or discard.

## Limitations

- The skill does not generate vendor-specific client code. It produces property names and values portable across the major Kafka client libraries (Java, librdkafka-based, franz-go, kafka-go); the team adapts the property names to their client.
- It cannot guarantee an external system supports idempotency keys. If the downstream lacks them, the design degrades; the consumer must accept potential duplicates and choose its mitigation (rate limit, recent-history dedup, manual reconciliation).
- It assumes the topic design is sound. If keys are poorly chosen, the consumer pattern cannot rescue per-key ordering or balance.
- It does not size the consumer instance count. That depends on processing time per message and the partition count; benchmark and tune.
- It does not pick between consumer libraries. The choice between confluent-kafka-python, kafka-go, franz-go, and the Java client is a separate decision, usually dominated by team familiarity.

## Sources reviewed

- https://github.com/apache/kafka
- https://github.com/confluentinc/librdkafka
- https://github.com/segmentio/kafka-go
- https://github.com/twmb/franz-go
- https://github.com/strimzi/strimzi-kafka-operator
- https://github.com/debezium/debezium

## Linked notes

- [[domains/platform/kafka-streams-pipeline-designer]] — see-also

<!-- skg-attribution:
  vault_path: "domains/platform/kafka-consumer-pattern-picker.md"
  skill_id: "019e91f9-6c15-73b1-bbda-bcd8e330df33"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "83b4dd6c9250101ea97341f270bc9262c1776d8c302a6fb3d4725772e31496c5"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:07.961563Z -->
