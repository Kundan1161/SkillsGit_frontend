---
id: skillsgit-curated/imported-google-skills-waf-cost
version: 1.0.1
name: Google Cloud Well-Architected — Cost Optimization
description: Apply the Google Cloud Well-Architected Framework Cost Optimization pillar
  — FinOps culture, resource optimization, governance, and continuous monitoring.
authors:
- name: Google (original)
  handle: google
  role: author
- name: skillsgit Curated
  handle: skillsgit-curated
  role: maintainer
category: engineering
tags:
- imported
- source-google
- gcp
- well-architected
- cost-optimization
- finops
links:
- target: cloud-cost-audit
  relation: see-also
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gemini-2.0-pro
trigger_keywords:
- waf cost
- finops
- cost optimization
- rightsizing
- committed use discount
- spot vm
example_invocations:
- Audit a workload for cost-optimization gaps using the WAF framework.
- Recommend FinOps practices for a fast-growing team.
inputs: []
outputs: []
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Imported from google/skills under Apache-2.0.
kind: skill
distribution:
  content_hash: d0e1b96abcae824f40aec13b794feb37e78b8dcdebcf26e4d731e575227a1d55
  signed_at: '2026-06-04T09:34:38.063979Z'
  signed_by: marketplace
  signature: e772a3d222392233902a4556824741cc5ed0320d5094ffbec43c80cdb0b32d87
---

# Google Cloud Well-Architected Framework — Cost Optimization pillar

## When to use

Use this skill when evaluating a workload against the Google Cloud Well-Architected Framework Cost Optimization pillar, identifying cost optimization requirements, or generating actionable cost-optimization recommendations.

## How to apply

Anchor on the four core principles. Inventory the workload's current spending alignment, cost awareness culture, resource usage, and continuous optimization practices. Ask the workload assessment questions, then walk the validation checklist to score architectural alignment.

## Overview

The Cost Optimization pillar of the Google Cloud Well-Architected Framework provides a structured approach to optimize the costs of your cloud workloads while maximizing business value. Cloud costs differ significantly from on-prem CapEx models, requiring a shift to OpEx management and a culture of accountability (FinOps).

## Core principles

- Align cloud spending with business value: ground at https://docs.cloud.google.com/architecture/framework/cost-optimization/align-cloud-spending-business-value
- Foster a culture of cost awareness: https://docs.cloud.google.com/architecture/framework/cost-optimization/foster-culture-cost-awareness
- Optimize resource usage: https://docs.cloud.google.com/architecture/framework/cost-optimization/optimize-resource-usage
- Optimize continuously: https://docs.cloud.google.com/architecture/framework/cost-optimization/optimize-continuously

## Relevant Google Cloud products

- Visibility and monitoring: Cloud Billing reports, BigQuery billing export, Looker Studio, Billing alerts and budgets.
- Automation and optimization tools: Recommender / Active Assist, Cloud Hub Optimization, FinOps hub, Billing quotas.
- Efficient infrastructure: Managed and serverless services (Cloud Run, Cloud Run functions, GKE Autopilot); Compute Engine Spot VMs and CUDs; Cloud Storage Lifecycle Policies.
- Organization and governance: Resource Manager (Organizations, Folders, Projects), Labels, Organization Policy Service.

## Workload assessment questions

- How do you incorporate cost considerations into your cloud architecture design process?
- How do you foster a culture of cost awareness among your development teams?
- How do you monitor and manage cloud costs across different projects or departments?
- What strategies do you use to optimize the cost of your compute resources?
- How do you balance cost optimization with the need for agility and innovation?
- How do you ensure that you are not over-provisioning cloud resources?
- How do you use data and analytics to drive cost optimization decisions?
- How do you optimize costs in different environments (dev, test, prod)?
- How do you ensure that your cost-optimization efforts are sustainable and ongoing?
- How do you measure the success of your cloud cost-optimization initiatives?

## Validation checklist

- Cost Attribution: 100% of resources are labeled with key metadata (e.g., `env`, `team`, `app`).
- Granular Visibility: BigQuery billing export is enabled and used for regular cost reviews.
- Budgets and Alerts: Every project or business unit has defined budgets and active alerts.
- Rightsizing: Resources are regularly adjusted based on Active Assist Recommender suggestions.
- Commitment Strategy: Spend is reviewed monthly to optimize CUD coverage.
- Idle Resource Management: Unused disks, IP addresses, and idle VMs are identified and removed monthly.
- Managed Services: Serverless options are preferred for new workloads unless specific constraints exist.
- Storage Tiers: Lifecycle policies are active for all major storage buckets to minimize archival costs.

## Attribution

This skill was imported from `google/skills` under the Apache-2.0 license. Original content authored by Google. Modifications by skillsgit: frontmatter normalization to fit marketplace spec; addition of attribution and sources sections; addition of `## When to use` and `## How to apply` stubs required by our validator. The original LICENSE and NOTICE files are preserved at the source repository.

## Sources reviewed

- https://github.com/google/skills/tree/main/skills/cloud/google-cloud-waf-cost-optimization (Apache-2.0)

## Linked notes

- [[domains/cost/cloud-cost-audit]] — see-also

<!-- skg-attribution:
  vault_path: "domains/cost/imported-google-skills-waf-cost.md"
  skill_id: "019e91f9-6a53-7f72-976f-4a92b97df825"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "ea07247b5ccdd438446d3ea8b913ee0d3dc352319e44f3f338ad8fae5f14bd24"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:39:34.070107Z -->
