# Incident Veteran (sample data) — v1.0.0

> A persona overlay by @jane-devops-demo. Production DevOps incident response, on-call process design, cost
triage, observability cleanup.


## What's in this overlay

- 7 memory neuron(s) recording real situations, decisions, and outcomes.

## About the practitioner

Hi — I'm @jane-devops-demo, a SAMPLE persona shipped with the
Cycle-1 demo. Every neuron here is synthesised demonstration data,
not a real engineer's record. When the Skills Git platform ships
real practitioner personas, they replace this content.

## Attribution

This persona was assembled at 2026-01-01T00:00:00Z by Skills Git.
- `@jane-devops-demo/incident-veteran` v1.0.0

See `persona.json` for the machine-readable manifest fragment. Composition merges this overlay into the parent occupation vault at delivery time.

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:08.511394Z -->
