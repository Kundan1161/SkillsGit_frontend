---
id: skillsgit-curated/ops-runbook-generator
version: 1.0.1
name: Runbook Generator
description: Takes a recurring operational task — restart a stuck consumer, rotate
  a credential, drain a node — and produces an executable runbook with numbered steps,
  expected outputs, a troubleshooting tree for the common failure modes, and a clear
  escalation path.
authors:
- name: skillsgit Curated
  handle: skillsgit-curated
  role: author
category: operations
tags:
- runbook
- sre
- on-call
- operations
- automation
- documentation
- reliability
links:
- target: ops-incident-commander
  relation: see-also
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  tools_required: []
  min_context_tokens: 32000
  estimated_tokens_per_invocation: 8000
trigger_keywords:
- runbook
- playbook
- sop
- standard operating procedure
- operational procedure
- on-call task
- operations manual
- step-by-step
- troubleshooting tree
- escalation path
- automate this
- recurring task
example_invocations:
- Generate a runbook for restarting a stuck Kafka consumer group.
- We rotate database credentials every 90 days. Write the runbook.
- Draft an on-call runbook for failing traffic out of a cloud region.
inputs:
- name: task_description
  type: text
  required: true
  description: A plain-language description of the task — what it accomplishes, when
    it is performed, who typically performs it.
- name: known_steps
  type: text
  required: false
  description: Notes, transcripts, or rough steps the team already uses informally.
    Pasted chat where someone explained the procedure works fine.
- name: environment_context
  type: text
  required: false
  description: Tools, platforms, and CLIs available — for example, AWS CLI, kubectl,
    internal deployment tool name, ticketing system.
- name: failure_modes_seen
  type: text
  required: false
  description: Known things that go wrong during this task — partial failures, expected-but-confusing
    errors, edge cases the team has hit before.
outputs:
- name: runbook_document
  type: markdown
  description: A complete runbook with prerequisites, numbered steps, expected outputs,
    a troubleshooting tree, an escalation path, and an automation candidacy assessment.
- name: precondition_checklist
  type: markdown
  description: A standalone short checklist the on-call can run before starting the
    procedure, to confirm they have access and the system is in a state where the
    procedure applies.
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release.
kind: skill
distribution:
  content_hash: 5444fb67b17fb85c27fe189bb04c8e79e9c6346b9994462fb1c69add1c84b5dd
  signed_at: '2026-06-04T09:34:37.959863Z'
  signed_by: marketplace
  signature: 3f60b14cb3eddd7bc4bedf611b03ebb44805e57cc9c1371b9e35996e05558ce3
---

## When to use

Use this skill when a team finds itself answering the same operational question repeatedly — "how do I drain a node before patching?" "how do I rotate this credential?" "how do I replay the failed messages from yesterday?" — and the answer currently lives in one engineer's head, a Slack thread from six months ago, or a wiki page that has not been touched in a year. The skill takes whatever raw material exists (a transcript of someone explaining it, a half-written wiki page, or just a description of what the task needs to do) and produces an executable runbook a new on-call can follow at 2am.

The skill is intentionally biased toward runbooks for recurring, mostly-mechanical tasks where the steps converge on a stable shape: a precondition check, a sequence of commands, verifications, and an escalation path. It is not the right tool for fully novel incident response (use the Incident Commander Sidekick), for security playbooks with legal review requirements, or for tasks that are genuinely one-time and won't recur.

A runbook produced by this skill is a contract with the next on-call: if you follow these steps and the verifications succeed, you have done the right thing and should not be second-guessed. If a verification fails, the runbook tells you what to try next or who to call. That contract is the value, and the structure exists to deliver it.

## How to apply

The skill follows a twelve-step composition process. The order is opinionated: write the contract first (what success looks like), then the precondition (what must be true to start), then the steps (how to do it), then the failure modes (what to do when steps don't work), and finally the meta (automation candidacy, ownership, last-reviewed date).

1. **Restate the task as a single sentence with measurable success.** Not "deploy a fix" but "restart Kafka consumer group `payments-consumer` so that its lag returns to under 1000 messages within 5 minutes." Not "rotate the credential" but "replace the active AWS access key for service `risk-api` with a new key, with zero requests failing during the rotation window." The success criterion goes in the runbook header and is what every step ultimately serves.

2. **Identify who runs this and what they need before starting.** Specify the role (on-call for service X, member of the database team), the access required (production read, deploy permission, cloud console with a specific role), and any external coordination needed (ticket created, change-management approval, customer communication). If a step requires a permission the typical on-call doesn't have, surface that as a blocker — it is the single most common reason a runbook fails at 2am.

3. **Write a precondition checklist of three to seven items.** Each precondition is a yes/no question the on-call can answer in 30 seconds: "Is the affected service currently in a degraded state? (If no, do not run this runbook.)" "Do you have shell access to the production bastion?" "Has the on-call for the upstream service been notified?" The checklist is short by design; if it grows to 15 items the runbook is trying to do too much and should be split.

4. **Identify the natural backout point and state it before the steps.** Every runbook should answer "if I run step 1 and 2, can I still safely stop and walk away?" The answer is usually yes through the verification step and no after the destructive action. Mark this point explicitly in the runbook so the on-call knows where commitment kicks in. This single line of metadata prevents a class of incidents where someone interrupts a procedure halfway through because they realized it was the wrong runbook.

5. **Number every step and pair each with an expected output.** A step without an expected output is incomplete — the on-call cannot tell whether it worked. The expected output is what the on-call should see in the terminal, the cloud console, or the dashboard. It can be exact ("the command exits with code 0 and prints `consumer group reset to offset 47283`") or qualitative ("the dashboard at /metrics/consumer-lag should show lag descending below 1000 within 60 seconds"). Both are acceptable; what is not acceptable is "you should see something change."

6. **Make commands copy-pastable and parameterize variable parts.** Use explicit placeholder syntax like `<CONSUMER_GROUP>` or `<REGION>` and define every placeholder at the top of the runbook. Do not leave hostnames, service names, or credentials hardcoded; the runbook is going to be copied and adapted, and unparameterized values become subtle bugs in the next version.

7. **Insert verification steps between the destructive ones.** A good runbook reads "do X, verify X happened, do Y, verify Y happened" — not "do X, Y, Z, then check at the end." The reason is failure mode containment: if step Y silently failed, the verification after Y catches it before step Z compounds the problem. Verifications can be cheap (a quick dashboard glance) but they must be present.

8. **Build the troubleshooting tree as flat conditionals, not nested logic.** For each step that has a known failure mode, append a "if you see X, do Y" line. Example: "If `kafka-consumer-groups.sh --reset-offsets` returns `Error: GROUP_ID_NOT_FOUND`, the consumer is not currently registered — wait 60 seconds and retry; if still failing, the consumer service is not running, see the consumer-service runbook." Avoid deeply nested if/then/else trees — they are unreadable at 2am. A flat list of failure-mode → action lines is what gets read in practice.

9. **Define a single, explicit escalation path with thresholds.** The runbook must answer: when do I stop trying this and call someone? Use concrete triggers, not feelings. Examples: "If the procedure has not completed successfully after 20 minutes, page the database on-call." "If you observe any error containing `data corruption` or `checksum mismatch`, halt the procedure and page the storage team immediately, regardless of progress." The escalation path is named (page the on-call for service X via mechanism Y), not vague ("escalate to senior leadership"). Vague escalation = no escalation under stress.

10. **Add a post-execution section: what to record, who to notify, what comes next.** After the procedure succeeds, the on-call should know what to log in the operational ticket, whether to notify the customer-facing team, and whether any follow-up monitoring is required for the next N minutes or hours. This section is short — three to five bullets — but it closes the loop and prevents the silent-success failure mode where the procedure worked but nobody knew.

11. **Assess automation candidacy honestly and state it at the bottom.** For each runbook, write a one-paragraph "automation candidacy" note: would this be a good candidate for automation, and if so, what is blocking that today? Possible answers: "Yes — the procedure is fully scripted already and only needs a Slack-triggered wrapper. Estimated effort: 1 day." "Partially — steps 1–4 are mechanical, step 5 (decide which replica to promote) requires human judgment." "No — every invocation is materially different because the failure mode varies." This note is for the team's tech-debt backlog; it is not action for the on-call at 2am.

12. **End with ownership, last-reviewed date, and a one-line invitation to update.** Name the team that owns the runbook, the date it was last reviewed, and a line that explicitly invites edits — "if any step in this runbook surprised you, edit it before forgetting why." Runbooks rot quickly; the date-stamp and the invitation are how rot becomes visible.

### Standard runbook layout

The output document uses these section headers in this order:

1. `# Runbook: <task name>`
2. `## Purpose and success criterion`
3. `## When to run this (and when not to)`
4. `## Prerequisites`
5. `## Preconditions checklist`
6. `## Procedure`
   - Each step is a numbered `### Step N — <verb phrase>` followed by command(s), expected output, and inline failure-mode hints.
7. `## Verification (final)`
8. `## Troubleshooting`
9. `## Escalation`
10. `## After completion`
11. `## Automation candidacy`
12. `## Metadata` — owner, last reviewed, related runbooks.

### Composition rules

- **One verb per step.** "Restart the consumer and update the offset" is two steps. Splitting them lets the on-call verify each independently.
- **Imperative voice, second person implied.** "Run `kubectl drain node-7`." Not "the operator should run." Not "kubectl drain may be run."
- **No assumed knowledge.** If a step requires kubectl context to be set, the step is "set kubectl context" — do not assume it.
- **Reversibility marked.** Each step is implicitly reversible up to the backout-point marker, then explicitly irreversible after. Mark the boundary.
- **Limit the procedure to 7–15 steps.** A longer runbook should be split into two; an on-call following more than 15 sequential commands at 2am loses the thread.
- **Sample outputs in code blocks.** When showing expected output, use a code block with a leading comment indicating the source (terminal, dashboard URL, etc).

## Inputs

- **Task description (required, text).** Plain-language statement of what the runbook should accomplish, when it gets triggered, and who runs it.
- **Known steps (optional, text).** Anything the team already has — a transcript of an engineer explaining the procedure, a half-finished wiki page, a Slack thread. The skill normalizes whatever is provided.
- **Environment context (optional, text).** Tools available: cloud provider, orchestration platform, CLI tools, ticketing system, paging tool. The runbook commands will be tuned to these.
- **Failure modes seen (optional, text).** Specific things the team has hit before. This input is the single biggest quality multiplier — generic troubleshooting trees are weaker than ones that name real failures the team has experienced.

## Outputs

A complete markdown runbook following the layout above. Separately, a precondition checklist that can be pasted into a pre-flight ticket or chat thread without needing the rest of the document.

## Examples

### Worked example: restart a stuck Kafka consumer group

**Input task description:** "Sometimes the payments-consumer Kafka group stops processing — lag climbs and stays. We need to reset it. Usually the on-call for payments does this. It happens maybe twice a month."

**Input known steps:** "Pat usually does it. He shells into the bastion, runs `kafka-consumer-groups.sh --describe` to see the lag, then `--reset-offsets --to-latest` if lag is over 100k. Then watches the dashboard for 5 minutes to make sure lag drops."

**Input environment context:** "AWS, EKS, internal bastion `bastion.prod.internal`, Datadog dashboards. Kafka is MSK. Paging via PagerDuty."

**Input failure modes seen:** "Sometimes the reset command fails with `GROUP_ID_NOT_FOUND` because the consumer is genuinely down — that's a different problem and we shouldn't reset. Once we reset and processing started but slowly — turned out a downstream HTTP endpoint was rate-limiting us."

**Expected output (excerpted):**

> # Runbook: Reset payments-consumer Kafka consumer group
>
> ## Purpose and success criterion
>
> Restart processing on the `payments-consumer` Kafka consumer group when it has stalled. **Success:** consumer-group lag returns below 1000 messages within 5 minutes of completing the procedure, and remains there for 10 minutes.
>
> ## When to run this (and when not to)
>
> Run when: the `payments-consumer-lag` Datadog dashboard shows lag above 100,000 sustained for more than 10 minutes, and the consumer service itself is healthy (its pods are running and not crashlooping).
>
> Do **not** run when: the consumer service is down or crashlooping (see runbook `payments-consumer-crashloop`), or when lag is climbing because an upstream producer is sending more than normal (this resets your view of those messages — see runbook `producer-traffic-spike`).
>
> ## Prerequisites
>
> - PagerDuty on-call rotation: payments
> - Access required: bastion (`bastion.prod.internal`), kubectl context `prod-payments`, Datadog read
> - Notify before starting: post in `#payments-oncall` that you are running this — no approval gate, just a heads-up
>
> ## Preconditions checklist
>
> - [ ] The `payments-consumer-lag` dashboard shows lag > 100,000 sustained for > 10 minutes
> - [ ] The `payments-consumer` pods are running (`kubectl get pods -n payments -l app=payments-consumer` — all `Running`)
> - [ ] There is no active sev1 for downstream services (check `#incidents`)
> - [ ] You have an active SSH session to `bastion.prod.internal`
>
> If any item is unchecked, stop and reassess.
>
> ## Procedure
>
> **Backout point:** steps 1–3 are read-only and safe to abandon. Step 4 changes consumer offsets and is the irreversible action.
>
> ### Step 1 — Confirm the current lag and offsets
>
> ```bash
> kafka-consumer-groups.sh \
>   --bootstrap-server <MSK_BOOTSTRAP> \
>   --describe \
>   --group payments-consumer
> ```
>
> Expected output: a table with one row per partition showing CURRENT-OFFSET, LOG-END-OFFSET, and LAG. Confirm LAG is > 100,000 on at least one partition.
>
> If you see `Error: GROUP_ID_NOT_FOUND`: the consumer is not currently registered. Halt this runbook and follow `payments-consumer-crashloop` instead.
>
> ### Step 2 — Capture the current state for the postmortem
>
> Save the output of step 1 to a file or chat message. This is the only record of the lag before the reset.
>
> ### Step 3 — Verify no upstream traffic spike
>
> Open the Datadog dashboard `payments-producer-rate` and confirm the producer rate is within normal range (under 5,000 messages/sec). If it is above, halt this runbook and follow `producer-traffic-spike`.
>
> ### Step 4 — Reset the consumer offsets to latest [IRREVERSIBLE]
>
> ```bash
> kafka-consumer-groups.sh \
>   --bootstrap-server <MSK_BOOTSTRAP> \
>   --reset-offsets \
>   --to-latest \
>   --group payments-consumer \
>   --all-topics \
>   --execute
> ```
>
> Expected output: a table confirming the new offset for each partition. The exit code must be 0.
>
> If the command fails with a non-zero exit code: do not retry blindly. Capture the error and escalate per the Escalation section.
>
> ### Step 5 — Watch the lag descend
>
> Open the `payments-consumer-lag` dashboard. Within 5 minutes the lag should fall below 1000.
>
> If lag descends below 1000 within 5 minutes: proceed to Verification.
> If lag descends but slowly (still > 10,000 after 5 minutes): a downstream is rate-limiting. Run `kubectl logs -n payments -l app=payments-consumer --tail=200` and look for HTTP 429 responses. If present, this is no longer the right runbook — escalate to the downstream service's on-call.
> If lag does not move at all: the reset did not take effect. Escalate.
>
> ## Verification (final)
>
> - Consumer-group lag is below 1000.
> - The dashboard shows sustained processing rate ≥ producer rate.
> - No new alerts have fired in the 10 minutes since reset.
>
> ## Troubleshooting
>
> - `GROUP_ID_NOT_FOUND` at step 1 → consumer is down; use `payments-consumer-crashloop` runbook instead.
> - Reset command returns non-zero → do not retry; escalate to the platform team's on-call.
> - Lag descends slowly (HTTP 429 in consumer logs) → downstream rate-limiting; escalate to the affected downstream's on-call.
> - Lag does not descend at all → the consumer is registered but not consuming; restart the consumer pods with `kubectl rollout restart deployment/payments-consumer -n payments` and retry from step 1.
>
> ## Escalation
>
> - 20 minutes after Step 4 without success → page the platform team via PagerDuty service `platform-oncall`.
> - Any error containing `data loss` or `corruption` → halt and page `storage-oncall` immediately, regardless of progress.
> - Lag exceeds 1,000,000 at any point during the procedure → page payments engineering manager (escalation is automatic at this threshold; it indicates customer-visible impact).
>
> ## After completion
>
> - Post in `#payments-oncall` with the timing: when you started, when lag dropped below 1000, and any failure modes you hit.
> - Open a ticket in the payments backlog tagged `runbook-execution` with the bash output from steps 1 and 4.
> - Monitor the lag dashboard for the next 30 minutes; if it climbs again, you may have addressed the symptom but not the cause — open a ticket to investigate.
>
> ## Automation candidacy
>
> Strong candidate. Steps 1, 3, 4, and 5 are fully scripted. The judgment calls are: deciding whether to run (currently in the precondition checklist) and recognizing the "downstream rate-limiting" failure mode (recognizable from log scan). A ChatOps command `/payments reset-consumer-lag` that runs the precondition checks, performs the reset, and watches the dashboard for 5 minutes would replace 80% of human invocations. Estimated effort: 2–3 days.
>
> ## Metadata
>
> - Owner: payments team
> - Last reviewed: 2026-05-14
> - Related runbooks: `payments-consumer-crashloop`, `producer-traffic-spike`
> - If any step here surprised you when you ran it, edit this runbook before you forget why.

## Limitations

- The skill produces runbooks; it does not test them. A runbook that has never been executed once after generation is unproven. The team must run it the first time in a low-stakes context (planned maintenance window) before treating it as production-grade.
- The skill cannot verify that command syntax is current. CLI tools update — `kubectl drain` flags change, AWS CLI subcommands rename. Treat exact command syntax as a starting point that needs validation against the current tool version.
- The skill leans on the inputs it is given. A vague "we sometimes reset the consumer" input produces a vague runbook. The single biggest quality lever is the **failure modes seen** input — naming real, specific failures the team has hit produces a runbook that an on-call recognizes.
- The skill does not know your organization's escalation tree. It will name role categories (the on-call for service X), and the team must replace those with the actual paging mechanism and contact names.
- The automation candidacy assessment is heuristic. A skill output that says "strong candidate" is not a commitment that the automation will work; it is a hint for the backlog. Real automation requires its own design and review.
- Security-sensitive runbooks (key rotation, certificate replacement, credential revocation) often have audit and compliance requirements that this skill does not encode by default. Add them in a manual edit pass before publishing.

## Sources reviewed

- https://github.com/PagerDuty/incident-response-docs
- https://github.com/braintree/runbook
- https://github.com/aws-samples/aws-incident-response-playbooks
- https://github.com/austinsonger/Incident-Playbook
- https://github.com/meirwah/awesome-incident-response

## Linked notes

- [[domains/incident/ops-incident-commander]] — see-also

<!-- skg-attribution:
  vault_path: "domains/incident/ops-runbook-generator.md"
  skill_id: "019e91f9-7090-7562-9d3f-d75218e19aa0"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "94c8e45a4267cd7cbdb06c0b4a5b99a1f4065ce53e5f04d02087fca4303f32f5"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:39:34.070269Z -->
