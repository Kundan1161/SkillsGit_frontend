# Index — AI DevOps Engineer (demo)

## Base methodology

### ci-cd

**Core**

- [[domains/ci-cd/ci-pipeline-architect]] — CI Pipeline Architect


### incident

**Core**

- [[domains/incident/ops-runbook-generator]] — Ops Runbook Generator


### observability

**Core**

- [[domains/observability/alert-policy-architect]] — Alert Policy Architect


## Personas

_None bundled in this base build. Composition adds personas at delivery time — see `vault.json` after composition._

<!-- license:b7ae3081ba0f82e3 buyer:0d35f73d714c524b ts:2026-06-04T09:37:08.645949Z -->
