---
id: jane-demo/jane-neuron-1
version: 1.0.0
name: Jane Neuron 1
description: A test skill describing Jane Neuron 1.
category: engineering
tags: ['jane']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: memory_neuron
parent_occupation_id: occ-creator/ai-devops-engineer-it
links:
  - target: base/ops-runbook-generator
    relation: applies
neuron:
  situation: 'Production incident at 3am.'
  decision: 'Roll back the deploy + write the runbook.'
  outcome: '15-min impact; runbook reused 3x.'
  recorded_at: '2024-10-15'
  confidence: 'high'
---

## When to use

Use this skill when Jane Neuron 1 applies.

## How to apply

1. Read the spec.
2. Apply it.

## Linked notes

- [[base/ops-runbook-generator]] — applies

<!-- skg-attribution:
  vault_path: "personas/jane-demo/jane-incident-it/neurons/jane-neuron-1.md"
  skill_id: "019e91fe-64a0-7aa1-82db-7ae4d0bea360"
  version: "1.0.0"
  kind: "memory_neuron"
  creator_handle: "jane-demo"
  content_hash: "be57e6944ac42ab8e5d74df9e34407e8bd3525a526629c1e94d54242ff61a0ae"
  built_at: "2026-01-01T00:00:00Z"
-->
