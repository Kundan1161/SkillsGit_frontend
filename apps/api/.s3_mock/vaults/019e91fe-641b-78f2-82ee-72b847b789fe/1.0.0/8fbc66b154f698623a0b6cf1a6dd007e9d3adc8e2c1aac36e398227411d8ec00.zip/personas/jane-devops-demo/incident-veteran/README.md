# Incident Veteran (demo) — v1.0.0

> A persona overlay by @jane-devops-demo. DevOps on-call

## What's in this overlay

- 2 memory neuron(s) recording real situations, decisions, and outcomes.

## About the practitioner

Hi I'm Jane-Devops-Demo.

## Attribution

This persona was assembled at 2026-01-01T00:00:00Z by Skills Git.
- `@jane-devops-demo/incident-veteran` v1.0.0

See `persona.json` for the machine-readable manifest fragment. Composition merges this overlay into the parent occupation vault at delivery time.
