---
id: skillsgit-curated/ops-runbook-generator
version: 1.0.0
name: Ops Runbook Generator
description: A test skill describing Ops Runbook Generator.
category: engineering
tags: ['ops']
license_type: free
ai:
  required_models:
    - claude-sonnet-4-7
kind: skill
---

## When to use

Use this skill when Ops Runbook Generator applies.

## How to apply

1. Read the spec.
2. Apply it.

<!-- skg-attribution:
  vault_path: "domains/incident/ops-runbook-generator.md"
  skill_id: "019e91fe-6547-7cf1-8254-1465c122213e"
  version: "1.0.0"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "9f70a66b80d3d3d3f4433d844193755f3886a764ca41aad6cf7dd1d97208a569"
  built_at: "2026-01-01T00:00:00Z"
-->
