---
id: skillsgit-curated/kafka-schema-evolution-architect
version: 1.0.1
name: Kafka Schema Evolution Architect
description: Design a Kafka schema evolution policy — Avro vs Protobuf vs JSON Schema,
  compatibility modes, registry placement, breaking-change governance, and producer-and-consumer
  rollout.
authors:
- name: skillsgit Curated
  handle: skillsgit-curated
  role: author
category: data
tags:
- niche:kafka-architecture
- kafka
- schema-registry
- avro
- protobuf
- schema-evolution
- compatibility
- governance
links:
- target: kafka-topic-architect
  relation: applies
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gpt-4.1
  - gemini-1.5-pro
  tools_required:
  - file_io
  tools_optional:
  - web_search
  min_context_tokens: 32000
  estimated_tokens_per_invocation: 7000
trigger_keywords:
- kafka schema
- schema registry
- avro evolution
- protobuf evolution
- schema compatibility
- backward compatibility
- forward compatibility
- full compatibility
- breaking schema change
- schema versioning
- subject naming
- dual publish
- schema governance
example_invocations:
- We want to switch from JSON to Avro on our Kafka topics — design the rollout.
- Our producers keep breaking consumers with schema changes; design a compatibility
  policy.
- We need to remove a field from an event schema — what's the safe rollout?
inputs:
- name: current_state
  type: text
  required: true
  description: Existing serialization (JSON, Avro, Protobuf, none), whether a schema
    registry exists, current pain points, and the topics in scope.
- name: organization_shape
  type: text
  required: false
  description: Number of producer and consumer teams, deployment cadence, language
    mix, and how independently teams can move.
- name: change_examples
  type: text
  required: false
  description: Recent and upcoming schema changes the team needs to handle (add field,
    remove field, rename, type change, split entity).
- name: governance_appetite
  type: choice
  required: false
  description: How much process the team can sustain around schema changes.
  choices:
  - strict-cab
  - lightweight-review
  - library-only
  - none
- name: tooling_constraints
  type: text
  required: false
  description: Mandated languages, code-generation tooling availability, existing
    schema registry choices, and licensing constraints on registry software.
outputs:
- name: schema_policy
  type: markdown
  description: Chosen serialization format, registry placement, subject naming, compatibility
    mode per topic kind, and the breaking-change governance rules.
- name: rollout_playbook
  type: markdown
  description: Step-by-step plan for the common evolution scenarios — add field, deprecate
    field, remove field, rename, type change, split entity — with producer-then-consumer
    ordering.
- name: migration_plan
  type: markdown
  description: If the team is switching formats or introducing a registry, the migration
    sequence with reversibility checkpoints.
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release.
kind: skill
distribution:
  content_hash: 6e859cca79b40538b0dbcdf7d720022c0f6963faff3caacfefaa2889a1263b27
  signed_at: '2026-06-04T09:34:38.117511Z'
  signed_by: marketplace
  signature: 97c188bf5dd5ecbcd91abad02ae30e3789162fd9d86170b1f7513038fa38e921
---

# Kafka Schema Evolution Architect

## When to use

Use this skill when a team needs to keep Kafka event and entity schemas evolvable without breaking the producers and consumers that depend on them. The skill picks a serialization format, a registry strategy, a subject-naming convention, compatibility modes per topic, and a governance process. It also produces playbooks for the recurring evolution scenarios.

It assumes Kafka topics exist (see `kafka-topic-architect`) and consumers exist (see `kafka-consumer-pattern-picker`). It is opinionated about Avro and Protobuf over loose JSON.

Common triggers:

- A team has been shipping JSON without schemas and producers keep breaking consumers on what should have been compatible changes.
- A team is adopting a schema registry and needs to pick compatibility modes per topic before importing schemas.
- A producer must rename or remove a field that consumers depend on and the team wants a safe rollout.
- A migration from one serialization format to another is on the table (JSON → Avro, Avro → Protobuf).
- A regulator or auditor needs a documented schema history per topic.

Do not use this skill for:

- Designing topics themselves (`kafka-topic-architect`).
- Picking consumer patterns (`kafka-consumer-pattern-picker`).
- API schema design for HTTP services. The principles overlap but the rollout mechanics differ.
- Recommending specific schema-registry software. Many registry products exist with various licenses; this skill covers the policy and rollout, not the procurement.

## Inputs

- `current_state` (required) — current serialization, whether a registry exists, current pain, and topics in scope.
- `organization_shape` — number of producer and consumer teams, deploy cadence, language mix. Affects how aggressive the rollout can be.
- `change_examples` — pending changes shape the playbooks. Recent breakages reveal what the policy must prevent.
- `governance_appetite` — sets the weight of review and the strictness of registry-enforced compatibility.
- `tooling_constraints` — language mix, registry choices, licensing constraints. Some registries are not freely licensed; the skill defers the choice to the team but flags the implication.

## How to apply

The steps produce three deliverables: a schema policy, a rollout playbook, and (if needed) a migration plan. Work them in order.

### 1. Pick the serialization format

1.1. The realistic choices for Kafka payloads are **Apache Avro**, **Protocol Buffers (Protobuf)**, or **JSON Schema**. Pick one per system, not per topic.

1.2. **Avro** strengths: compact binary, rich type system, designed-in evolution rules, mature Confluent-style registry integration, broad Kafka ecosystem support. Avro stores the writer schema reference inline (via registry id), reducing payload size. Avro is Apache-2.0; references: github.com/apache/avro.

1.3. **Protobuf** strengths: ubiquitous code generation across languages, gRPC interop, field-number-based evolution that is hard to get wrong by accident, good observability tooling. Protobuf is BSD-3-Clause; references: github.com/protocolbuffers/protobuf. Protobuf is less self-describing than Avro in the registry sense; the schema lives in version control and the registry stores the schema text.

1.4. **JSON Schema** strengths: human-readable on the wire, easy to debug, lowest tooling barrier. Costs: larger payloads, looser evolution semantics, harder to enforce backward compatibility at the registry. Pick JSON Schema only if the team is unwilling or unable to adopt binary serialization.

1.5. Heuristic:

- Polyglot organization with Kafka-first stack and analytics consumers: Avro.
- Organization that already runs Protobuf for service APIs: Protobuf in Kafka, too.
- Small team starting out, willing to migrate later: JSON Schema with a registry. Migration to Avro or Protobuf is feasible but is a project.

1.6. Mixing formats per topic is a smell. Allow it only for legacy migration with a sunset date.

### 2. Place the schema registry

2.1. A registry is the contract layer. The skill assumes one exists or will be stood up. Concrete registry products vary in licensing; the team picks one that fits the allowlist and budget. The policy below is registry-product-agnostic.

2.2. Registry responsibilities:

- Store the canonical schema text per subject and version.
- Enforce a compatibility mode on register.
- Vend schema ids to producers and consumers.
- Optionally, serve schemas to code generators at build time.

2.3. Network placement: the registry is on the same network as the brokers and clients. High availability and low latency matter; producers and consumers call it on every new schema id.

2.4. Authentication: the registry must require authentication for writes. Schema overwrites and registrations are privileged operations.

2.5. Schemas are content-addressable. The wire format is `magic-byte | schema-id | payload-bytes`. Consumers cache the schema by id; producers cache the id by schema text. Both caches are essential for performance.

### 3. Name subjects

3.1. The subject is the registry-side name under which schema versions are kept. The most common conventions:

- **TopicNameStrategy** — subject is `{topic}-key` and `{topic}-value`. One schema per topic side. Default in most registries.
- **RecordNameStrategy** — subject is the fully qualified record type name. Allows multiple record types on one topic.
- **TopicRecordNameStrategy** — subject is `{topic}-{record-type}`. Permits multiple types per topic while keeping topic scoping.

3.2. Default: **TopicNameStrategy with one record type per topic**. Simplest to reason about; matches the one-topic-per-aggregate guidance from `kafka-topic-architect`.

3.3. Use **TopicRecordNameStrategy** when the topic carries multiple event types per aggregate (e.g. `order.placed`, `order.cancelled`, `order.shipped` on `prod.orders.events`). The consumer dispatches on the record type after deserialization.

3.4. Do not use **RecordNameStrategy** unless one record type genuinely flows across many topics; it complicates per-topic compatibility enforcement.

3.5. Subject naming is hard to change later because the registry indexes on it. Document the choice and apply it consistently.

### 4. Pick compatibility modes per topic kind

4.1. The standard compatibility modes:

- **BACKWARD** — new schema readable by code that was generated from the previous schema (consumers can be upgraded later than producers). Add optional field with default, remove field, are safe.
- **FORWARD** — new schema produces data readable by consumers using the older schema (producers can be upgraded later than consumers). Add field with default, remove optional field, are safe.
- **FULL** — both BACKWARD and FORWARD. The intersection is small but the safest.
- **NONE** — anything goes. Reserve for sandboxes.
- **TRANSITIVE** variants — apply the check against all prior versions, not just the immediately previous. Recommended for production.

4.2. **Default per topic kind**:

- Event topics consumed by many independent teams: **BACKWARD_TRANSITIVE**. Producers can evolve; consumers upgrade on their own schedule.
- Compacted entity topics with replay consumers: **FULL_TRANSITIVE**. Old data must remain readable forever and new data must be readable by old consumers.
- Internal-team-only topics with coordinated deploys: **BACKWARD** (non-transitive) is acceptable as a starting point.

4.3. Set the mode at the subject level via the registry's API or admin UI. Document it in the topic manifest alongside other topic properties.

4.4. Compatibility checks are a publish-time guardrail. They do not prevent runtime bugs from consumer code that ignores defaults or misreads optional fields; the policy is necessary but not sufficient.

### 5. Codify the evolution playbook

5.1. **Add an optional field with a default** — backward-compatible in Avro and Protobuf. Producer side: ship the new schema, write the new field where applicable. Consumer side: upgrade at leisure to read the new field; existing consumers see the default. No coordination needed.

5.2. **Make an existing required field optional** — usually backward-compatible. Verify against the registry's compatibility check. Test against the deserializer; some languages handle optional-from-required in subtle ways.

5.3. **Deprecate a field** — mark deprecated in the schema text (Avro: doc string; Protobuf: `[deprecated = true]`). Producers stop populating it on a known date. Consumers stop reading it. The field stays in the schema for a full deprecation window (default 6 months). Only then proceed to removal.

5.4. **Remove a field** — backward-compatible if the field had a default and no consumer reads it as required. Avro: the field disappears from the writer schema; readers fall back to their schema default. Protobuf: the field number must remain reserved (`reserved 7;`) to prevent accidental reuse. Always reserve removed Protobuf field numbers.

5.5. **Rename a field** — not directly supported in Avro or Protobuf as a single operation. Two-step: add the new field, dual-populate for the deprecation window, mark the old field deprecated, then remove. Do not let the field name change atomically.

5.6. **Change a field type** — almost always breaking. Avro permits a small set of widening promotions (int → long → float → double); Protobuf permits compatible numeric widening within the int family. Anything else: new field, dual-populate, deprecate old, remove old.

5.7. **Split or merge entities** — never an in-place schema change. Create new topics with new schemas; dual-publish for the migration window; cut consumers; retire the old topic.

5.8. **Hard breaking change** with no compatible path: new topic, new subject, new major version. Migrate consumers individually. The previous topic continues to receive writes during the migration; retire only after the last consumer moves.

### 6. Govern who can break what

6.1. Compatibility mode is the technical guardrail; governance is the human guardrail. Two extremes to avoid:

- "Anyone can register anything" — schemas drift; consumers break.
- "Every schema change requires a CAB review" — teams smuggle schemas around the process; the policy reflects nobody's reality.

6.2. The workable middle: schemas live in version control alongside the producer code. Pull requests touching a schema require review from the topic owner. CI runs the registry's compatibility check against the registered current version and fails the build on incompatibility. Registry write is automated from the CI step on merge.

6.3. Major (incompatible) version bumps require explicit sign-off from the topic owner and announcement to subscribed consumers. The deprecation window is non-negotiable.

6.4. Maintain a `schema-owners.md` per repository or per registry namespace. Schema reviews route to the owner.

6.5. Block schema changes in production deployments that did not pass through CI. The registry should accept writes only from a service account belonging to CI.

### 7. Plan the rollout sequence for each change

7.1. The right sequence depends on the compatibility mode:

- **BACKWARD compatibility**: producers upgrade first, consumers later. New schema reads by old consumer code is the property guaranteed.
- **FORWARD compatibility**: consumers upgrade first, producers later. New consumer code reading old data is the property guaranteed.
- **FULL compatibility**: either order is safe; pick the operational easier one.

7.2. The skill recommends **BACKWARD_TRANSITIVE for events**, which means producers move first. This is the easier human flow because producers are typically a single team while consumers are many.

7.3. For deprecation:

1. Publish the new schema with the new field, deprecate the old field.
2. Producers populate both fields during the deprecation window (dual-populate).
3. Consumers migrate to the new field one at a time.
4. After the window, producers stop populating the old field.
5. Remove the field from the schema (or reserve the field number for Protobuf).

7.4. For format migration (e.g. JSON → Avro):

1. Stand up the registry; register the current schema as Avro.
2. Producers dual-publish: same payload to the existing JSON topic and a new Avro topic.
3. Consumers migrate to the new topic one at a time, validating equivalence.
4. After all consumers move, producers retire the JSON topic.
5. The migration window has a hard end date — typically 30–90 days.

7.5. Document each rollout step with a feature flag or producer config switch so the team can pause or revert.

### 8. Plan registry resilience

8.1. The registry is a hot dependency: producers and consumers call it on every first-time schema id. Cache aggressively; lifecycle of a schema id is forever, so cached entries do not expire.

8.2. Registry outage handling:

- Producers with a warm cache continue producing; producers starting cold cannot register a new schema until the registry returns.
- Consumers with a warm cache continue consuming; consumers seeing a new schema id cannot deserialize until the registry returns.
- Plan a multi-instance registry deployment. The registry is replicated; treat it like the broker — a single instance is not enough.

8.3. Schema backups: export schema history regularly. A registry without a backup is a single point of irrecoverable data loss for the schemas, even though Kafka data persists.

8.4. Cross-region: schemas should be replicated across regions used by Kafka. If MirrorMaker 2 mirrors topics across regions, the schemas must also be available in the destination region.

### 9. Handle multi-language consumers

9.1. Avro and Protobuf both have code generation for the major Kafka client languages. The generator produces classes the consumer maps to. Some languages handle evolution better than others; verify on the languages in use.

9.2. For JSON Schema, use a validator at runtime; ad-hoc parsing without validation is what got the team into trouble.

9.3. Schema text is the contract; generated code is not. Treat schema-evolution discussions in terms of the schema, not the generated classes, which differ by language.

9.4. Provide a starter project per language that imports the schema artifacts. Teams that have to write the boilerplate from scratch will copy-paste the wrong thing.

### 10. Document and emit

10.1. The policy artifact lists: chosen format, registry placement, subject naming, compatibility mode per topic kind, governance rules, deprecation window.

10.2. The rollout playbook lists each common change with the producer-then-consumer (or reverse) sequence, dual-populate windows, and rollback procedure.

10.3. The migration plan, when applicable, lists the format-switch or registry-introduction steps with reversibility checkpoints.

10.4. Each topic carries a header in its manifest pointing at its current schema version and the compatibility mode. Engineers reading the topic see the contract without digging through registry UI.

### Decision rules and heuristics

- **Pick one format per system.** Mixing Avro and Protobuf in one cluster is operational pain.
- **BACKWARD_TRANSITIVE for events.** Producers move first; consumers move later.
- **FULL_TRANSITIVE for compacted entity topics.** Old data must remain readable; new data must be readable by old consumers reading from start.
- **Reserve Protobuf field numbers on removal, always.** Forgetting once causes a silent data corruption later.
- **No rename in place.** Add new field, dual-populate, deprecate old, remove old.
- **No type change in place.** Same pattern.
- **Compatibility checks at publish time, not at read time.** Registry-enforced is the only checking that scales.
- **Schemas live with code, registered via CI.** Hand-registration drifts.
- **Deprecation window is at least 6 months for cross-team topics.** Shorter windows leak into breaks.
- **Schema registry is a critical dependency.** Replicate, back up, monitor.

### Edge cases

- **Topics with no schema yet (legacy JSON).** Register the current schema as version 1 with FORWARD compatibility temporarily, so existing producers do not break. Tighten to BACKWARD_TRANSITIVE once consumers can handle defaults.
- **Union types.** Avro unions are powerful and confusing. Default to a small union (e.g. `["null", "string"]` for optional). Avoid unions of unrelated record types in a single field.
- **Required field with no default.** A field added as required with no default is breaking in BACKWARD mode. The registry will reject; do not work around.
- **Logical types** (Avro `logicalType: timestamp-millis`, Protobuf `google.protobuf.Timestamp`). Use them; they survive language differences better than raw long-since-epoch fields.
- **Cross-topic referenced types.** Avro and Protobuf both allow shared definitions. Manage these in a separate shared schema package; do not embed and copy.
- **Schema-on-read consumers (analytics).** They read older data using a current schema; FULL_TRANSITIVE is essentially required for the compacted entity topics they target.
- **CDC schemas (Debezium-generated).** They evolve when the source table schema changes. Apply BACKWARD compatibility and accept the operational cost of source DDL coordinating with downstream consumers.

## Outputs

- `schema_policy` — Format, registry, subject naming, compatibility mode per topic kind, governance, deprecation window.
- `rollout_playbook` — Add field, deprecate field, remove field, rename, type change, split entity, hard break — each with the producer-and-consumer sequence and rollback path.
- `migration_plan` — When applicable, the format-switch or registry-introduction sequence with reversibility.

## Examples

### Worked example

Input excerpt:

> We have 12 production topics with JSON payloads, no registry. Three producer teams, eight consumer teams. Recent pain: a producer team renamed `customer_id` to `customerId` and broke six downstream consumers for a day. We use mostly Java and Python clients. We can sustain lightweight review per change.

Expected output sketch (policy excerpt):

- Format: Avro. Reason: Kafka-first stack, broad language support including Java and Python, compact binary, mature registry integration. Protobuf is not used elsewhere; Avro is the cheaper introduction.
- Registry: a single registry product hosted on the broker cluster's VPC, replicated across two instances, schemas exported nightly to object storage.
- Subject naming: TopicNameStrategy, one record type per topic; switch a single topic (`prod.orders.events`) to TopicRecordNameStrategy because it carries `order.placed`, `order.cancelled`, and `order.shipped`.
- Compatibility per topic kind:
  - Event topics: BACKWARD_TRANSITIVE.
  - Compacted entity topics (`prod.*.state`): FULL_TRANSITIVE.
  - Command and DLQ topics: BACKWARD.
- Governance: schema files live next to producer code; PRs touching schema require topic-owner review; CI runs the registry compatibility check and fails on incompatibility; registry write is the CI step on merge.

Rollout playbook excerpt for the rename scenario:

1. PR adds the new field `customer_id_v2` with default null and a comment marking the old field deprecated.
2. CI registers the new schema version against the topic subject. Compatibility check passes.
3. Producers deploy. Both fields are populated for the 90-day deprecation window.
4. Consumers migrate to read the new field. Each consumer's PR removes the old-field read.
5. After 90 days and the dashboard shows zero consumers reading the old field, producers stop populating the old field.
6. After another 30 days, the old field is removed from the schema; a follow-up PR registers the cleanup version.

Migration plan excerpt (JSON → Avro):

- Phase 1 (weeks 1–2): stand up the registry, define Avro schemas matching current JSON payloads, register version 1.
- Phase 2 (weeks 3–8): producers dual-publish JSON to existing topics and Avro to new `*.events.v2` topics. Consumers migrate one at a time; each migration is its own deploy.
- Phase 3 (weeks 9–12): after every consumer is on Avro topics, producers retire JSON topics. The old topics drain their retention naturally over the next 14 days.
- Reversibility: a feature flag on each producer toggles back to JSON-only publication. Each consumer migration is independently revertible.

## Limitations

- The skill does not recommend a specific schema-registry product. Several products exist with various licenses; the team must pick one that fits its allowlist and operational footprint.
- It does not enforce policy. A team without CI gates and topic-owner review will violate any policy within a quarter.
- It assumes Avro or Protobuf semantics. Custom serialization formats fall outside this advice.
- It does not cover schema discovery for analytics consumers reading from cold storage (Iceberg, Parquet). Those consumers benefit from the same schemas but have separate evolution mechanics.
- It cannot guarantee runtime correctness. Registry compatibility checks prevent some classes of breaks; consumer code that ignores defaults or assumes field presence still breaks.

## Sources reviewed

- https://github.com/apache/avro
- https://github.com/protocolbuffers/protobuf
- https://github.com/apache/kafka
- https://github.com/debezium/debezium
- https://github.com/apache/iceberg
- https://github.com/confluentinc/cp-demo

## Linked notes

- [[domains/platform/kafka-topic-architect]] — applies

<!-- skg-attribution:
  vault_path: "domains/platform/kafka-schema-evolution-architect.md"
  skill_id: "019e91f9-6c26-70e2-8062-5ad77a21cf94"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "efe8115d53b5afa6faafdd430468d11a30c563644f723d98022526bfc83f9e56"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:07.961586Z -->
