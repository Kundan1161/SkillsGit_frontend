---
id: skillsgit-curated/chaos-experiment-planner
version: 1.0.1
name: Chaos Experiment Planner
description: Plan a chaos experiment with explicit hypothesis, steady-state metrics,
  blast radius, abort criteria, and learnings capture so the test produces insight
  instead of an outage.
authors:
- name: skillsgit Curated
  handle: skillsgit-curated
  role: author
category: engineering
tags:
- niche:distributed-systems
- chaos-engineering
- resilience-testing
- game-day
- blast-radius
- failure-injection
- sre
- postmortem-input
links:
- target: imported-alirezarezvani-chaos-engineering
  relation: see-also
- target: ops-incident-commander
  relation: see-also
- target: imported-google-skills-waf-reliability
  relation: applies
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gpt-4.1
  - gemini-1.5-pro
  tools_required:
  - file_io
  tools_optional:
  - web_search
  min_context_tokens: 24000
  estimated_tokens_per_invocation: 6000
trigger_keywords:
- chaos engineering
- chaos experiment
- failure injection
- game day
- resilience test
- blast radius
- abort criteria
- fault injection
- latency injection
- pod kill experiment
- dependency outage drill
- disaster drill
- fire drill
- steady state hypothesis
example_invocations:
- Plan a chaos experiment that injects 30% packet loss between our API and payment
  service in staging.
- We want to game-day our cache failure response on Tuesday — write the experiment.
- Review this chaos experiment plan and tell me what blast-radius and abort criteria
  we're missing.
inputs:
- name: target
  type: text
  required: true
  description: The system, dependency, or behavior to test. Include the topology,
    the failure mode being injected, and the population of traffic involved.
- name: hypothesis
  type: text
  required: false
  description: What you expect to be true under the injected condition — the steady
    state that should hold. If absent, the skill will help draft one.
- name: environment
  type: choice
  required: false
  description: Where the experiment runs. Production has tighter blast-radius and
    abort criteria than staging.
  choices:
  - development
  - staging
  - pre-prod
  - production-small-blast
  - production-full
- name: tooling
  type: text
  required: false
  description: Available chaos tooling and observability — fault-injection libraries,
    network shapers, monitoring dashboards, alert systems.
- name: prior_incidents
  type: text
  required: false
  description: Relevant past incidents the experiment is informed by — outcomes, gaps
    surfaced, hypotheses suggested for verification.
outputs:
- name: experiment_plan
  type: markdown
  description: A formal experiment plan with hypothesis, steady-state metric, scope,
    blast radius, abort criteria, runbook, learnings template.
- name: pre_flight_checklist
  type: markdown
  description: A short list of conditions that must hold before the experiment starts
    (observability green, on-call ready, comms posted, rollback rehearsed).
- name: postmortem_template
  type: markdown
  description: A structured template for capturing what happened, what was learned,
    and what work the experiment generates.
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release.
kind: skill
distribution:
  content_hash: d3befbc27393d90efcf8a8b837a939753aa7db1e5e137f7d26422b4c1c70ce5f
  signed_at: '2026-06-04T09:34:37.989418Z'
  signed_by: marketplace
  signature: b56215829c130364a9d3c40ca07994e537c66dbbcc9bbd542d48e5aa1518763b
---

# Chaos Experiment Planner

## When to use

Use this skill when a team is preparing a chaos experiment — a deliberate, controlled injection of failure intended to verify that the system behaves as designed under stress. The output is an experiment plan that lets the team run the experiment safely, learn from it, and capture the work it generates.

The skill is calibrated for teams running their first few experiments and for teams running mature game-days. It catches the common gaps that turn experiments into incidents: missing abort criteria, vague hypotheses, blast radii that are wider than the team noticed.

Common triggers:

- An outage suggested the system has resilience weaknesses; the team wants to verify before the next one.
- An on-call team plans a quarterly game-day to refresh incident-response muscle.
- A new service is going live and the team wants to test its resilience claims before traffic ramps.
- A platform team needs to demonstrate that a recent investment in resilience actually paid off.
- A SOC 2 or similar audit asks for evidence of resilience testing.

Do not use this skill for:

- Load testing or capacity planning. Those have related but distinct vocabularies.
- Penetration testing or security red-team exercises. Different scope, different reviewers, different abort criteria.
- Random failure injection without a hypothesis. Unfocused breakage is not chaos engineering; it is just breakage.

## Inputs

- `target` (required) — The system under test, the dependency or layer being perturbed, and the population of traffic. "Inject 200 ms added latency on the call from web-api to payments-svc, affecting 5% of inbound checkout traffic for 15 minutes" is usable. "Test payments" is not.
- `hypothesis` — The expected steady state. If not provided, the skill will help draft one from the target.
- `environment` — Drives blast radius and abort criteria. Production-full requires the strictest controls; development the loosest.
- `tooling` — Affects implementation. Recommendations adapt to what the team has.
- `prior_incidents` — Useful context. Experiments tied to past incidents are usually higher-value than abstract experiments.

## How to apply

The output is an experiment plan built section by section.

### 1. State the hypothesis

1.1. Every experiment has a hypothesis or it is not an experiment. The hypothesis is a falsifiable claim about steady state under the injected condition.

1.2. Format: "When [injected condition] is true, [steady-state metric] will remain [bound] for [population]." Example: "When the payment service is 200 ms slower, the checkout success rate will remain above 99% for users in the US region."

1.3. The hypothesis must be falsifiable. "The system will degrade gracefully" is not a hypothesis; "Latency will remain under 1500 ms p99" is.

1.4. State the hypothesis before the experiment is designed in detail. A hypothesis discovered after the run is just a story.

### 2. Pick the steady-state metric

2.1. The steady-state metric is the observable quantity that defines whether the hypothesis holds. It must be: measurable in near-real-time, robust against noise, and meaningful to the business.

2.2. Good steady-state metrics:

- Successful transaction rate (counts) per minute, where success is defined upstream.
- p99 end-to-end latency on a known endpoint.
- Cache hit rate for the workload involved.
- Saga completion rate for the affected process.
- Error budget burn rate over the experiment window.

2.3. Bad steady-state metrics:

- "Our dashboard looks fine." Subjective; not falsifiable.
- "No customer complaints." Lags by hours; cannot abort on this.
- Single-instance CPU usage. Tells you about a process, not the system.

2.4. Pick at most two steady-state metrics. More than two and the experiment becomes hard to interpret.

### 3. Design the perturbation

3.1. Specify the perturbation precisely: what fails, where it fails, how it fails, for how long, with what intensity.

3.2. Common perturbations:

- **Latency injection** — delay responses by a fixed or distributional amount.
- **Error injection** — return errors at a defined rate.
- **Resource starvation** — CPU, memory, disk, or network bandwidth pressure.
- **Process kill** — terminate one or more instances of a service.
- **Network partition** — block traffic between two groups of nodes.
- **DNS or service-discovery failure** — make a downstream unresolvable.
- **Clock skew** — shift the system clock on one or more nodes.
- **Storage failure** — read-only mode, slow disk, full disk.

3.3. Start with the **smallest meaningful perturbation**. The first experiment for a system should not be "kill the database"; it should be "add 100 ms to one downstream and see what happens."

3.4. Increase intensity in subsequent experiments after the smaller ones return data. Aggressive first experiments yield outages, not insight.

### 4. Define the scope and blast radius

4.1. The blast radius is the population that may be affected if the experiment goes wrong. Define it explicitly:

- **Traffic blast radius** — the share of requests touched. Start at 1% in production; ramp on subsequent runs.
- **Tenant blast radius** — which customers or accounts are affected. Avoid affecting flagship accounts during early experiments.
- **Region blast radius** — keep experiments to one region first.
- **Service blast radius** — the explicit downstream that can also be affected if the perturbation propagates.

4.2. Use **routing and feature flags** to enforce scope. A perturbation that applies "to everything" is too large for early experiments.

4.3. State the **worst-case blast radius** alongside the intended one. If the experiment misbehaves, what is the most it could damage? If the answer is "the whole product", redesign.

4.4. For production experiments, prefer **synthetic traffic** or **canary traffic** as the first targets. Inject into the synthetic path before the real-user path.

### 5. Define abort criteria

5.1. The experiment is aborted when an abort criterion fires. Criteria are objective and observable in real time.

5.2. Standard abort criteria:

- Steady-state metric breached its bound by more than 20% for more than 60 seconds.
- A separate "guardrail" metric breached (often: total error rate across the product).
- A page fires that is not the expected experiment-induced page.
- A human in the room calls abort. "I have a bad feeling" is a valid abort.

5.3. The **abort path** is a single command. Test it before the experiment starts. A manual fifteen-step rollback is not an abort path.

5.4. Aborts are not failures. An aborted experiment that revealed a bound the team had not noticed is a successful experiment.

5.5. State the abort criteria in the plan and re-state them in the room at the start of the run.

### 6. Build the run script

6.1. Sequence:

- **T-30 minutes**: open the comms channel, post the plan link, confirm on-call awareness.
- **T-10 minutes**: re-verify the steady-state metric is in a normal range.
- **T-0**: start the perturbation at the smallest scope.
- **T+observation_window/2**: ramp scope if guardrails are clean. Skip ramp on first experiments.
- **T+observation_window**: stop the perturbation, confirm steady-state recovery.
- **T+observation_window+10 minutes**: hot-wash the run while memories are fresh.

6.2. **Observation window** length: long enough to see the system's slowest detection feedback loop (alerts, autoscalers, retries). Typical: 10–30 minutes for a small experiment.

6.3. The script names a **conductor** (drives the experiment), an **observer** (watches metrics and calls abort), and a **scribe** (captures observations). For small experiments one person can fill two roles; not all three.

6.4. Pre-record the **expected timeline of events**: the perturbation starts, X happens within Y seconds, Z follows after W minutes. Surprises at the actual run become valuable data.

### 7. Plan observability

7.1. Identify the dashboards and traces that will be watched during the run. Bookmark them in the comms channel.

7.2. Confirm that the **steady-state metric** is plotted at a resolution shorter than the abort criterion window. A metric refreshed every 5 minutes cannot anchor a 60-second abort criterion.

7.3. Confirm that the **guardrail metrics** are visible without log-in friction. The observer should not be hunting through dashboards while abort criteria fire.

7.4. Snapshot dashboards at T-5, T+0, T+observation_window/2, T+observation_window, T+30. These become the postmortem artifacts.

7.5. Tag traces with the experiment id so post-hoc analysis can filter to affected traffic.

### 8. Communicate

8.1. Internal comms: post the plan link in the engineering channel, the on-call channel, and any tenant-facing customer-support channel that should know. Use a clear "chaos experiment in progress" banner during the run.

8.2. External comms: for production experiments with any user-visible blast radius, decide in advance whether to status-page the experiment. Default: do not status-page small in-scope experiments; do status-page experiments that may cause user-visible degradation.

8.3. **Stakeholder approval**: production experiments need sign-off from the on-call team for the affected service plus a sponsor with authority over the blast radius. Sign-offs are real, not theater; require an acknowledgement.

8.4. Plan **end-of-experiment comms**: announce the abort or normal completion in the same channels.

### 9. Capture learnings

9.1. The experiment is not done when the perturbation stops. The team owes a write-up.

9.2. The postmortem template captures: hypothesis, perturbation, outcome (held or falsified), observations, unexpected behaviors, action items.

9.3. Action items are concrete and assigned. "Improve resilience" is not an action item; "Add a 500 ms timeout to the cache get call in service X" is.

9.4. Distinguish **expected outcomes** from **surprises**. Surprises are the gold of chaos engineering; the team should re-run them after the work is done to verify the fix.

9.5. Publish the write-up. Hidden chaos experiments build organizational distrust; visible ones build it down.

### 10. Plan the sequel

10.1. Each experiment narrows the search space. The next experiment usually extends the perturbation in one of four ways:

- Wider scope (same perturbation, more traffic).
- Deeper system (same downstream, more aggressive perturbation).
- Adjacent component (sibling service, similar perturbation).
- Compound (two perturbations simultaneously, often less aggressive each).

10.2. Schedule the sequel before the current one ends. Momentum is the scarce resource in chaos programs.

10.3. Retire perturbations that consistently hold their hypothesis after several runs. The team has learned the system handles that condition; refocus on others.

### 11. Emit the plan

11.1. Lead with one paragraph: target, hypothesis, perturbation, blast radius, abort criteria, scheduled time.

11.2. Provide the full plan: hypothesis, steady-state metrics, perturbation specification, scope, observation window, run script with role assignments, observability bookmarks, abort criteria, comms plan, learnings template.

11.3. Provide the pre-flight checklist as a separate section: observability green, on-call paged in, blast-radius routing tested, abort path tested, sign-offs collected.

11.4. Provide the postmortem template the team will fill out after the run.

### Decision rules and heuristics

- **No hypothesis, no experiment.** Random breakage is sabotage with extra steps.
- **Start small.** The first experiment in a system should feel boring. Boredom is a feature.
- **Blast radius is the first design choice, not the last.** Decide it before designing the perturbation.
- **Abort criteria are objective.** "It feels wrong" is a valid abort, but the criteria document gives objective ones too.
- **Observe more than you perturb.** A perturbation without dashboards is theater.
- **Falsified hypotheses are wins.** They produced learning. Treat them as the most valuable outcome.
- **Run in production eventually, but never first.** A program that never runs in production never learns the real failure modes; a program that starts in production teaches an incident response course.
- **The conductor does not call abort.** Separate the roles; the observer abort decision must be uninhibited by the conductor's momentum.

### Edge cases

- **The system has no resilience to test.** Sometimes the first chaos experiment reveals that the system is so fragile any experiment is unsafe. Recommend building basic resilience first, then return.
- **The metric the team wants to watch is not measurable yet.** Defer the experiment, instrument first. An experiment without measurement is meaningless.
- **Regulated industry.** Some industries require formal change-management approvals for any production perturbation. Build approval workflows into the plan; do not skip them.
- **Multi-region with active-active.** Perturbations in one region may shift traffic to another. Plan to observe both regions.
- **External vendor as the target.** Inject the failure between you and the vendor, not into the vendor. The vendor likely does not consent to your experiment.
- **Game day involving humans.** People are part of the system. Test the incident response process, the runbooks, and the comms channels, not just the code paths.
- **Repeated experiments to verify a fix.** Run the same perturbation after the fix lands; if the hypothesis now holds, the fix is verified. Resist the urge to skip verification.

## Outputs

- `experiment_plan` — A markdown document covering hypothesis, steady-state metrics, perturbation, scope, blast radius, run script with roles, observability bookmarks, abort criteria, comms plan, and a postmortem template stub.
- `pre_flight_checklist` — Conditions that must hold before the experiment starts. Designed to be printed and walked through in the room.
- `postmortem_template` — A structured template covering hypothesis, perturbation, outcome, observations, surprises, action items. The team fills it in within 24 hours of the run.

## Examples

### Worked example

Input excerpt:

> Web-api calls payments-svc over gRPC. We want to verify our circuit breaker actually opens under sustained latency. Target environment: production, small blast radius. Available tooling: a sidecar that injects latency by service, OpenTelemetry traces, a Grafana stack, an existing on-call rotation, feature-flag system for routing.

Expected output sketch:

- Hypothesis: "When the payments-svc p99 latency exceeds 800 ms for 2 minutes, the circuit breaker in web-api opens within 60 seconds and the checkout success rate remains above 98% for affected users via the queued-retry fallback."
- Steady-state metrics: (1) checkout success rate (1-minute resolution), (2) breaker state per route (state transitions captured by trace span).
- Perturbation: latency injection of 1500 ms on web-api → payments-svc, applied to 2% of traffic (selected by feature flag based on user-id hash), for 15 minutes.
- Blast radius: ≤2% of checkout users in one region for the duration; worst case if propagation fails: 2% of users for the duration plus 1 minute of recovery; status-page banner not required at this scope.
- Abort criteria: (1) checkout success rate below 95% for any 60-second window; (2) any unexpected page fires; (3) human in the room calls abort.
- Run script: T-30 announce, T-10 verify steady state, T+0 start at 2%, no ramp first run, T+15 stop, T+25 hot-wash.
- Observability bookmarks: checkout success dashboard, breaker state dashboard, latency p99 dashboard, error rate dashboard.
- Comms: post in #engineering and #payments-oncall; banner on the team channel; no public status page.
- Postmortem: filled out within 24h, published in the engineering wiki.

## Limitations

- The skill does not run the experiment; it produces the plan. Execution discipline lives with the team.
- It cannot verify that the chosen steady-state metric is actually instrumented in the target system. Encourage the team to verify the metric responds in normal traffic before the experiment.
- It is biased toward conservative blast radii. Teams that want to start with aggressive perturbations will receive a counter-recommendation.
- It does not cover penetration testing or security experiments; those have their own approval and scope rules.
- It assumes the team has a basic incident response process. Without one, a chaos experiment is a teaching exercise, not a learning one.

## Sources reviewed

- https://github.com/Netflix/chaosmonkey
- https://github.com/chaos-mesh/chaos-mesh
- https://github.com/litmuschaos/litmus
- https://github.com/dapr/dapr
- https://github.com/resilience4j/resilience4j
- https://github.com/temporalio/temporal

## Linked notes

- [[domains/incident/imported-alirezarezvani-chaos-engineering]] — see-also
- [[domains/incident/ops-incident-commander]] — see-also
- [[domains/incident/imported-google-skills-waf-reliability]] — applies

<!-- skg-attribution:
  vault_path: "domains/incident/chaos-experiment-planner.md"
  skill_id: "019e91f9-6638-7733-9227-1a8c8a548c9f"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "2ab44a09f47e654d3531505b259416793bdba1d4054d996c1fd2c13dcc2f2618"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:39:34.070194Z -->
