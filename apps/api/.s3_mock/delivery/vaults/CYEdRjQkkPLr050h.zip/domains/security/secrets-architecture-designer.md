---
id: skillsgit-curated/secrets-architecture-designer
version: 1.0.1
name: Secrets Architecture Designer
description: Design an end-to-end secrets architecture covering sources of truth,
  runtime distribution, rotation policy, ephemeral vs long-lived credentials, break-glass,
  and multi-cloud federation.
authors:
- name: skillsgit Curated
  handle: skillsgit-curated
  role: author
category: engineering
tags:
- niche:identity-and-secrets
- secrets-management
- rotation
- vault
- kubernetes
- multi-cloud
- break-glass
- audit
links:
- target: workload-identity-architect
  relation: extends
- target: artifact-signing-and-verification-designer
  relation: see-also
license_type: free
pricing:
  currency: USD
  support_included: false
ai:
  required_models:
  - claude-opus-4-7
  compatible_models:
  - claude-sonnet-4-6
  - gpt-4o
  - gpt-4.1
  tools_required:
  - file_io
  tools_optional:
  - web_search
  min_context_tokens: 32000
  estimated_tokens_per_invocation: 11000
trigger_keywords:
- secrets architecture
- secrets management design
- vault design
- secrets rotation
- secret zero
- dynamic secrets
- break-glass
- secrets audit
- multi-cloud secrets
- secret distribution
- secret sprawl
example_invocations:
- Design a secrets architecture for our three-region multi-cloud platform.
- We have secrets sprawled across env vars, CI variables, and a legacy vault — propose
  a target state.
- Lay out a rotation policy for database credentials and third-party API tokens.
inputs:
- name: scope
  type: text
  required: true
  description: Workloads, environments, and regions covered (e.g., "200 microservices
    across 3 AWS regions plus an on-prem Kubernetes fleet").
- name: current_state
  type: text
  required: false
  description: Existing secret stores, env-var practices, CI variable use, ad-hoc
    files, and any prior vault or KMS deployment.
- name: compliance_drivers
  type: text
  required: false
  description: Regulatory or contractual constraints (PCI, HIPAA, SOC2, FedRAMP) that
    force specific controls such as separation of duties, rotation frequency, or audit
    retention.
- name: blast_radius_tolerance
  type: text
  required: false
  description: How much downstream impact is acceptable on rotation, on revocation,
    and on outage of the secrets plane itself.
- name: ops_capacity
  type: text
  required: false
  description: Headcount and skill profile of the team that will operate the secrets
    plane day to day.
outputs:
- name: architecture_document
  type: markdown
  description: A target-state design with sources of truth, distribution paths, lifecycle
    policy, break-glass, audit, and migration roadmap.
- name: decisions_json
  type: json
  description: 'Structured record of choices: secret_class, store, distribution_mechanism,
    ttl, rotation_owner, break_glass_path, audit_sink, residual_risk.'
changelog:
- version: 1.0.0
  date: 2026-05-14
  notes: Initial release.
kind: skill
distribution:
  content_hash: 3a6134ced3bb8ab5ee18b6d4b624463e158d70de6d68a5c72f6afe9f76c54644
  signed_at: '2026-06-04T09:34:38.022866Z'
  signed_by: marketplace
  signature: 82ee00598327edc5b6a3082e11cd7629d12b721840ef9ae790000e819ea437e3
---

# Secrets Architecture Designer

## When to use

Use this skill when an engineering organization needs a written target state for how secrets — database passwords, API tokens, cloud credentials, signing keys, TLS private keys, third-party webhook secrets, encryption keys, OAuth client secrets — are stored, distributed, rotated, audited, and revoked across a multi-service, multi-environment estate.

Concrete moments to invoke:

- A new platform team is being chartered and asked "what is the secrets story" before any service onboards.
- Audit or compliance has flagged secrets sprawl, plaintext in repositories, or stale long-lived keys.
- The organization is migrating from one cloud to two, or adding an on-prem footprint, and the existing single-cloud secret store will not serve both worlds.
- A production incident traced back to a leaked or unrotated secret has created political will for a real architecture.
- A new product line demands sharper isolation (per-tenant key material, BYOK obligations) than the current shared model supports.

The skill produces a target-state architecture document and a structured decision record. It is opinionated about defaults — favour ephemeral credentials over long-lived ones, favour identity-based access over shared secrets, favour append-only audit over best-effort logs — and explicit about the trade-offs each default imposes.

This skill is not a vendor selector. It expresses the architecture in terms that map to most modern secret stores; the integrator picks a specific implementation. It is also not a penetration test, a threat model, or a key-management program design — that last is a sibling skill (`key-management-program-architect`) with overlapping but distinct concerns.

## Inputs

| Input | Required | Purpose |
| --- | --- | --- |
| `scope` | yes | Bounds the design — services, environments, regions, identities. |
| `current_state` | no | Anchors the migration roadmap and lets the agent grade the gap honestly. |
| `compliance_drivers` | no | Forces specific controls (rotation frequency, audit retention, separation of duties). |
| `blast_radius_tolerance` | no | Drives ttl choices and revocation-path design. |
| `ops_capacity` | no | Calibrates complexity — a two-person platform team should not own a high-availability raft cluster. |

## How to apply

Run the stages in order. Earlier choices constrain later ones; do not jump ahead.

### Stage 1 — Inventory and classify secrets

1. Enumerate every kind of secret the in-scope systems handle today. Group by purpose, not by storage location: database credentials, cloud API credentials, third-party API tokens, OAuth client secrets, webhook signing secrets, TLS server private keys, code-signing keys, encryption-at-rest keys, intra-service mTLS material, root-of-trust material (CA private keys, master encryption keys).
2. For each kind, capture five attributes: who creates it, who consumes it, lifetime today, blast radius if leaked, and detection difficulty if leaked. The matrix gives the agent the raw material for downstream policy choices.
3. Mark each secret kind as one of: **bootstrap** (needed before any identity exists — e.g., the credential a process uses to authenticate to the secrets plane), **operational** (consumed by workloads at runtime to call other systems), **long-lived** (signing keys, root CA material that must persist across rotations), **session** (short-lived tokens issued from a longer-lived credential), or **derived** (computed from a key in the store and never persisted in plaintext).
4. Flag secrets that should not exist in the target state at all. A static long-lived cloud access key consumed by a service that runs inside that cloud is a classic candidate — workload identity replaces it. A symmetric webhook secret shared by ten services is another — per-service secrets with the same trust replace it.
5. Record the inventory as a table the user can verify. Do not proceed until the user accepts or amends it; a wrong inventory poisons every later choice.

### Stage 2 — Pick sources of truth

6. For each remaining secret kind, declare a single source of truth. The source of truth is the system that holds the authoritative value; every other copy is a cache or a derived artefact and must be reproducible from the source.
7. Default to one logical secrets store per environment, replicated geographically inside that environment. Two logical stores in the same environment is a code smell unless there is a hard sovereignty boundary (e.g., one regulated tenant cannot share infrastructure with another).
8. Encryption-at-rest keys for the secrets store itself live outside the store — in a cloud KMS, a hardware security module, or a sealed-storage primitive on the store's host. Never let the store gate access to its own root key.
9. For multi-cloud, prefer a primary store in one cloud with read-replicas or one-way mirrors elsewhere, over a federated multi-master design, unless the team has the operational maturity for the harder design. Document the recovery story for the failure mode "primary cloud unreachable for 24 hours."
10. For each source of truth, record: technology category (e.g., centralized vault, cloud-native secret manager, file-system-based encrypted store, hardware-backed token), replication topology, the identity the store authenticates with to its underlying storage, and the operator who owns it.

### Stage 3 — Design distribution

11. For every consumer kind, name the distribution mechanism. The mechanisms in modern stacks are: direct API read (workload calls the store at startup or on-demand), sidecar injection (a co-process fetches and presents secrets through a local socket or filesystem), operator-mediated synchronization (a control-plane process pulls from the store and writes platform-native secret objects such as Kubernetes Secrets), agent-rendered templates (a host agent renders config files on disk from store contents), or environment variables injected at process start.
12. Direct API read is the strongest pattern for new workloads — the secret never persists outside the consumer's memory and rotation is observable from the store side. Operator-mediated synchronization is the pragmatic default for Kubernetes workloads that cannot be modified, because it bridges legacy `envFrom` patterns to a real store without code changes. Make this trade-off explicit in the document.
13. For each path, name the identity used to authenticate the consumer to the store. The bootstrap problem — how the consumer first proves it is allowed to read its secret — is the single most common point of failure. Resolutions: cloud instance metadata (the consumer's role), workload identity attestation (e.g., SPIFFE-style), Kubernetes service account tokens with audience-bound projection, signed JWTs from a platform identity provider. Forbid embedded long-lived tokens in container images, in CI variables that ship to runtime, or in baked-in environment files.
14. Define refresh semantics for each path: how often the consumer re-reads, what it does on failure, whether it accepts a stale value, and how long a stale value is valid. A service that caches a database password for 24 hours after the store goes unreachable behaves very differently from one that hard-fails after five minutes; both are valid choices but the design must pick one.
15. Define the path for build-time secrets — credentials a CI pipeline needs to talk to package registries, deploy targets, signing services. CI runners attest into the secrets store using their own workload identity rather than carrying static deploy keys; the document should make this explicit and call out the specific identity-attestation primitive offered by the CI platform in use.

### Stage 4 — Lifecycle and rotation

16. Assign each secret kind a rotation cadence: automatic-on-use, automatic-scheduled, automatic-event-driven, manual-scheduled, or never-rotates. "Never-rotates" is valid for some root material but should be paired with a documented rekey procedure executable on demand.
17. Prefer dynamic credentials over static rotation. A dynamic database credential generated for a workload on first request, valid for an hour, and revoked at expiry, eliminates the rotation problem at the cost of dependence on the store's availability. For each candidate dynamic-credential surface (databases, cloud APIs, message brokers, internal services), record whether the upstream supports it.
18. For static secrets that must rotate, design two-key overlap: at rotation time, the new value is published and the old one is left valid for an overlap window long enough that all consumers have refreshed. Define the overlap explicitly per kind — a one-hour overlap is reasonable for workloads polling every five minutes; days may be needed for sleepy batch jobs.
19. Name the rotation owner per secret kind. The owner is the human or system responsible for invoking the rotation and verifying that no consumer broke. Owners must be roles, not individuals; rotations performed by a single human cannot be audited or run while that human is on leave.
20. Capture detection: what alert fires when a secret nears expiry without a rotation, when a rotation fails, when an old version is still in use after the overlap window. These are not nice-to-haves; missing them turns the rotation policy into theatre.

### Stage 5 — Break-glass and revocation

21. Define a break-glass path for every secret class. The break-glass path is the procedure for retrieving or replacing a secret when the normal automation is unavailable — for example, when the store is down, when the platform identity service is broken, or when a compromise requires emergency rotation.
22. Break-glass requires a different identity than normal access. The agent should describe the human approval flow: dual-control retrieval of a sealed credential from an offline location, with audit guarantees that survive store-side compromise.
23. Define revocation timing per secret class. For dynamic credentials, revocation is implicit at lease expiry; document the maximum residual window. For static credentials, revocation requires both invalidating the secret at the source-of-truth side and notifying consumers — define the notification mechanism (push, poll, force-restart).
24. Design for the partial-compromise case: a single workload is suspected of compromise but the secret it holds is shared across many workloads. The design should make this case rare (per-workload secrets, dynamic credentials) and, where it cannot be avoided, document the cost (broad rotation of every consumer).

### Stage 6 — Audit and observability

25. Specify what every secret-plane action emits: read events, write events, rotation events, lease grants, lease renewals, revocations, policy changes, administrative authentications. The events must include the calling identity (not just the network origin), the secret reference (not the secret value), and the policy decision.
26. Audit logs flow to a sink the secret-plane administrators cannot edit. Cross-account log delivery with an account-isolation boundary is the standard pattern; document the specific cross-boundary primitive in use.
27. Define drift detection: a periodic job that compares actual platform-native secret objects to the store's view and flags discrepancies. A secret that exists in a Kubernetes namespace but not in the store, or a value that has changed without a rotation event, is a high-signal alert.
28. Define a metric set that the platform team watches week to week: percentage of secrets rotated on schedule, percentage of workloads using dynamic credentials, age distribution of long-lived secrets, count of break-glass events, count of failed rotations. The metrics make the architecture observably alive.

### Stage 7 — Migration roadmap

29. Translate the gap between `current_state` and the target state into ordered phases. Phase 0 is always "stop new sprawl" — a policy and an enforcement mechanism (commit-time scanners, admission webhooks, CI checks) that block new secrets from landing outside the chosen architecture.
30. Order subsequent phases by blast-radius reduction per effort, not by alphabetical service name. Migrating the highest-blast-radius long-lived cloud credentials to workload-identity first usually pays more than migrating a hundred low-impact webhook secrets.
31. For each phase, define entry, exit, owner, rollback. A phase without a defined rollback is a phase that will not be attempted.
32. Carry forward a residual-risk register: items the design knowingly does not solve in this iteration, with the rationale and the trigger for revisiting (regulatory change, scale milestone, new product surface).

## Outputs

The skill returns:

- A markdown architecture document with sections matching stages 1-7.
- A JSON record of every secret class with its assigned source of truth, distribution mechanism, lifecycle policy, owner, audit sink, and known residual risks.
- A migration roadmap with ordered phases, each with entry and exit conditions.

## Examples

Example skeleton invocation: a 200-service platform with a primary AWS footprint, a smaller GCP footprint for analytics, and an on-prem Kubernetes cluster for an air-gapped customer. The skill produces an inventory that distinguishes shared third-party API tokens (consolidating to per-service dynamic credentials where the upstream supports it; documented overlap rotation otherwise) from cloud credentials (eliminated entirely in favour of workload identity inside AWS and GCP, with a federated trust into a small set of on-prem-issued SVIDs); chooses one logical secrets store per environment with cross-region replication; specifies operator-mediated synchronization into Kubernetes; assigns rotation cadences ranging from one-hour leases on dynamic database creds to quarterly rotation for the few unavoidable static webhook secrets; documents a sealed-envelope break-glass procedure stored offline; and orders the migration so that the highest-impact static cloud credentials are first to die.

## Limitations

- The skill does not select a specific vendor. It will name technology categories and call out concrete primitives, but choosing between, say, two centralized vault implementations is left to the integrator.
- The skill assumes the team has at least one platform operator. A solo team running a hundred workloads should adopt a much simpler design than the one this skill will produce by default; tell the skill so in `ops_capacity`.
- The skill does not size the deployment. Replica counts, instance types, network capacity, and storage forecasts come from a downstream capacity-planning exercise.
- The skill does not enumerate cryptographic primitives. Key sizes, algorithm choices, and HSM versus software-key trade-offs live in `key-management-program-architect`.
- The skill does not produce code. Terraform, Helm charts, and policy files are downstream of the architecture document.

## Sources reviewed

The methodology was synthesized from the following public projects, each of which contributed patterns to one or more stages. No code or documentation was copied; the citations are for transparency.

- https://github.com/spiffe/spire — Apache-2.0
- https://github.com/openbao/openbao — MPL-2.0
- https://github.com/external-secrets/external-secrets — Apache-2.0
- https://github.com/cert-manager/cert-manager — Apache-2.0
- https://github.com/getsops/sops — MPL-2.0
- https://github.com/FiloSottile/age — BSD-3-Clause
- https://github.com/sigstore/cosign — Apache-2.0

## Linked notes

- [[domains/security/workload-identity-architect]] — extends
- [[domains/security/artifact-signing-and-verification-designer]] — see-also

<!-- skg-attribution:
  vault_path: "domains/security/secrets-architecture-designer.md"
  skill_id: "019e91f9-66f3-74c2-90ac-ffa65c8b13c9"
  version: "1.0.1"
  kind: "skill"
  creator_handle: "skillsgit-curated"
  content_hash: "4af6ad6f867cea462c64e53a38a4c170b9847f199bdf471248276d5bcaa681f6"
  built_at: "2026-01-01T00:00:00Z"
-->

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:08.511364Z -->
