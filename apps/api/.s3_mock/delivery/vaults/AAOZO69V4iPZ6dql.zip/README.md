# AI DevOps Engineer — v1.0.0

> A curated, graph-linked vault of methodology for the AI DevOps Engineer role. Built by @skillsgit-curated.

## What's in this vault

- 30 base methodology skills across 7 domain(s) (ci-cd, observability, incident, iac, security, cost, platform).
- Compose with persona overlays for recorded situations and on-call decisions.

## Summary

The AI DevOps Engineer occupation packages 30 cross-linked methodology
skills covering the full DevOps lifecycle — from pipeline design
through incident response, observability, infrastructure as code,
workload identity, supply-chain security, and FinOps. Built on top of
Skills Git's curated library, every member skill links to its
neighbours (60 explicit cross-links) so an Obsidian graph view renders
the day-to-day mental map an on-call SRE actually uses.

Pair this base occupation with a Persona overlay (Wave 4) to add a
practitioner's recorded situations, decisions, and outcomes on top of
the curated methodology.

## How to use this vault

1. Open the folder in **Obsidian** (no plugins required).
2. Press `Ctrl-G` to view the graph.
3. Start at `00-index.md`.
4. Drop the vault folder into your AI agent's working directory; point your agent at `vault.json` for routing.

## Attribution

This vault was assembled at 2026-01-01T00:00:00Z by Skills Git from:
- `@skillsgit-curated/ai-devops-engineer` v1.0.0

See `vault.json` for the machine-readable manifest.

## License

Each file's license is governed by the buyer's purchase of the parent product. This bundle is per-buyer; the watermark in each file identifies the licensee. Redistribution is not permitted.

<!-- license:c12fd132942eff81 buyer:8382e503cf6d3781 ts:2026-06-04T09:37:07.961148Z -->
